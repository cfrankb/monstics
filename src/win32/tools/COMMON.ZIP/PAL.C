//
// Pal.C
//

#define NumSysColors (sizeof(SysPalIndex)/sizeof(SysPalIndex[1]))
#include "pal.h"

HWND extern hwnd;


// The editor

//*** These are the GetSysColor display element identifiers
int SysPalIndex[] = {
  COLOR_ACTIVEBORDER,
  COLOR_ACTIVECAPTION,
  COLOR_APPWORKSPACE,
  COLOR_BACKGROUND,
  COLOR_BTNFACE,
  COLOR_BTNSHADOW,
  COLOR_BTNTEXT,
  COLOR_CAPTIONTEXT,
  COLOR_GRAYTEXT,
  COLOR_HIGHLIGHT,
  COLOR_HIGHLIGHTTEXT,
  COLOR_INACTIVEBORDER,

  COLOR_INACTIVECAPTION,
  COLOR_MENU,
  COLOR_MENUTEXT,
  COLOR_SCROLLBAR,
  COLOR_WINDOW,
  COLOR_WINDOWFRAME,
  COLOR_WINDOWTEXT
};


//*** This array holds the old color mapping so we can restore them
COLORREF OldColors[NumSysColors];

USER_WINPAL     PalColors[256];			// The user colors palette

unsigned int    MSDOS_PAL16[256];
USER_24bpp      MSDOS_PAL24[256];
USER_32bpp      MSDOS_PAL32[256];

char MSDOS_PAL[] = {
	0 , 0 , 0 , 0 , 0 , 42 , 0 , 42 , 
	0 , 0 , 42 , 42 , 42 , 0 , 0 , 42 , 
	0 , 42 , 42 , 21 , 0 , 42 , 42 , 42 , 
	21 , 21 , 21 , 21 , 21 , 63 , 21 , 63 , 
	21 , 21 , 63 , 63 , 63 , 21 , 21 , 63 , 
	21 , 63 , 63 , 63 , 21 , 63 , 63 , 63 , 
	0 , 0 , 0 , 5 , 5 , 5 , 8 , 8 , 
	8 , 11 , 11 , 11 , 14 , 14 , 14 , 17 , 
	17 , 17 , 20 , 20 , 20 , 24 , 24 , 24 , 
	28 , 28 , 28 , 32 , 32 , 32 , 36 , 36 , 
	36 , 40 , 40 , 40 , 45 , 45 , 45 , 50 , 
	50 , 50 , 56 , 56 , 56 , 63 , 63 , 63 , 
	0 , 0 , 63 , 16 , 0 , 63 , 31 , 0 , 
	63 , 47 , 0 , 63 , 63 , 0 , 63 , 63 , 
	0 , 47 , 63 , 0 , 31 , 63 , 0 , 16 , 
	63 , 0 , 0 , 63 , 16 , 0 , 63 , 31 , 
	0 , 63 , 47 , 0 , 63 , 63 , 0 , 47 , 
	63 , 0 , 31 , 63 , 0 , 16 , 63 , 0 , 
	0 , 63 , 0 , 0 , 63 , 16 , 0 , 63 , 
	31 , 0 , 63 , 47 , 0 , 63 , 63 , 0 , 
	47 , 63 , 0 , 31 , 63 , 0 , 16 , 63 , 
	31 , 31 , 63 , 39 , 31 , 63 , 47 , 31 , 
	63 , 55 , 31 , 63 , 63 , 31 , 63 , 63 , 
	31 , 55 , 63 , 31 , 47 , 63 , 31 , 39 , 
	63 , 31 , 31 , 63 , 39 , 31 , 63 , 47 , 
	31 , 63 , 55 , 31 , 63 , 63 , 31 , 55 , 
	63 , 31 , 47 , 63 , 31 , 39 , 63 , 31 , 
	31 , 63 , 31 , 31 , 63 , 39 , 31 , 63 , 
	47 , 31 , 63 , 55 , 31 , 63 , 63 , 31 , 
	55 , 63 , 31 , 47 , 63 , 31 , 39 , 63 , 
	45 , 45 , 63 , 49 , 45 , 63 , 54 , 45 , 
	63 , 58 , 45 , 63 , 63 , 45 , 63 , 63 , 
	45 , 58 , 63 , 45 , 54 , 63 , 45 , 49 , 
	63 , 45 , 45 , 63 , 49 , 45 , 63 , 54 , 
	45 , 63 , 58 , 45 , 63 , 63 , 45 , 58 , 
	63 , 45 , 54 , 63 , 45 , 49 , 63 , 45 , 
	45 , 63 , 45 , 45 , 63 , 49 , 45 , 63 , 
	54 , 45 , 63 , 58 , 45 , 63 , 63 , 45 , 
	58 , 63 , 45 , 54 , 63 , 45 , 49 , 63 , 
	0 , 0 , 28 , 7 , 0 , 28 , 14 , 0 , 
	28 , 21 , 0 , 28 , 28 , 0 , 28 , 28 , 
	0 , 21 , 28 , 0 , 14 , 28 , 0 , 7 , 
	28 , 0 , 0 , 28 , 7 , 0 , 28 , 14 , 
	0 , 28 , 21 , 0 , 28 , 28 , 0 , 21 , 
	28 , 0 , 14 , 28 , 0 , 7 , 28 , 0 , 
	0 , 28 , 0 , 0 , 28 , 7 , 0 , 28 , 
	14 , 0 , 28 , 21 , 0 , 28 , 28 , 0 , 
	21 , 28 , 0 , 14 , 28 , 0 , 7 , 28 , 
	14 , 14 , 28 , 17 , 14 , 28 , 21 , 14 , 
	28 , 24 , 14 , 28 , 28 , 14 , 28 , 28 , 
	14 , 24 , 28 , 14 , 21 , 28 , 14 , 17 , 
	28 , 14 , 14 , 28 , 17 , 14 , 28 , 21 , 
	14 , 28 , 24 , 14 , 28 , 28 , 14 , 24 , 
	28 , 14 , 21 , 28 , 14 , 17 , 28 , 14 , 
	14 , 28 , 14 , 14 , 28 , 17 , 14 , 28 , 
	21 , 14 , 28 , 24 , 14 , 28 , 28 , 14 , 
	24 , 28 , 14 , 21 , 28 , 14 , 17 , 28 , 
	20 , 20 , 28 , 22 , 20 , 28 , 24 , 20 , 
	28 , 26 , 20 , 28 , 28 , 20 , 28 , 28 , 
	20 , 26 , 28 , 20 , 24 , 28 , 20 , 22 , 
	28 , 20 , 20 , 28 , 22 , 20 , 28 , 24 , 
	20 , 28 , 26 , 20 , 28 , 28 , 20 , 26 , 
	28 , 20 , 24 , 28 , 20 , 22 , 28 , 20 , 
	20 , 28 , 20 , 20 , 28 , 22 , 20 , 28 , 
	24 , 20 , 28 , 26 , 20 , 28 , 28 , 20 , 
	26 , 28 , 20 , 24 , 28 , 20 , 22 , 28 , 
	0 , 0 , 16 , 4 , 0 , 16 , 8 , 0 , 
	16 , 12 , 0 , 16 , 16 , 0 , 16 , 16 , 
	0 , 12 , 16 , 0 , 8 , 16 , 0 , 4 , 
	16 , 0 , 0 , 16 , 4 , 0 , 16 , 8 , 
	0 , 16 , 12 , 0 , 16 , 16 , 0 , 12 , 
	16 , 0 , 8 , 16 , 0 , 4 , 16 , 0 , 
	0 , 16 , 0 , 0 , 16 , 4 , 0 , 16 , 
	8 , 0 , 16 , 12 , 0 , 16 , 16 , 0 , 
	12 , 16 , 0 , 8 , 16 , 0 , 4 , 16 , 
	8 , 8 , 16 , 10 , 8 , 16 , 12 , 8 , 
	16 , 14 , 8 , 16 , 16 , 8 , 16 , 16 , 
	8 , 14 , 16 , 8 , 12 , 16 , 8 , 10 , 
	16 , 8 , 8 , 16 , 10 , 8 , 16 , 12 , 
	8 , 16 , 14 , 8 , 16 , 16 , 8 , 14 , 
	16 , 8 , 12 , 16 , 8 , 10 , 16 , 8 , 
	8 , 16 , 8 , 8 , 16 , 10 , 8 , 16 , 
	12 , 8 , 16 , 14 , 8 , 16 , 16 , 8 , 
	14 , 16 , 8 , 12 , 16 , 8 , 10 , 16 , 
	11 , 11 , 16 , 12 , 11 , 16 , 13 , 11 , 
	16 , 15 , 11 , 16 , 16 , 11 , 16 , 16 , 
	11 , 15 , 16 , 11 , 13 , 16 , 11 , 12 , 
	16 , 11 , 11 , 16 , 12 , 11 , 16 , 13 , 
	11 , 16 , 15 , 11 , 16 , 16 , 11 , 15 , 
	16 , 11 , 13 , 16 , 11 , 12 , 16 , 11 , 
	11 , 16 , 11 , 11 , 16 , 12 , 11 , 16 , 
	13 , 11 , 16 , 15 , 11 , 16 , 16 , 11 , 
	15 , 16 , 11 , 13 , 16 , 11 , 12 , 16 , 
	0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
	0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
	0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
	0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 };


HPALETTE		hpal;


void AppActivate(BOOL fActive);
HPALETTE CreateIdentityPalette(USER_WINPAL user_defpal[], int nColors);
void ClearSystemPalette(void);

//***********************************************************
//
// InitAppPal()
//
//
BOOL InitAppPal()
{
	int			dx,dy;
	HDC			Screen;
	int 		PaletteDevice;
	int 		nBitsPixel;         
	int 		nPlanes;         
	int			nColorDepth;


    /* Refuse to run if this is a non-palettized device */
    Screen = GetDC(0);

    if (Screen)
    {
      PaletteDevice = GetDeviceCaps(Screen, RASTERCAPS) & RC_PALETTE;
      nBitsPixel = GetDeviceCaps(Screen, BITSPIXEL);         
      nPlanes = GetDeviceCaps(Screen, PLANES);         
      nColorDepth = nBitsPixel * nPlanes;
      ReleaseDC(0, Screen);

      if ((8 > nColorDepth) )
      {
        MessageBox(0,
         "Affichage de moins de 256 couleurs inutilisable",
         "Erreur d'affichage",
         MB_OK);
        return FALSE;
      }
    }

    dx = GetSystemMetrics (SM_CXSCREEN) / 2;
    dy = GetSystemMetrics (SM_CYSCREEN) / 2;

	return TRUE;
}



/************************************************************/
//
//*** AppActivate sets the system palette use and
//*** remaps the system colors accordingly.
//
/************************************************************/
void AppActivate(BOOL fActive)
{
  HDC hdc;
  int i;

  //*** Just use the screen DC
  hdc = GetDC(NULL);

  //*** If the app is activating, save the current color mapping
  //*** and switch to SYSPAL_NOSTATIC
  if (fActive && GetSystemPaletteUse(hdc) == SYSPAL_STATIC)
  {
    //*** Store the current mapping
    for (i=0; i<NumSysColors; i++)
      OldColors[i] = GetSysColor(SysPalIndex[i]);

    //*** Switch to SYSPAL_NOSTATIC and remap the colors
    SetSystemPaletteUse(hdc, SYSPAL_NOSTATIC);
    //SetSysColors(NumSysColors, SysPalIndex, MonoColors);
  }
  else if (!fActive)
  {
    //*** Always switch back to SYSPAL_STATIC and the old mapping
    SetSystemPaletteUse(hdc, SYSPAL_STATIC);

    //SetSysColors(NumSysColors, SysPalIndex, OldColors);
  }
  //*** Be sure to release the DC!
  ReleaseDC(NULL,hdc);
}



// ***********************************************************
//*** Creating an identity palette code here
//
// ***********************************************************

HPALETTE CreateIdentityPalette(USER_WINPAL user_defpal[], int nColors)
{
  int i,x;
  struct
  {
    WORD Version;
    WORD NumberOfEntries;
    PALETTEENTRY aEntries[256];
  } Palette =
  {
    0x300,
    256
  };


  HDC hdc = GetDC(NULL);

  //*** For SYSPAL_NOSTATIC, just copy the color table into
  //*** a PALETTEENTRY array and replace the first and last entries
  //*** with black and white

/*  if (GetSystemPaletteUse(hdc) == SYSPAL_NOSTATIC )
  {
    //*** Fill in the palette with the given values, marking each
    //*** as PC_RESERVED
    for(i = 0; i < nColors; i++)
    {
      Palette.aEntries[i].peRed =   0x00+user_defpal[i].red;
      Palette.aEntries[i].peGreen = 0x00+user_defpal[i].green;
      Palette.aEntries[i].peBlue =  0x00+user_defpal[i].blue;
      Palette.aEntries[i].peFlags = PC_RESERVED;
	}


    //*** Mark any remaining entries PC_RESERVED
    for (; i < 256; ++i)
    {
      Palette.aEntries[i].peFlags = PC_NOCOLLAPSE;
    }

    //*** Make sure the last entry is white
    //*** This may replace an entry in the array!
    
    Palette.aEntries[0].peRed = 0;
    Palette.aEntries[0].peGreen = 0;
    Palette.aEntries[0].peBlue = 0;
    Palette.aEntries[0].peFlags = 0;

    //*** And the first is black
    //*** This may replace an entry in the array!

  }
  else
*/

  //*** For SYSPAL_STATIC, get the twenty static colors into
  //*** the array, then fill in the empty spaces with the
  //*** given color table
  {
    int nStaticColors;
    int nUsableColors;

    //*** Get the static colors
    nStaticColors = GetDeviceCaps(hdc, NUMCOLORS);
    GetSystemPaletteEntries(hdc, 0, 256, Palette.aEntries);

    //*** Set the peFlags of the lower static colors to zero
    nStaticColors = (nStaticColors / 2) ;
    for (i=0; i<nStaticColors; i++)
      Palette.aEntries[i].peFlags = 0;

    //*** Fill in the entries from the given color table
    nUsableColors = nColors - nStaticColors;
    
	for (x=0, i=16; i<nUsableColors; i++, x++)
    {
      //Palette.aEntries[i].peRed = aRGB[i][0];
      //Palette.aEntries[i].peGreen = aRGB[i][2];
      //Palette.aEntries[i].peBlue = aRGB[i][1];
      //Palette.aEntries[i].peFlags = PC_RESERVED;

      Palette.aEntries[i].peRed =   0x00+PalColors[x].red;
      Palette.aEntries[i].peGreen = 0x00+PalColors[x].green;
      Palette.aEntries[i].peBlue =  0x00+PalColors[x].blue;
      Palette.aEntries[i].peFlags = PC_NOCOLLAPSE;
    
	}

    //*** Mark any empty entries as PC_RESERVED
    for (; i<256 - nStaticColors; i++)
      Palette.aEntries[i].peFlags = PC_RESERVED;

    //*** Set the peFlags of the upper static colors to zero
    for (i = 256 - nStaticColors; i<256; i++)
      Palette.aEntries[i].peFlags = 0;

    

  }

  ReleaseDC(NULL, hdc);


  //*** Create the palette
  return CreatePalette((LOGPALETTE *)&Palette);
}






//***********************************************************
//
// void ClearSystemPalette(void)
// Nettoyer la palette syst�me
//
//***********************************************************
void ClearSystemPalette(void)
{
	//*** A dummy palette setup
	struct
	{
		WORD Version;
		WORD NumberOfEntries;
		PALETTEENTRY aEntries[256];
	} Palette =
	{
		0x300,
		256
	};

	HPALETTE ScreenPalette = 0;
	HDC ScreenDC;
	int i;

	//*** Reset everything in the system palette to black
	for(i = 0; i < 256; i++)
	{
      Palette.aEntries[i].peRed =   0;
      Palette.aEntries[i].peGreen = 0;
      Palette.aEntries[i].peBlue =  0;
          
	  Palette.aEntries[i].peFlags = 0 ; //PC_EXPLICIT;	
	}

	//*** Create, select, realize, deselect, and delete the palette
	ScreenDC = GetDC(NULL);
	ScreenPalette = CreatePalette((LOGPALETTE *)&Palette);
	if (ScreenPalette)
	{
		ScreenPalette = SelectPalette(ScreenDC,ScreenPalette,FALSE);
		RealizePalette(ScreenDC);
		ScreenPalette = SelectPalette(ScreenDC,ScreenPalette,FALSE);
		DeleteObject(ScreenPalette);
	}
	ReleaseDC(NULL, ScreenDC);
}


int ChoisirCouleur()
{
	 static CHOOSECOLOR cc ;
     static COLORREF    crCustColors[16] ;

     cc.lStructSize    = sizeof (CHOOSECOLOR) ;
     cc.hwndOwner      = NULL ;
     cc.hInstance      = NULL ;
     cc.rgbResult      = RGB (0x80, 0x80, 0x80) ;
     cc.lpCustColors   = crCustColors ;
     cc.Flags          = CC_RGBINIT | CC_FULLOPEN ;
     cc.lCustData      = 0L ;
     cc.lpfnHook       = NULL ;
     cc.lpTemplateName = NULL ;

     return ChooseColor (&cc) ;
}

// *************************************************************
//
// BOOL msg_QueryNewPalette(HWND hwnd, HPALETTE hpal)
//
// *************************************************************


BOOL msg_QueryNewPalette(HWND hwnd, HPALETTE hpal)
{
    HDC hdc;	
    
	BOOL f;
    hdc = GetDC(hwnd);

	if (hpal)
    	SelectPalette(hdc, hpal, FALSE);

    f = RealizePalette(hdc);
    ReleaseDC(hwnd,hdc);

    if (f)
       InvalidateRect(hwnd,NULL,TRUE);

    return f;
}

// *************************************************************
//
// void msg_ActivateApp(HWND hwnd, HPALETTE hpal, WPARAM wParam)
//
// *************************************************************

void msg_ActivateApp(HWND hwnd, HPALETTE hpal, WPARAM wParam)
{
	HDC hdc;	
    
    BOOL fAppActive;
     fAppActive = (BOOL)wParam;               
     AppActivate(FALSE);
     if (hpal)
     {
         hdc = GetDC(hwnd);

         UnrealizeObject(hpal);
         SelectPalette(hdc, hpal, FALSE);
         RealizePalette(hdc);
         ReleaseDC(hwnd, hdc);
      }
        
}

//***********************************************************
//
// CreateAppPal()
//
//***********************************************************

 BOOL CreateAppPal()
 {
			   HDC hdc;
		   	   int cpt;
		
               unsigned int icolor;
               unsigned int red;
               unsigned int blue;
               unsigned int green;

			   memcpy(PalColors, MSDOS_PAL, 256*3);			   
			   
			   for (cpt=0; cpt<256; cpt++)
			   {
				   PalColors[cpt].red =  PalColors[cpt].red*4;
				   PalColors[cpt].green =  PalColors[cpt].green*4;
				   PalColors[cpt].blue =  PalColors[cpt].blue*4;
               
                   red= (PalColors[cpt].red/4) /2;                                              
                   green= (PalColors[cpt].green/4) /2 ;                        
                   blue= (PalColors[cpt].blue/4) /2;          
                
                
                   icolor =  (1*  blue)      
                        + (1*64*green )    
                        + (1*0x800* red)    ;
                                   
                    MSDOS_PAL16[cpt] = icolor;             
                    MSDOS_PAL24[cpt].red = PalColors[cpt].red;
                    MSDOS_PAL24[cpt].blue = PalColors[cpt].blue;
                    MSDOS_PAL24[cpt].green = PalColors[cpt].green;

                    MSDOS_PAL32[cpt].red = PalColors[cpt].red;
                    MSDOS_PAL32[cpt].blue = PalColors[cpt].blue;
                    MSDOS_PAL32[cpt].green = PalColors[cpt].green;
                    MSDOS_PAL32[cpt].reserved = 0;
                  
                   
               }
			   
				  
			   if (InitAppPal()==FALSE) return FALSE;
				
				hpal= CreateIdentityPalette(PalColors, 256);
				
                ClearSystemPalette();				

				AppActivate(TRUE);

				if (hpal)
				{
					hdc = GetDC(hwnd);

					UnrealizeObject(hpal);
					SelectPalette(hdc, hpal, FALSE);
					RealizePalette(hdc);				
					
					ReleaseDC(hwnd, hdc);
				}

   
	return TRUE;

 }

// **************************************************************
//
// void AppExit()
//
// **************************************************************

void AppExit()
{

  if (hpal)
    DeleteObject(hpal);

  //*** Be sure to restore the state on exit!
   AppActivate(FALSE);
}


