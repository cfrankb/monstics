/*
	FICHIER: IMLMAKER.C
	AUTEUR : FRANCOIS BLANCHETTE
	BUT    : GENERER DES .IML A PARTIR DE .OBL
*/

#include <user\friendly.h>
#include <stdlib.h>
char ver[]="IMLMAKER V1.0 (12/28/95)";
struct ffblk ffblk;

typedef  struct
{
	char id[4];
	unsigned int nbfnt;
	unsigned int sizedefstats;
	unsigned int sizemap;
	unsigned int sizecomment;
	unsigned int nbobl;
}  IMLHEADER;

typedef struct
{
	char id[4];
	unsigned char masterkey;
	unsigned char objclass;
	unsigned char s1;
	unsigned char s2;
	unsigned char lenght;
	unsigned char height;
	unsigned char hasmap;
}  OBLHEADER;

typedef struct
{
	int ptrnext;
	char masterkey;
	char objclass;
	char s1;
	char s2;
	char lenght;
	char height;
	int ptrmap;
	//int fragments; //flexible structure
} IMLENTRY;


// GLOBAL VARIABLES
FILE *sfile;
FILE *tfile;
FILE *mfile;
FILE *oblfile;

int quiet =0;

// System related var
IMLHEADER 			imlheader;
IMLENTRY  			imlentry;
OBLHEADER 			oblheader;

//IMLENTRY  			*imlptr;
unsigned int        *imlptr;
unsigned int huge 	*fontptr;
unsigned char      	*mapptr;
unsigned char      	*comptr;
unsigned int huge  *fntptr;

unsigned int 		imlbase;
unsigned int 		combase;
unsigned int	    mapbase;

// A fnt from a .OBL
int aFNT[64/2];


void AfficherSyntaxe()
{
	puts("");
	puts(ver);
	puts("(C) 1995 FRANCOIS BLANCHETTE");
	puts("\nSyntaxe:");
	puts("  IMLMAKER [/S] fichiers ...");
	puts("");
	puts("  /? /HELP /AIDE         Aide");
	puts("  /S                     Supprimer le (c) message\n");
	exit(3);
}

void stripof(char *chaine, char car)
{
	int cpt;
	for (cpt=0; cpt<strlen(chaine); cpt++)
	{
		if (*(chaine+cpt) == car)
			strcpy(chaine+cpt, chaine+cpt+1);
	}
}

char maj(char car)
{
	if ( (car>='a') && (car <='z') )
	   car = car -'a' + 'A';

	return(car);
}


int haswild(const char *NomIma)
{
	return(((strchr(NomIma, '*')) || (strchr(NomIma,'?'))));
}

int hasbackslash(const char *NomIma)
{	return(int)(strchr(NomIma,'\\'));
}

int lastofchar(const char *NomIma, char car)
{   const char *temp;
	int addon_;
	temp = NomIma;
	addon_ = strlen(NomIma);

	while (((*(temp+addon_) != car) &&
			(addon_)))
		addon_--;

	if (*(temp+addon_)!=car)
		return(-1);
	else
		return(addon_);
}

void error(const char *err__)
{
	puts(err__);
	exit(2);
}



int IsIn(const char *Limite, char car)
{
	//printf("%c%s%c", 34,Limite,34);
	for (;*Limite; Limite++)
		if (*Limite == car)
		{
		//	printf("*");
			return(1);
		}
	return(0);

}

void chgchar(char *chaine, char ocar, char ncar)
{
	for (;*chaine; chaine++)
	{	if ( (*chaine)==ocar)
			 (*chaine)=ncar;
	}
}

char *getElement(char *element, char *chaine, const char *limite)
{

	char *t_element;
	t_element= element;
	for (;*chaine==32;chaine++);
	for (; *chaine; chaine++, element++ )
	{

		if (    ((IsIn(limite, *chaine) ==1)  &&  (*t_element)!=';')
		   )
		{
			//*chaine=0;
			printf("%");
			break;

		}

		 *element= *chaine;
	}
	*element=0;
	printf("%s\n", t_element);
	if (*chaine)
		return(chaine+1);
	else
		return(chaine);
}

void ecrireIML(char *imlname)
{
	tfile = fopen(imlname, "wb");
	if (tfile==NULL)
	{
		printf("ERR: Incapable de reecrire %c%s%c.\n", 34, imlname,34);
		fprintf(mfile,"ERR: Incapable de reecrire %c%s%c.\n", 34, imlname,34);
		return;
	}

	fwrite(&imlheader, sizeof(IMLHEADER), 1, tfile);
	fwrite(imlptr, imlbase, 1, tfile);
	fwrite(mapptr, mapbase, 1, tfile);
	fwrite((char huge*)fontptr, imlheader.nbfnt, 64, tfile);
	fwrite(comptr, combase, 1,tfile);
	fprintf(tfile, "%c%s (C) 1995 FRANCOIS BLANCHETTE ", 0xff, ver);
	fclose(tfile);
}

int findmatch()
{
	unsigned int x,y;
	unsigned int huge *ptr;
	ptr = fontptr;
	for (y=0; y!=(imlheader.nbfnt); y++)
	{
		for (x=0; x<64/2; x++)
		{
		   if (*(ptr+x+y*32) != (aFNT[x]) )
			  break;
		}

		if (x==(64/2))
			break;
	}

	if (y==imlheader.nbfnt)
	{
		memmove(ptr+imlheader.nbfnt*32, aFNT, 64);
		(imlheader.nbfnt)= (imlheader.nbfnt)+1;

	}
	printf("FONT=%d NBFNT=%d\n", y, imlheader.nbfnt);

	return(y);

}

int openobl(char *name,char *chaine)
{
	unsigned int x;

	oblfile= fopen(name, "rb");
	if (oblfile==NULL)
	{
	   fprintf(mfile," [err]\n");
	   return(0);
	}

	// Reading the OBLHEADER in memory
	fread(&oblheader, sizeof(OBLHEADER), 1, oblfile);

	// Adding Utilisation map
	if (oblheader.hasmap)
	{
		*(imlptr+4+imlbase/2)= mapbase;
		fread(mapptr+ mapbase, oblheader.lenght * oblheader.height,
			  1, oblfile);
		imlheader.sizemap=+(oblheader.lenght* oblheader.height);
	}
	else
		*(imlptr+4+imlbase/2)= -1;

	// Adding comment
	strcpy( comptr + combase, chaine);
	combase = combase + strlen(chaine) +1;
	imlheader.sizecomment = combase;

	// Filling the field in the .IML data structure
	// masterkey,objclass, s1,s2, lenght, height
	memmove(imlptr+1+imlbase/2, &oblheader.masterkey, 6);

	// Fill the list of framents
	for (x=0; x < (oblheader.lenght * oblheader.height) ; x++)
	{
		fread(aFNT, 64,1,oblfile);
		*(imlptr +imlbase/2 +x + sizeof(IMLENTRY)/2)= findmatch();
	}

	// Filling IMLENTRY.ptrnext
	*(imlptr+imlbase/2) = imlbase + sizeof(IMLENTRY) +
						  (oblheader.lenght * oblheader.height *2);

	// Prepare for next .OBL
	imlbase = imlbase+ sizeof(IMLENTRY) + (oblheader.lenght * oblheader.height *2);
	imlheader.sizedefstats = imlbase;
	imlheader.sizemap = mapbase;
	imlheader.sizecomment = combase;

	printf("%x\n", imlbase);
	fprintf(mfile," [ok]\n");
	fclose(oblfile);
	return(1);

}

void ajouterobl(char *element, char *chaine)
{
	char oblname[128];

	if ((imlheader.nbobl)<0x10)
		fprintf(mfile,"000%x", imlheader.nbobl);
	else
		if ((imlheader.nbobl)<0x100)
			fprintf(mfile,"00%x", imlheader.nbobl);
		else
			if ((imlheader.nbobl)<0x1000)
				fprintf(mfile,"0%x", imlheader.nbobl);
			else
				fprintf(mfile,"%x", imlheader.nbobl);

	fprintf(mfile, " %-25s ", element);
	strcpy(oblname, element);
	strcat(oblname, ".OBL");
//	printf("%c%s%c",34,chaine,34);
	fprintf(mfile, "%-30s", chaine);

	if (openobl(oblname, chaine)==0) return;
	imlheader.nbobl++;

}

void GererSection(char *entete)
{
	char static imlname[128];
	char static chaine[256];
	char static element[128];

	if (strcmpi(entete,"END")== 0)
	   return;

	strcpy(imlname, entete);
	strcat(imlname, ".IML");
	fprintf(mfile,"-----------------------------------------------\n");
	fprintf(mfile,"FILE CREATED: [%s]\n", entete);

	//Init IMLHEADER
	strcpy(imlheader.id, "IML");
	imlheader.nbfnt =0;
	imlheader.sizedefstats =0;
	imlheader.sizemap =0;
	imlheader.sizecomment =0;
	imlheader.nbobl =0;

	imlbase=0;
	combase=0;
	mapbase=0;

	while(!feof(sfile))
	{
		fgets(chaine,254,sfile);
		chgchar(chaine, 0xd, 0);
		chgchar(chaine, 0xa, 0);
		stripof(chaine,34);
		strcpy(chaine,getElement(element,chaine, ", ]"));

		switch(element[0])
		{
			case ';':
			case 0  :
				fprintf(mfile, "%s\n", element);
			break;

			case '[':
				ecrireIML(imlname);
				if (strcmpi(element+1,"END")== 0)
				   return;
				GererSection(element+1);
			break;

			default:
				ajouterobl(element, chaine);
//				fprintf(mfile, "FATALE: Entete de section attendue.\n");
			break;

		}
	}

}


void readINIFile()
{
	static char chaine[256];
	char element[256];

	while(!feof(sfile))
	{
		fgets(chaine,254,sfile);
		chgchar(chaine, 0xd, 0);
		chgchar(chaine, 0xa, 0);
		stripof(chaine,34);
		strcpy(chaine,getElement(element,chaine, ", ]"));

		switch(element[0])
		{
			case ';':
			case 0  :
				fprintf(mfile, "%s\n", element);
			break;

			case '[':
				if (strcmpi(element+1,"END")== 0)
				   return;
				GererSection(element+1);
			break;

			default:
				fprintf(mfile, "FATALE: Entete de section attendue.\n");
			return;

		}
	}
}

void gererINI(char ininame[])
{
	static char mapname[128];
	strcpy(mapname, ininame);
	strcpy(mapname+ lastofchar(mapname, '.'), ".MAP");

	printf("INI FILE:%s\n", ininame);
	printf("MAP FILE:%s\n", mapname);

	// Ouverture du fichier .INI
	sfile = fopen(ininame, "rb");
	if (sfile==NULL)
	{
		printf("ERR: Incapable de lire %c%s%c\n", 34,ininame,34);
		return;
	}

	// Ouverture du fichier .MAP
	mfile = fopen(mapname, "wt");
	if (sfile==NULL)
	{
		fclose(sfile);
		printf("ERR: Incapable de reecrire %c%s%c\n", 34,mapname,34);
		return;
	}

	fprintf(mfile,"SOURCE FILE LINKED: %s\n", ininame);
	readINIFile();

	//fputs("\n!File compiled with apparent success.\n", mfile);
	fputs("\n!File was compiled entierly", mfile);

	fclose(sfile);
	fclose(mfile);
	//fclose(tfile);

}

void withfile(char *thefile)
{
	static char ininame[128];

	char *tempPtr = thefile;
	int lastslash= lastofchar(thefile, '\\');
	int lastdot;

	if (lastslash!=-1)
		tempPtr= tempPtr + lastslash;

	lastdot = lastofchar(tempPtr+ lastslash, '.');

	if (lastdot==-1)
	{	strcpy(ininame, thefile);
		strcat(ininame, ".INI");
	}
	else
		strcpy(ininame, thefile);

	gererINI(ininame);
}

void givehelp(int NbArgs, char *TabPtr[])
{
	char static temp[256];
	int cpt;
	for (cpt=1; cpt < NbArgs; cpt++)
	{
		*(TabPtr[cpt]+1)= maj(*(TabPtr[cpt]+1));
		strcpy(temp,TabPtr[cpt]);
		temp[2]=0;

		if (strcmp(temp, "/C") !=0)
			strupr(TabPtr[cpt]);
		if (strcmp(temp, "/S") ==0)
			quiet=1;
		if (strcmp(temp, "/Q") ==0)
			quiet=1;

		if (strcmp(TabPtr[cpt], "/?") ==NULL)
			AfficherSyntaxe();
		if (strcmp(TabPtr[cpt], "/HELP") ==NULL)
			AfficherSyntaxe();
		if (strcmp(TabPtr[cpt], "/AIDE") ==NULL)
			AfficherSyntaxe();

	}
}


char hex2dec(unsigned char hex)
{
	//printf("[%c]", hex);
	if (((hex >='0') && (hex<='9')) )
		return(hex-'0');
	if (((hex >='A') && (hex<='F')))
		return(hex-'A'+10);
	return(18);
}


void withcommand(char *command)
{
	switch(*(command+1))
	{
		case 'S':
		case 'Q':
			break;

		default:
			printf("Parametre %c%s%c invalide.\n", 34,command,34);
			break;
	}
}

void AllocMem()
{
	  imlptr  = (unsigned int*) farmalloc(32768);
	  if (imlptr==NULL) error("FATALE: Memoire insuffisante.");

	  mapptr  = (unsigned char *) farmalloc(16384);
	  if (mapptr==NULL) error("FATALE: Memoire insuffisante.");

	  comptr  = (unsigned char *) farmalloc(16384);
	  if (comptr==NULL) error("FATALE: Memoire insuffisante.");

	  fontptr = (unsigned int huge*) farmalloc(65536*4);
	  if (fontptr==NULL) error("FATALE: Memoire insuffisante.");
}


void main(int NbArgs, char *TabPtr[])
{
	int cpt;
	// User want help ?
	givehelp(NbArgs, TabPtr);
	if (NbArgs <2)
		AfficherSyntaxe();

	if (!quiet)
	{
		puts("");
		puts(ver);
		puts("(C) 1995 FRANCOIS BLANCHETTE\n");
	}

	AllocMem();
	for (cpt=1; cpt < NbArgs; cpt++)
	{
		if (*(TabPtr[cpt])!='/')
			withfile(TabPtr[cpt]);
		else
			withcommand(TabPtr[cpt]);
	}

}