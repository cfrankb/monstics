
//
// scx,c
//

#include "scx.h"

int SaveSCX(USER_SCX3HEADER *pScxHead,
            char *szScxName)
{
    FILE *tfile;
    int iCpt;
    USER_SCX3 *pScx;
    
    tfile =fopen(szScxName, "wb");
    if (tfile==NULL) return err_fileopen;

    memcpy(pScxHead->Id, "SCX3",4);
    fwrite(pScxHead, sizeof(USER_SCX3HEADER), 1, tfile);
    pScx = pScxHead->pFirst;
    for (iCpt=0; iCpt<pScxHead->iNbEntries; iCpt++)
    {
        fwrite(pScx, sizeof(USER_SCX3), 1,tfile);
        // Prepare to add extra data later...
        pScx = pScx->pNext;
    }
    fclose(tfile);

}


void NewSCX(USER_SCX3HEADER *pScxHead,
            char *szSdoName,
            char *szScxName)
{

    fillmem(pScxHead, 0, sizeof(USER_SCX3HEADER));
    pScxHead->iNbEntries =0;
    pScxHead->iDataSize = 0;//sizeof(USER_SCX3);
    pScxHead->pFirst = NULL;//malloc(sizeof(USER_SCX3));
    //fillmem(pScxHead->pFirst, 0, sizeof(USER_SCX3));
    strcpy(pScxHead->szName,"");
    if (SamePath(szSdoName, szScxName))
    {
       strcpy(pScxHead->szSDOName,
           LastOf(szSdoName, '\\')+1);
    }
    else
    {
       strcpy(pScxHead->szSDOName,szSdoName);
    }
    strcpy(pScxHead->szSDOFullName,szSdoName);
    memcpy(pScxHead->Id, "SCX3",4);

}

int LoadSDO(USER_SDO3TABS *pSdoTabs,
            char *szFilename)
{

    FILE            *sfile;
    USER_SDO3HEADER lsSdoHead;
    USER_SDI3       *pSdi;
    USER_SDI3       *pPSdi;
    int             iCpt;
    USER_SDO3       *pSDOa;
    USER_SDO3       *pSDOb;
    int             iNbValidObjs=0;

    fillmem(lsSdoHead.Id, 0,4);
    if (szFilename==NULL) return err_filename;
    if (strlen(szFilename)==0) return err_filename;

    sfile = fopen( szFilename, "rb");
    if (sfile==NULL) return err_fileopen;
    fread(&lsSdoHead, sizeof(USER_SDO3HEADER), 1 ,sfile);

    if (memcmp(lsSdoHead.Id, "SDO3",4)!=0)
    {   fclose (sfile);
        return err_format;
    }

    // Alloc and init tabs
    pSdoTabs->ppTabSdi =  malloc(4 * lsSdoHead.iNbObj);
    fillmem(pSdoTabs->ppTabSdi,0,4 * lsSdoHead.iNbObj); 

    pSdoTabs->ppTabIma =  malloc(4 * lsSdoHead.iNbImages);
    fillmem(pSdoTabs->ppTabIma,0,4 * lsSdoHead.iNbImages); 

    pSdoTabs->ppTabMap =  malloc(4 * lsSdoHead.iNbImages);
    fillmem(pSdoTabs->ppTabMap,0,4 * lsSdoHead.iNbImages); 

    // Alloc and fill-up noueds
    lsSdoHead.pFirstSdi =malloc(lsSdoHead.iNbObj*sizeof(USER_SDI3));
    fread(lsSdoHead.pFirstSdi,lsSdoHead.iNbObj * sizeof(USER_SDI3),
        1,sfile);

    lsSdoHead.pFirstIma = malloc(lsSdoHead.iSizeImage);
    fread(lsSdoHead.pFirstIma, lsSdoHead.iSizeImage, 1,sfile);

    lsSdoHead.pFirstMap = malloc(lsSdoHead.iSizeMap);
    fread(lsSdoHead.pFirstMap, lsSdoHead.iSizeMap, 1,sfile);

    fclose(sfile);
    
    // Save Ptr to 1st SDI
    pSdoTabs->pFirstSdi = lsSdoHead.pFirstSdi;
 
    // Lier les noeuds et remplir le tableau des Sdi
    pSdi = lsSdoHead.pFirstSdi;
    pPSdi = NULL;
    lsSdoHead.pFirstSdi = NULL;
    for (iCpt=0; iCpt<lsSdoHead.iNbObj; iCpt++)
    {

        // if valid entry
        if ((pSdi->bDeleted==FALSE) &&
            (pSdi->sOblHead.iNbrImages!=0))
        {     
            iNbValidObjs = iNbValidObjs+1;
            if (lsSdoHead.pFirstSdi==NULL) 
            {
                pSdi->bDeleted = iCpt;  // # obj
                lsSdoHead.pFirstSdi=pSdi;
                pPSdi = pSdi;
            }
            else
            {
                pSdi->bDeleted = iCpt;  // # obj
                pPSdi->pNext = pSdi;
            }


            // Set the default image no straight
            if ((pSdi->sOblHead.iDefaultImage>0) 
                && (pSdi->sOblHead.iDefaultImage<=
                pSdi->sOblHead.iNbrImages) )
            {
                    pSdi->sOblHead.iDefaultImage =
                        pSdi->iFirstImaNo -1 +
                            pSdi->sOblHead.iDefaultImage;
            }
            else
            {
                pSdi->sOblHead.iDefaultImage = 
                     pSdi->iFirstImaNo;
            }


        }

        pSdi->pNext=NULL;
        *(pSdoTabs->ppTabSdi+iCpt)= pSdi;
        pSdi= pSdi+1;
    }

    // Remplir le tableau des Images
    // et des maps
    // (lier les noeuds sera inutile).

    pSDOa = lsSdoHead.pFirstIma;
    pSDOb = lsSdoHead.pFirstMap;
    for (iCpt=0; iCpt<lsSdoHead.iNbImages; iCpt++)
    {

        *(pSdoTabs->ppTabIma+iCpt) = pSDOa;
        pSDOa = (USER_SDO3 *)
                    ((char *)pSDOa + (pSDOa->iEntrySize));
            
        *(pSdoTabs->ppTabMap+iCpt) =  pSDOb;
        pSDOb = (USER_SDO3 *)
                    ((char *)pSDOb + (pSDOb->iEntrySize));

    }

    // Coping remaining pertinent data to TabsStruct
    pSdoTabs->pFirstValidSdi = lsSdoHead.pFirstSdi;
    pSdoTabs->iNbValidObjs = iNbValidObjs;
    pSdoTabs->iCurrentObj =0;
    pSdoTabs->iNbImages = lsSdoHead.iNbImages;

    if (iNbValidObjs==0)
        return err_emptyfile;
    
    return TRUE;
}