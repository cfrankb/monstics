// GRILDCLAS.C

// *** INCLUDED FILES ***
#include "resource.h"
#include "include.h"
#include "const.h"
#include "mcx.h"
#include "WinEasy.h"

extern HPALETTE hpal;
	 
// EDIT GRILD
extern HWND hAppInstance;

extern	USER_MCXHEADER mcx_header;
extern	USER_MCX       *current_mcx;
extern	USER_MCXHEADER mcx_header2;
extern  HWND hwnd;
extern  HWND hAppWnd;
extern  HWND hgrildwnd;	

extern	char     BitGrild[32*32*8*8];
extern  MOUSE	 mouse;

extern  USER_WINPAL		PalColors[256];		// The user colors palette
extern  USER_WINPAL		DefColors[256];
extern  HPALETTE		hpal;

extern  char PenColor;
extern  int HasChanged;
extern  char BitPalColor[];

void RemplirGrild(uchar BitGrild[], uchar ImageData[32][32]);
LRESULT CALLBACK EditGrildWndProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);
void InitBitGrild(uchar BitGrild[]);


void InitEditor(char BitGrild[], char BitImage[])
{
		InitBitGrild(BitGrild);        	
}

void InitBitGrild(uchar BitGrild[])
{
    int x,y,z;
	for (y=0; y<32; y++)
	{
		for (x=0 ; x<32; x++)
	    {    
			for (z=0; z<8; z++)
	        {
			   BitGrild[y*32*8*8+x*8+z+7*32*8] = 148;
			   BitGrild[(y*32*8*8)+(x*8)+7+(z*32*8)] = 148;
			}
	    }
	}
}


//**********************************************************
//
//
//
//**********************************************************

void NewFile()
{
				// Initializing mcx_header
				HasChanged = FALSE;
				memcpy (mcx_header.Id, "GE96",4);
				//memcpy (mcx_header.Version, "00", 2);
				mcx_header.Class= 0;
				strcpy (mcx_header.Name, "");
				mcx_header.NbrImages = 1;
				mcx_header.LastViewed = 1;
				memcpy (mcx_header.Palette, PalColors, 256*3);
				mcx_header.PtrFirst = malloc (sizeof(USER_MCX));
				*mcx_header.PtrFirst->Name = 0;
				mcx_header.PtrFirst->PtrPrev = NULL;
				mcx_header.PtrFirst->PtrNext = NULL;			   
				current_mcx =  mcx_header.PtrFirst;


				ClearMCX(current_mcx);
			
  				RemplirGrild(BitGrild, current_mcx->ImageData);
                if (hgrildwnd)
                    InvalidateRect(hgrildwnd,NULL,TRUE);				

				//DoCaption(hwnd);
}

//***********************************************************
//
//HWND RegisterAndCreateAppColorPal(HINSTANCE hInstance)
//
//***********************************************************

#define EditGrildName "Grille d'�dition"

HWND RegisterAndCreateEditGrild(HINSTANCE hInstance)

{
	WNDCLASS wc;
    ATOM atom;
    // *****************  Class for the ChildWindow ************************
	wc.style = CS_BYTEALIGNWINDOW 
		       ;
//	wc.style = CS_BYTEALIGNWINDOW |
//		       CS_HREDRAW | CS_VREDRAW | CS_OWNDC | CS_DBLCLKS;

    
    wc.lpfnWndProc = EditGrildWndProc; 
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 4;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, M2INT(IDI_ICON8)) ;
	wc.hCursor = LoadCursor(hInstance, M2INT(IDC_PEN96));
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = "EditGrild" ; 

	atom = RegisterClass(&wc);

    return (CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_WINDOWEDGE,
		"EditGrild",
		EditGrildName,
		WS_POPUP | WS_CAPTION | WS_CLIPCHILDREN | WS_MINIMIZEBOX
         | WS_CLIPSIBLINGS,
		150, 200, 32*8+128, 32*8+64,
		hwnd,
		(HMENU)NULL,
		hInstance,
		0L));
}


//	wsprintf (text, "%s - [%s]",



void PeinturerFenetre(HDC hdc, char BitGrild[])
{

			char text[512];

			int x,y;

	        HBITMAP hbitmap;
			if (hpal)
			{
				SelectPalette(hdc, hpal, FALSE);
				RealizePalette(hdc);
			}
													     

           hbitmap = MakeBitmap(32*8,32*8, BitGrild, hdc);
		   //hbitmap = CreateBitmap(32*8, 32*8, 1, 8, BitGrild);

		   if (hbitmap)
           { PutBitmap( hdc, 
		                hbitmap,
		                00,
		                00)  ;
		  
			   DeleteObject(hbitmap);
		   }

           hbitmap = MakeBitmap(32,32, (char *)current_mcx->ImageData, hdc);
		   //hbitmap = CreateBitmap(32, 32, 1, 8, current_mcx->ImageData);
		   if (hbitmap)
           { PutBitmap( hdc, 
		                hbitmap,
		                32*8+8,
		                8)  ; }
		  


			if (hbitmap)
			{
			for (y=0; y<3; y++)
			   for (x=0;x<3;x++)
					PutBitmap( hdc, 
		                hbitmap,
		                x*32+32*8+8,
		                y*32+16+32)  ;

			DeleteObject(hbitmap);
			}
			

			
           hbitmap = MakeBitmap(32,32, BitPalColor, hdc); 
		   //hbitmap = CreateBitmap(32, 32, 1, 8, BitPalColor);
		   if (hbitmap)
           { PutBitmap( hdc, 
		                hbitmap,
		                32*9+16,
		                8)  ;
		   



			   DeleteObject(hbitmap);
		   }


					strcpy(text,Int2Str(mcx_header.LastViewed));
					strcat(text, " de ");
					strcat(text,Int2Str(mcx_header.NbrImages));
					strcat(text, " images");


				    PutText(hdc,  
					       text, 
					         8*32+8+8,
							 8*16+32+32, 
							 ANSI_VAR_FONT);						       
}      	    




void RemplirGrild(uchar BitGrild[], uchar ImageData[32][32])
{
	
	int x;
	int y;
	int x2;
	int y2;

	for (y=0; y<32; y++)
	{
	  for (x=0; x<32; x++)
	  {
		  if (ImageData[y][x])
		  {
		    for (y2=0; y2<7; y2++)
		    {
			  for (x2=0; x2<7; x2++)
			  {
				  BitGrild[(y*8*32*8)+ 
					       (y2 * 8*32)+ 
						   (x *8)+x2] =

				  (ImageData[y][x]);
			  }
		    }
		  }
		  else
		    for (y2=0; y2<7; y2++)
		    {
			  for (x2=0; x2<7; x2++)
			  {
				  if (x2>=4&& x2<=5 && y2>=4 && y2<=5)
				  BitGrild[(y*8*32*8)+ 
					       (y2 * 8*32)+ 
						   (x *8)+x2] =148;
				  else
				  BitGrild[(y*8*32*8)+ 
					       (y2 * 8*32)+ 
						   (x *8)+x2] =

				  (ImageData[y][x]);
			  }
		    }


	  }
	}


}





void DrawOnGrild(char color, HWND hwnd)
{
	    if ((mouse.y/8<32) && (mouse.x/8<32))
			{	current_mcx->ImageData[mouse.y/8]
                [mouse.x/8]	 = color ;
										
						
		       RemplirGrild(BitGrild, current_mcx->ImageData);
               InvalidateRect (hwnd, NULL, FALSE) ;

					
				if (!HasChanged){	HasChanged=TRUE;
					       DoCaptionL (hAppWnd);}

		}

}


//**********************************************************************************
//
// ChildWndProc : This is the message handler to the Child PopUp Window
//                The Color Palette Window Proc handler
//
//*********************************************************************************
LRESULT CALLBACK EditGrildWndProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{        
PAINTSTRUCT ps ;
    HDC         hdc ;
	//static char bitPalette[16*16*16*14];
	BOOL fAppActive;

	int cpt;
	static HWND hwndButton[2];
	static action  = action_draw;

struct 
{
	   int x;
	   int y;
	   int len;
	   int hei;
	   char *text ;
}
static buttons [] =
{
8*32+8, 8*16+32, 32,16,"<<",
8*32+8+32+32, 8*16+32, 32,16,">>"
} ;
	

		switch (iMsg)
		{
        case WM_CLOSE :
            SendMessage(hAppWnd, iMsg,wParam, lParam);
        return 0 ;



		case WM_COMMAND:

			switch( LOWORD(wParam) )
			{
			
			case 0:
				SendMessage(hAppWnd, WM_COMMAND, ID_IMAGE_PRECEDENTE, 0L);

  			break;

			case 1:
				SendMessage(hAppWnd, WM_COMMAND, ID_IMAGE_SUIVANTE, 0L);
			break;

			}

			
		break;

		case WM_ACTIVATEAPP:

            fAppActive = (BOOL)wParam;

        //*** Remap the system colors and deal with the palette
               
           //AppActivate(fAppActive);
           AppActivate(FALSE);
           if (hpal)
           {
            hdc = GetDC(hwnd);

            UnrealizeObject(hpal);
            SelectPalette(hdc, hpal, FALSE);
            RealizePalette(hdc);
            ReleaseDC(hwnd, hdc);
           }
        
           break;
	
		        case WM_CREATE :

				if (hpal)
				{
         		    /*
					hdc = GetDC(hwnd);

					UnrealizeObject(hpal);
					SelectPalette(hdc, hpal, FALSE);
					RealizePalette(hdc);				
					
					ReleaseDC(hwnd, hdc);
 			     //   FillbitPalette(bitPalette);
                    */
					InitEditor(BitGrild, NULL);
	
					mouse.last_x=-1;
					mouse.last_y=-1;
					mouse.x=-1;
					mouse.y=-1;

					NewFile();
                    
					for (cpt=0; cpt<2	; cpt++)
						hwndButton[cpt] = 
						CreateWindow ("button",
									  buttons[cpt].text,
									  WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
									  buttons[cpt].x, buttons[cpt].y,
									  buttons[cpt].len,
									  buttons[cpt].hei, hwnd, (HMENU) cpt,
									  hAppInstance, NULL);



				}
				return 0 ;

		case WM_LBUTTONDOWN:
               if (wParam & MK_LBUTTON || wParam & MK_RBUTTON)
               {
                   
                	mouse.last_x= mouse.x;
					mouse.last_y= mouse.y;
		            mouse.button = wParam;
                    mouse.x = LOWORD (lParam) ;
                    mouse.y = HIWORD (lParam) ;
		

					if (mouse.button==MK_LBUTTON)
						DrawOnGrild(PenColor, hwnd);

					if (mouse.button==MK_RBUTTON)
						DrawOnGrild(0,hwnd);




			}                    

			
			return 0;

		case WM_MOUSEMOVE:
               if (wParam & MK_LBUTTON || wParam & MK_RBUTTON)
               {
                   
                	mouse.last_x= mouse.x;
					mouse.last_y= mouse.y;
		            mouse.button = wParam;
                    mouse.x = LOWORD (lParam) ;
                    mouse.y = HIWORD (lParam) ;
		

					if (mouse.button==MK_LBUTTON)
						DrawOnGrild(PenColor, hwnd);

					if (mouse.button==MK_RBUTTON)
						DrawOnGrild(0, hwnd);
			}                    
               return 0 ;


				case WM_PAINT :
			  		hdc = BeginPaint(hwnd,&ps);
					PeinturerFenetre(hdc, BitGrild);
       				EndPaint(hwnd,&ps);
				return 0L;

 
	
		}
         return DefWindowProc (hwnd, iMsg, wParam, lParam) ;

	}        


