
//
// DRAW.C
//

#include "draw.h"

char        extern  MSDOS_PAL[];
USER_WINPAL extern  PalColors[256];
int         extern  MSDOS_PAL16[256];
USER_24bpp  extern  MSDOS_PAL24[256];
int         extern  MSDOS_PAL32[256];                

// ***********************************************************
//
// void PutBitmap(HDC hdc, HBITMAP hBitmap,int xStart,int yStart);
// Example of how to draw a bitmap.
//
// PURPOSE: Give a tangible example of how to draw bitmap onto
// the screen.
//
// ***********************************************************
void PutBitmap(HDC hdc, 
				HBITMAP hBitmap,
				int xStart,
				int yStart)
{

	BITMAP	bm;
	HDC		hdcMem;
	POINT   ptSize, ptOrg;
    HBITMAP hOldBitmap;

	hdcMem = CreateCompatibleDC(hdc);

	hOldBitmap =SelectObject (hdcMem, hBitmap);
	SetMapMode(hdcMem, GetMapMode(hdc));

	GetObject(hBitmap, sizeof (BITMAP), (LPVOID) &bm);

	ptSize.x= bm.bmWidth;
	ptSize.y= bm.bmHeight;

	ptOrg.x= 0;
	ptOrg.y= 0;

	BitBlt(hdc, xStart, yStart, ptSize.x, ptSize.y,
		   hdcMem, ptOrg.x, ptOrg.y, SRCCOPY);


	SelectObject (hdcMem, hOldBitmap);

	DeleteDC(hdcMem);
}


// ***********************************************************
//
// void PutIcon(HDC hdc, HICON hicon,int xStart,int yStart);
// Example of how to draw an Icon 
//
// PURPOSE: Give a tangible example of how to draw an icon onto
// the screen.
//
// ***********************************************************

void PutIcon(HDC hDC,HICON hicon, int x, int y)
{
    
	HDC hMemDC;
	HICON name=  hicon;

    hMemDC = CreateCompatibleDC(hDC);
    SelectObject(hMemDC, name);
    DrawIcon (hDC,x,y,name);
    DeleteDC(hMemDC);
}

//
// void PutText(.......);
//

void PutText(HDC hdc, 
			 char * Text,
			 int x,
			 int y,
			 int Font)
{
    SelectObject(hdc,GetStockObject(Font));
    TextOut(hdc, x, y, Text, strlen(Text));
}

//
// void DrawUserRect (HDC hdc, USER_RECT user_rect);
//

void DrawUserRect (HDC hdc, USER_RECT user_rect)
     {
     HBRUSH hBrush ;
     RECT   rect ;

     SetRect (&rect, user_rect.x1, user_rect.y1, 
		             user_rect.x2, user_rect.y2)  ;

     hBrush = CreateSolidBrush (RGB (  user_rect.color.red,
                                       user_rect.color.green,
									   user_rect.color.blue
								)) ;


     FillRect (hdc, &rect, hBrush) ;


     DeleteObject (hBrush) ;
     }     


//
//  MakeBitmap
//

HBITMAP MakeBitmap(int len, int hei, unsigned char *bits, HDC hdc)
{

    

    int lplanes;
    int lbpp;

    //char        *ptrData;
    short       *ptrIData;
    int         *ptrData32;
    USER_24bpp  *ptrData24;
    char        *ptr;
    char        *ptrABC;
    int         cpt;
    int         *ptrPal;


    unsigned static char color;
    unsigned static short icolor;
                    
    unsigned static char red;
    unsigned static char green;
    unsigned static char blue;


    HBITMAP hbitmap=NULL;

    if ((len==0) || (hei==0))
        return NULL;

    lplanes = GetDeviceCaps(hdc, PLANES);
    lbpp = GetDeviceCaps(hdc, BITSPIXEL);
     
    switch (lbpp)
    {

        case 8:
            hbitmap =  CreateBitmap(len,hei,lplanes,lbpp, bits);
            return hbitmap;
        break;

        case 16:
            ptrIData =  malloc(len*hei*2);    
            ptr = (char *) ptrIData;

            ptrPal = &MSDOS_PAL16[0];

            cpt = len*hei/4;
            __asm
            {

                push eax
                push ebx            
                push ecx
                push edx
                push edi
                push esi
               
                mov ecx, cpt
                mov esi, bits
                mov edi, ptrIData
                mov ebx, ptrPal

again:

                xor eax,eax
                //mov al, [esi]
                mov edx, [esi]
//                              
                or edx,edx
                jne NotBlack

                mov [edi], eax
                inc edi
                inc edi
                inc edi
                inc edi

                mov [edi], eax
                inc edi
                inc edi
                inc edi
                inc edi
                
                inc esi
                inc esi
                inc esi
                inc esi
                jmp LoopNext

NotBlack:

                mov al,dl
                or al,al 
                je EqualZero                             

                sub al,16                
               
                shl eax,2        

                mov ax, [ebx+eax]
EqualZero:
                mov [edi], ax
                inc edi
                inc edi

//
                xor eax,eax
                mov al,dh
                or al,al 
                je EqualZero2

                sub al,16                
               
                shl eax,2        

                mov ax, [ebx+eax]
EqualZero2:
                mov [edi], ax
                inc edi
                inc edi



//
                sub eax,eax    
                shr edx,16
                mov al,dl
                or al,al 
                je EqualZero3

                sub al,16                
               
                shl eax,2        

                mov ax, [ebx+eax]
EqualZero3:
                mov [edi], ax
                inc edi
                inc edi

//

                sub eax,eax
                mov al,dh
                or al,al 
                je EqualZero4                             

                sub al,16                
               
                shl eax,2        

                mov ax, [ebx+eax]
EqualZero4:
                mov [edi], ax
                inc edi
                inc edi

                inc esi
                inc esi
                inc esi
                inc esi


LoopNext:
                dec ecx
                or ecx,ecx
                jne again


                pop esi
                pop edi
                pop edx
                pop ecx
                pop ebx
                pop eax
            }

            hbitmap =  CreateBitmap(len,hei,lplanes,lbpp,ptr);
            free(ptr);

            return hbitmap;
        break;

        case 24:

            ptrData24 =  malloc(len*hei*lbpp/8);    
            ptr = (char *)ptrData24;
            for (cpt = len*hei; cpt; cpt--)
            {

                color=0;
                if ((*bits <16) && (*bits!=0)) color = 134    ;
                else color = (*bits) -16;

                ptrABC = (char *) &MSDOS_PAL24[color];
                __asm 
                {
                    push ax
                    push esi
                    push edi

                    mov edi, ptrData24
                    mov esi, ptrABC
                    mov al, [esi]
                    mov [edi],al

                    mov al, [esi+1]
                    mov [edi+1],al

                    mov al, [esi+2]
                    mov [edi+2],al

                    pop edi
                    pop esi
                    pop ax
                }



                ptrData24++;
                bits++;
             }

            hbitmap =  CreateBitmap(len,hei,lplanes,lbpp,ptr);
            free(ptr);
            return hbitmap;
        break;

       case 32:

            ptrData32 =  malloc(len*hei*lbpp/8);    
            ptr = (char *) ptrData32;

            ptrPal = &MSDOS_PAL32[0];

            cpt = len*hei/4;

            __asm 
            {         
            
                push eax
                push ebx            
                push ecx
                push edx
                push edi
                push esi
               
                mov ecx, cpt
                mov esi, bits
                mov edi, ptrData32
                mov ebx, ptrPal


again32:
                mov edx, [esi]

                or edx,edx
                jne NotNULL32

             
                mov eax,edx
                mov [edi],eax
                inc edi
                inc edi
                inc edi
                inc edi
                mov [edi],eax
                inc edi
                inc edi
                inc edi
                inc edi
                mov [edi],eax
                inc edi
                inc edi
                inc edi
                inc edi
                mov [edi],eax
                inc edi
                inc edi
                inc edi
                inc edi

                inc esi
                inc esi
                inc esi
                inc esi
                
                jmp LoopNext32  



NotNULL32:

//              1st byte .......................
                xor eax,eax
                mov al,dl
                or al,al 
                je EqualZ32

                sub al,16                
               
                shl eax,2        

                mov eax, [ebx+eax]
EqualZ32:
                mov [edi], eax
                inc edi
                inc edi
                inc edi
                inc edi


//              2nd byte ........................
                xor eax,eax
                mov al,dh
                or al,al 
                je EqualZ32ii

                sub al,16                
               
                shl eax,2        

                mov eax, [ebx+eax]
EqualZ32ii:
                mov [edi], eax
                inc edi
                inc edi
                inc edi
                inc edi

//              3rd byte ........................
                shr edx,16
                xor eax,eax
                mov al,dl
                or al,al 
                je EqualZ32iii

                sub al,16                
               
                shl eax,2        

                mov eax, [ebx+eax]
EqualZ32iii:
                mov [edi], eax
                inc edi
                inc edi
                inc edi
                inc edi

//              4th byte ........................
                xor eax,eax
                mov al,dh
                or al,al 
                je EqualZ32iv

                sub al,16                
               
                shl eax,2        

                mov eax, [ebx+eax]
EqualZ32iv:
                mov [edi], eax
                inc edi
                inc edi
                inc edi
                inc edi

//              inc source reg. ...................

                inc esi
                inc esi
                inc esi
                inc esi


LoopNext32:
                dec ecx
                or ecx,ecx
                jne again32
             

                pop esi
                pop edi
                pop edx
                pop ecx
                pop ebx
                pop eax
            }


            hbitmap =  CreateBitmap(len,hei,lplanes,lbpp,ptr);
            free(ptr);
            return hbitmap;
        break;

    }
   

    return NULL;
}
