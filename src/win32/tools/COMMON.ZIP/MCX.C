//
// MCX.C
//

#include "mcx.h"

int MCXFormatId;

void ClearMCX(USER_MCX *mcx)
{

	int x,y;
	
	for (y=0; y<32; y++)
		for (x=0; x<32;x++)
		   (mcx->ImageData[y][x]) = 0;

	
}

int LoadMCX(const char *filename, USER_MCXHEADER *header)
{
	FILE *sfile;
	int cpt;
	int first= TRUE;
	USER_MCX *now;
	USER_MCX *prev;
	char Id[4] = "GE96";
	
	sfile = fopen (filename, "rb");

	if (sfile==NULL) 
		return(err_fileopen);

	for (cpt=0; cpt<4; cpt++)
		header->Id[cpt]= 0;
	
	fread(header, sizeof(USER_MCXHEADER), 1, sfile);
	
	for (cpt=0; cpt<4; cpt++)
		if (header->Id[cpt]!= Id[cpt]) return (err_format);
	
	cpt = header->NbrImages;

	if (header->Class>13) header->Class=0;

	for (;cpt;cpt--)
	{
		if (first)
		{
			first = FALSE;			
			now = malloc(sizeof(USER_MCX));
			if (now==NULL) {fclose(sfile);return(err_memory);}
			fread(now, sizeof(USER_MCX), 1, sfile);
			header->PtrFirst = now;
			now ->PtrPrev = NULL;
			prev = now;

		}
		else
		{
			now = malloc(sizeof(USER_MCX));
			if (now==NULL) {fclose(sfile);return(err_memory);}
			fread(now, sizeof(USER_MCX), 1, sfile);
			prev -> PtrNext = now;		// now suivant de prev
			now  -> PtrPrev = prev;      // prev pr�c�dent de now			
			prev = now;					

		}
	}

	if (first)
		header->PtrFirst = NULL;
	else
		now -> PtrNext = NULL;

	fclose(sfile);
	return(1);
}


int SaveMCX(const char *filename, USER_MCXHEADER *header)
{
	FILE *sfile;
	int cpt;
	USER_MCX *now;
	
	sfile = fopen (filename, "wb");

	if (sfile==NULL) 
		return(err_fileopen);

	fwrite(header, sizeof(USER_MCXHEADER), 1, sfile);
	cpt = header->NbrImages;
	now = header-> PtrFirst;

	for (;cpt;cpt--)
	{
		fwrite(now, sizeof(USER_MCX), 1, sfile);
		now = now ->PtrNext;
	}

	fclose(sfile);

	return(1);
}

void FreeMCX(USER_MCXHEADER *header)
{
	USER_MCX *temp;
	USER_MCX *old;

    temp = header->PtrFirst;
    while (temp!=NULL)
	{
	     old = temp;
		 temp = temp->PtrNext;
		 free(old);
	}
	header->PtrFirst = NULL;
	header->NbrImages = 0;
	header->LastViewed = 0;
	*header->Name=0;
}
