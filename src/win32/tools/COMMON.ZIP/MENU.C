
//
// menu.c
//

#include "menu.h"

// ***********************************************************
//
// MenuCheckMark 
// PURPOSE: WIll check or uncheck a menu item.
//
// ***********************************************************

void MenuCheckMark (HMENU hmenu, int id, BOOL bCheck)
     {
     int iState ;
     iState = (bCheck) ? MF_CHECKED : MF_UNCHECKED ;
     CheckMenuItem (hmenu, id, iState) ;
     }


// ***********************************************************
//
// BOOL Menu_EnableItem(HMENU hmenu, int id, BOOL bEnabled)
//
// ***********************************************************

BOOL Menu_EnableItem(HMENU hmenu, int id, BOOL bEnabled)
{

    int flags;
    flags = (bEnabled) ? MF_ENABLED : MF_DISABLED | MF_GRAYED;
    return EnableMenuItem (hmenu, id, flags);
}

