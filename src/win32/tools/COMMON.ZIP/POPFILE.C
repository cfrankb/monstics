/*------------------------------------------

  
	POPFILE.C -- Popup Editor File Functions
  
	
	  ------------------------------------------*/

#include "popfile.h"

static OPENFILENAME ofn ;

void PopFileInitialize (HWND hwnd, char *szFilter)
     {

     ofn.lStructSize       = sizeof (OPENFILENAME) ;
     ofn.hwndOwner         = hwnd ;
     ofn.hInstance         = NULL ;
     ofn.lpstrFilter       = szFilter ;
     ofn.lpstrCustomFilter = NULL ;
     ofn.nMaxCustFilter    = 0 ;
     ofn.nFilterIndex      = 0 ;
     ofn.lpstrFile         = NULL ;          // Set in Open and Close functions
     ofn.nMaxFile          = _MAX_PATH ;
     ofn.lpstrFileTitle    = NULL ;          // Set in Open and Close functions
     ofn.nMaxFileTitle     = _MAX_FNAME + _MAX_EXT ;
     ofn.lpstrInitialDir   = NULL ;
     ofn.lpstrTitle        = NULL ;
     ofn.Flags             = 0 ;             // Set in Open and Close functions
     ofn.nFileOffset       = 0 ;
     ofn.nFileExtension    = 0 ;
     ofn.lpstrDefExt       = "ima" ;
     ofn.lCustData         = 0L ;
     ofn.lpfnHook          = NULL ;
     ofn.lpTemplateName    = NULL ;
     }

BOOL PopFileOpenDlg (HWND hwnd, PSTR pstrFileName, PSTR pstrTitleName)
     {
     ofn.hwndOwner         = hwnd ;
     ofn.lpstrFile         = pstrFileName ;
     ofn.lpstrFileTitle    = pstrTitleName ;
     ofn.Flags             = OFN_HIDEREADONLY | OFN_PATHMUSTEXIST
                                     | OFN_FILEMUSTEXIST 
                                     | OFN_HIDEREADONLY; 
; // | OFN_CREATEPROMPT ;

     return GetOpenFileName (&ofn) ;
     }

BOOL PopFileSaveDlg (HWND hwnd, PSTR pstrFileName, PSTR pstrTitleName)
     {
     ofn.hwndOwner         = hwnd ;
     ofn.lpstrFile         = pstrFileName ;
     ofn.lpstrFileTitle    = pstrTitleName ;
     ofn.Flags             = OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY;

     return GetSaveFileName (&ofn) ;
     }

//
//
//

BOOL MultiSelectDialog(HWND hwnd, 
                       char *szFilter,
                       char *pstrFileName,
                       char *pstrTitleName,
                       int iStrSize)
{

    static OPENFILENAME ofn ;
    BOOL bStatus;

     ofn.lStructSize       = sizeof (OPENFILENAME) ;
     ofn.hwndOwner         = hwnd ;
     ofn.hInstance         = NULL ;
     ofn.lpstrFilter       = szFilter ;
     ofn.lpstrCustomFilter = NULL ;
     ofn.nMaxCustFilter    = 0 ;
     ofn.nFilterIndex      = 0 ;
     ofn.lpstrFile         = NULL ;          // Set in Open and Close functions
     ofn.nMaxFile          = iStrSize ;
     ofn.lpstrFileTitle    = NULL ;          // Set in Open and Close functions
     ofn.nMaxFileTitle     = iStrSize ;
     ofn.lpstrInitialDir   = NULL ;
     ofn.lpstrTitle        = pstrTitleName ;
     ofn.Flags             = 0 ;             // Set in Open and Close functions
     ofn.nFileOffset       = 0 ;
     ofn.nFileExtension    = 0 ;
     ofn.lpstrDefExt       = "ima" ;
     ofn.lCustData         = 0L ;
     ofn.lpfnHook          = NULL ;
     ofn.lpTemplateName    = NULL ;

     ofn.lpstrFile         = pstrFileName ;
     ofn.lpstrFileTitle    = NULL ;
     ofn.Flags             =           OFN_PATHMUSTEXIST
                                     | OFN_FILEMUSTEXIST 
                                     | OFN_HIDEREADONLY
                                     | OFN_ALLOWMULTISELECT
                                     | OFN_EXPLORER; 

     bStatus = GetOpenFileName (&ofn) ;
     return bStatus;


}





