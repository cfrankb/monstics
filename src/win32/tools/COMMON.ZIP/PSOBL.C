
//
// PsObl.c
//

#include "dialog.h"
#include "include.h"
#include "struc.h"
#include "gadgets.h"
#include "resource.h"
#include "common.h"
#include "WinEasy.h"
#include "comcthlp.h"
#include "obl3.h" 
#include "psobl.h"
#include "class97.h"
#include "sdx.h"
#include "user_msg.h"

USER_OBL3HEADER sgOBL3;
USER_SDI3 sgSDI3;
int bHasSdx = FALSE;
int igEvent; 

begin_struct
    int     iIde;
    int     iIds;
    WORD    wMin;
    WORD    wMax;    
end_struct(USER_ITEMINFO);

USER_ITEMINFO sSpins[] =
    {

        IDC_EREBIRTHTIME,//0
        IDC_SREBIRTHTIME, 0, 0x7fff,        
        IDC_EJUMP,      //1
        IDC_SJUMP,0, 0x7fff,
        IDC_EFIRERATE,  //2
        IDC_SFIRERATE,  0, 0x7fff,
        IDC_ELIFEFORCE, //3
        IDC_SLIFEFORCE, 0, 0x7fff,

        IDC_ELIVES,     //4
        IDC_SLIVES,  0, 0x7fff,
        IDC_EOXYGEN,    //5
        IDC_SOXYGEN,  0, 0x7fff,
        IDC_EMOVE,      //6
        IDC_SMOVE,  0, 0x7fff,
        IDC_EFALL,      //7
        IDC_SFALL,  0, 0x7fff,
        
        IDC_EASPEED,    //8
        IDC_SASPEED,  0, 0x7fff,
        IDC_ETIMEOUT,   //9
        IDC_STIMEOUT,  0, 0x7fff,
        IDC_EDOMAGES,   //10
        IDC_SDOMAGES,  0, 0x7fff,

        IDC_EIMAGE,     //11
        IDC_SIMAGE,0,0,

        IDC_EU1,        //12
        IDC_SU1,0,0x7fff,

        IDC_EU2,        //13
        IDC_SU2,0,0x7fff,

        IDC_ELEN,
        IDC_SLEN, 1, 64,

        IDC_EHEI,
        IDC_SLEN, 1, 64,

        IDC_EBIG,
        IDC_SBIG, 2,4,

        IDC_EPOINTS, 
        IDC_SPOINTS, 0, 0x7fff,


        0,0,0,0
    };


//
//
//


void InitBiggerPage(HWND hDlg) 
{

    int cpt;
    char sz[256];

    for (cpt=0; sSpins[cpt].iIds; cpt++)
    {
        UpDown_SetRange(
            GetHandle (hDlg, sSpins[cpt].iIds),
                sSpins[cpt].wMin, sSpins[cpt].wMax);
    }

    sprintf(sz, "%d",2);     
    Edit_SetText(GetHandle(hDlg,IDC_EBIG), sz);

};


void SaveBiggerPage(HWND hDlg) 
{

 // BOOL bError;
 // DWORD iLen;
 // DWORD iHei;
       
/* iLen= GetDlgItemInt(hDlg, 
                      IDC_ELEN,
                      &bError,
                      FALSE);


    iHei= GetDlgItemInt(hDlg, 
                      IDC_EHEI,
                      &bError,
                      FALSE);


    if ((iLen!=sgOBL3.iLen) |
        (iHei!=sgOBL3.iHei))
    {

        if ( WarningDialog(hDlg, 
           "Modifier la taille des images peut avoir des r�percusions importantes.", 
           "Continuer ?") == IDOK)
        {

            sgOBL3.iLen = iLen;
            sgOBL3.iHei = iHei;

        }

    }*/
};


//
//
//


BOOL CALLBACK ImageBiggerDialogProc(
                         HWND   hDlg,	
                         UINT   iMsg,	 
                         WPARAM wParam, 
                         LPARAM lParam )
{

    HWND hCtrl;
    static int iId;
    static char sz[256];
    static char sz2[256];
    static int cpt;
    static int iVal;

    static BOOL bModif = FALSE;


     switch (iMsg)
          {


            case EN_CHANGE:

                    iId = LOWORD(wParam);
                    hCtrl = (HWND) GetHandle(hDlg,iId);

                    if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);


                    Edit_GetText(hCtrl, sz, 254);
                    iVal = str2int(sz, sz2);
            
                    for (cpt=0; sSpins[cpt].iIde; cpt++)
                    {

                        if (sSpins[cpt].iIde==iId)
                        {
                            if (iVal<sSpins[cpt].wMin)
                            {
                               
                                wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMin); 
                                Edit_SetText(hCtrl,sz);
                                break;


                            }


                            if (iVal>sSpins[cpt].wMax) 
                            {

                                
                                wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMax); 
                                Edit_SetText(hCtrl,sz);



                            }
                            else
                            {
                                if (strlen(sz) > 
                                    strlen(sz2) )
                                    Edit_SetText(hCtrl,sz2);
                            }
                        

                            break;
                        }

                    }
                
                
            break;


            

          case WM_INITDIALOG :


              bModif = FALSE;
              InitBiggerPage(hDlg);             
              bModif = TRUE;

               return TRUE ;

          case WM_COMMAND :
               switch (LOWORD (wParam))
                    {
		            case IDOK :
                        SaveBiggerPage(hDlg);

		            case IDCANCEL :
			        case IDNO :
                           EndDialog (hDlg, 
			   	                   LOWORD 
				                  (wParam)) ;
			         return TRUE ;
                    }
               break ;
          }
     return FALSE ;
     }


//
//
//


BOOL CALLBACK ImageSizeDialogProc(HWND  hDlg,	
                         UINT  iMsg,	 
                         WPARAM  wParam, 
                         LPARAM  lParam )
{

    HWND hCtrl;
    static int iId;
    static char sz[256];
    static char sz2[256];
    static int cpt;
    static int iVal;

    static BOOL bModif = FALSE;


     switch (iMsg)
          {


            case EN_CHANGE:

                    iId = LOWORD(wParam);
                    hCtrl = (HWND) GetHandle(hDlg,iId);

                    if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);


                    Edit_GetText(hCtrl, sz, 254);
                    iVal = str2int(sz, sz2);
            
                    for (cpt=0; sSpins[cpt].iIde; cpt++)
                    {

                        if (sSpins[cpt].iIde==iId)
                        {
                            if (iVal<sSpins[cpt].wMin)
                            {
                               
                                wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMin); 
                                Edit_SetText(hCtrl,sz);
                                break;


                            }


                            if (iVal>sSpins[cpt].wMax) 
                            {

                                
                                wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMax); 
                                Edit_SetText(hCtrl,sz);



                            }
                            else
                            {
                                if (strlen(sz) > 
                                    strlen(sz2) )
                                    Edit_SetText(hCtrl,sz2);
                            }
                        

                            break;
                        }

                    }
                
                
            break;


            

          case WM_INITDIALOG :


              bModif = FALSE;
              InitPage3(hDlg);             
              bModif = TRUE;

               return TRUE ;

          case WM_COMMAND :
               switch (LOWORD (wParam))
                    {
		            case IDOK :
                        SavePage3(hDlg);

		            case IDCANCEL :
			        case IDNO :
                           EndDialog (hDlg, 
			   	                   LOWORD 
				                  (wParam)) ;
			         return TRUE ;
                    }
               break ;
          }
     return FALSE ;
     }


//
//
//


int str2int(char *szS, char *szD)
{
    int iVal=0;
    char *szDD = szD;
    char *szSS = szS;

    for (;(*szS>='0') && (*szS<='9');szS++, szD++)    
        *szD= *szS;

    *szD =0; szD = szDD;

    for (; *szD ; szD++)
        iVal = 10*iVal + *szD - '0';

    if (strlen(szDD)==0) 
    { strcpy(szDD, "0");
      strcpy(szSS,"00");
    }

    return iVal ;

}

void InitPage3(HWND hDlg) 
{

    int cpt;
    char sz[256];

    BYTE iTemp;

    for (cpt=0; sSpins[cpt].iIds; cpt++)
    {
        UpDown_SetRange(
            GetHandle (hDlg, sSpins[cpt].iIds),
                sSpins[cpt].wMin, sSpins[cpt].wMax);
    }


    sprintf(sz, "%d",sgOBL3.iLen);     
    Edit_SetText(GetHandle(hDlg, IDC_ELEN), sz);
    sprintf(sz, "%d",sgOBL3.iHei);     
    Edit_SetText(GetHandle(hDlg, IDC_EHEI), sz);

    if (bHasSdx)
    {
        Edit_Enable(GetHandle(hDlg, IDC_ELEN), FALSE);
        Edit_Enable(GetHandle(hDlg, IDC_EHEI), FALSE);
        Edit_Enable(GetHandle(hDlg, IDC_SLEN), FALSE);
        Edit_Enable(GetHandle(hDlg, IDC_SHEI), FALSE);
    }


    // InitCheckBoxs
    iTemp = sgOBL3.bCompilerOptions;
    for (cpt=0; cpt<8; cpt++)
    {
        Button_SetCheck(
            GetHandle(hDlg, IDC_C1+cpt),
            iTemp &1
            );

        iTemp = iTemp /2;
    }


};

void SavePage3(HWND hDlg) 
{

    BOOL bError;
    DWORD iLen;
    DWORD iHei;
    BYTE iTemp;
    BYTE iVal;
    int cpt;
    
       
    iLen= GetDlgItemInt(hDlg, 
                      IDC_ELEN,
                      &bError,
                      FALSE);


    iHei= GetDlgItemInt(hDlg, 
                      IDC_EHEI,
                      &bError,
                      FALSE);



    // Save all 8 checkboxes
    // (even if I don't know what they do, anyway)
    iVal = 1;
    iTemp =0;
    for (cpt=0; cpt<16; cpt++)
    {

        iTemp = iTemp +
            Button_GetCheck(GetHandle(hDlg, IDC_C1+cpt))*iVal; 

        iVal = iVal+ iVal;
    }

    sgOBL3.bCompilerOptions = iTemp;


    // Check len & hei and warns if applicable

    if (bHasSdx) // if Sdx don't bother, Combos are locked...
        return;
    if ((iLen!=sgOBL3.iLen) |
        (iHei!=sgOBL3.iHei))
    {

        if ( WarningDialog(hDlg, 
           "Modifier la taille des images peut avoir des r�percusions importantes.", 
           "Continuer ?") == IDOK)
        {

            sgOBL3.iLen = iLen;
            sgOBL3.iHei = iHei;

        }

    }




};



void SavePage2(HWND hDlg)
{

    BOOL bError;
    UINT iTemp;

    //
    Edit_GetText(
        GetHandle(hDlg,IDC_ENAME) ,
        sgOBL3.szName
        , 62);  
        
    //
    iTemp =
    GetDlgItemInt(hDlg,
                IDC_EREBIRTHTIME,
                &bError,
                FALSE);
    sgOBL3.wRebirthTime = iTemp;
       

    //
    iTemp =
    GetDlgItemInt(hDlg,
                IDC_EJUMP,
                &bError,
                FALSE);
    sgOBL3.wMaxJump = iTemp;

    //

    iTemp =
    GetDlgItemInt(hDlg,
                IDC_EFIRERATE,
                &bError,
                FALSE);
    sgOBL3.wFireRate = iTemp;

    //
    iTemp =
    GetDlgItemInt(hDlg,
                IDC_ELIFEFORCE,
                &bError,
                FALSE);
    sgOBL3.wLifeForce  = iTemp;

    //
    iTemp =
    GetDlgItemInt(hDlg,
                IDC_ELIVES,
                &bError,
                FALSE);
    sgOBL3.wLives = iTemp;

    //
    iTemp =
    GetDlgItemInt(hDlg,
                IDC_EOXYGEN,
                &bError,
                FALSE);
    sgOBL3.wOxygen = iTemp;

    //
    iTemp =
    GetDlgItemInt(hDlg,
                IDC_EMOVE,
                &bError,
                FALSE);
    sgOBL3.wSpeed = iTemp;

    //
    iTemp =
    GetDlgItemInt(hDlg,
                IDC_EFALL,
                &bError,
                FALSE);
    sgOBL3.wFallSpeed = iTemp;

    //
    iTemp =
    GetDlgItemInt(hDlg,
                IDC_EASPEED,
                &bError,
                FALSE);
    sgOBL3.wAniSpeed = iTemp;

    //
    iTemp =
    GetDlgItemInt(hDlg,
                IDC_ETIMEOUT,
                &bError,
                FALSE);
    sgOBL3.wTimeOut = iTemp;

    //
    iTemp =
    GetDlgItemInt(hDlg,
                IDC_EDOMAGES,
                &bError,
                FALSE);
    sgOBL3.wDomages = iTemp;

    sgOBL3.bItemProps = 
        1 * Button_GetCheck(GetHandle(hDlg, IDC_CSOLID)) |
        2 * Button_GetCheck(GetHandle(hDlg, IDC_CDEADLY)) |
        4 * Button_GetCheck(GetHandle(hDlg, IDC_CKILLPLAYER)) |
        8 * Button_GetCheck(GetHandle(hDlg, IDC_CKILLBYLAVA)) |
       16 * Button_GetCheck(GetHandle(hDlg, IDC_CKILLBYWATER)) |
       32 * Button_GetCheck(GetHandle(hDlg, IDC_CGRAVITY)) |
       64 * Button_GetCheck(GetHandle(hDlg, IDC_CJUMP)) |
      128 * Button_GetCheck(GetHandle(hDlg, IDC_CSWIM)) ;

}



void InitPage2(HWND hDlg)
{

    char sz[200];  
    int cpt;
    int iTemp;

    int iButtons[] =
    {                    
        IDC_CSOLID,
        IDC_CDEADLY,
        IDC_CKILLPLAYER,
        IDC_CKILLBYLAVA,
        IDC_CKILLBYWATER,
        IDC_CGRAVITY,
        IDC_CJUMP,
        IDC_CSWIM
    };


    for (cpt=0; cpt<7; cpt++)
    {
        UpDown_SetRange(
            GetHandle (hDlg, sSpins[cpt].iIds),
                sSpins[cpt].wMin, sSpins[cpt].wMax);
    }


    iTemp = sgOBL3.bItemProps;
    for (cpt=0; cpt<8; cpt++)
    {
        Button_SetCheck(
            GetHandle(hDlg, iButtons[cpt]),
            iTemp &1
            );

        iTemp = iTemp /2;
    }

    sprintf(sz, "%d",sgOBL3.wRebirthTime);     
    Edit_SetText(GetHandle(hDlg, IDC_EREBIRTHTIME), sz);

    sprintf(sz, "%d",sgOBL3.wMaxJump);     
    Edit_SetText(GetHandle(hDlg, IDC_EJUMP), sz);
       
    sprintf(sz, "%d",sgOBL3.wFireRate);     
    Edit_SetText(GetHandle(hDlg,IDC_EFIRERATE ), sz);
    
    sprintf(sz, "%d",sgOBL3.wLifeForce);     
    Edit_SetText(GetHandle(hDlg, IDC_ELIFEFORCE), sz);
    
    sprintf(sz, "%d",sgOBL3.wLives);     
    Edit_SetText(GetHandle(hDlg, IDC_ELIVES), sz);
    
    sprintf(sz, "%d",sgOBL3.wOxygen);     
    Edit_SetText(GetHandle(hDlg, IDC_EOXYGEN), sz);
    
    sprintf(sz, "%d",sgOBL3.wSpeed);     
    Edit_SetText(GetHandle(hDlg, IDC_EMOVE), sz);
    
    sprintf(sz, "%d",sgOBL3.wFallSpeed);     
    Edit_SetText(GetHandle(hDlg, IDC_EFALL), sz);
    
    sprintf(sz, "%d",sgOBL3.wAniSpeed);     
    Edit_SetText(GetHandle(hDlg, IDC_EASPEED), sz);

    sprintf(sz, "%d",sgOBL3.wTimeOut);     
    Edit_SetText(GetHandle(hDlg, IDC_ETIMEOUT), sz);

    sprintf(sz, "%d",sgOBL3.wDomages);     
    Edit_SetText(GetHandle(hDlg, IDC_EDOMAGES), sz);

    Edit_SetText(GetHandle(hDlg, IDC_ENAME),
                sgOBL3.szName) ;
    
}

void SavePage1(HWND hDlg)
{

    BOOL bError;

    char sz[200];

    // Save Class
    ComboBox_GetText(GetHandle(hDlg,IDC_DC_CLASS),
                 sz,
                 199);
    sgOBL3.bClassInfo = GetId(sOblClass, sz);

    // Save ShowAs
    ComboBox_GetText(GetHandle(hDlg,IDC_DC_SHOWAS),
                 sz,
                 199);
    sgOBL3.bDisplayInfo = GetId(sOblShowAs, sz);

    // Save ActAs
    ComboBox_GetText(GetHandle(hDlg,IDC_DC_ACTAS),
                 sz,
                 199);

    sgOBL3.bActAsInfo = GetId(sOblActAs, sz);



    // Save Default Image
    sgOBL3.iDefaultImage =
    GetDlgItemInt(hDlg, 
                      IDC_EIMAGE,
                      &bError,
                      FALSE);


    // Save U1
    sgOBL3.wU1 = (WORD)
    GetDlgItemInt(hDlg, 
                      IDC_EU1,
                      &bError,
                      FALSE);


    // Save U2
    sgOBL3.wU2 = (WORD)
    GetDlgItemInt(hDlg, 
                      IDC_EU2,
                      &bError,
                      FALSE);


    // Save Copyrights info
    Edit_GetText(GetHandle(hDlg,IDC_EINFO),
                 sgOBL3.szCopyrights, 
                 1023);


}


void InitPage1(HWND hDlg)
{
    int cpt;

    char sz[100];
    
    HWND hDC_CLASS;
    HWND hDC_SHOWAS;
    HWND hDC_ACTAS; 

    hDC_CLASS  = GetHandle(hDlg, IDC_DC_CLASS);
    hDC_SHOWAS = GetHandle(hDlg, IDC_DC_SHOWAS);
    hDC_ACTAS  = GetHandle(hDlg, IDC_DC_ACTAS);

    for (cpt=0; sOblClass[cpt].cHelpText; cpt++)
    {
         ComboBox_AddString(hDC_CLASS,
                sOblClass[cpt].cHelpText) ;
    }

    for (cpt=0; sOblShowAs[cpt].cHelpText; cpt++)
    {
          ComboBox_AddString(hDC_SHOWAS,
                sOblShowAs[cpt].cHelpText) ;
    }

    for (cpt=0; sOblActAs[cpt].cHelpText; cpt++)
    {
           ComboBox_AddString(hDC_ACTAS,
                 sOblActAs[cpt].cHelpText) ;
    }

    ComboBox_SetText (hDC_CLASS,
                      GetString(sOblClass, 
                      sgOBL3.bClassInfo));
    ComboBox_SetText (hDC_SHOWAS,
                      GetString(sOblShowAs,
                      sgOBL3.bDisplayInfo));
    ComboBox_SetText (hDC_ACTAS,
                      GetString(sOblActAs, 
                      sgOBL3.bActAsInfo));


    // DefaultImage (1..NbImage);
    if (sgOBL3.iNbrImages!=0)
    {
        sSpins[11].wMin =1;
        sSpins[11].wMax = (WORD) sgOBL3.iNbrImages;
    }

    for (cpt=0; sSpins[cpt].iIds; cpt++)
    {
        UpDown_SetRange(
            GetHandle (hDlg, sSpins[cpt].iIds),
                sSpins[cpt].wMin, sSpins[cpt].wMax);
    }


    sprintf(sz, "%d",sgOBL3.iDefaultImage);     
    Edit_SetText(GetHandle(hDlg, IDC_EIMAGE), sz);
    sprintf(sz, "%d",sgOBL3.wU1);     
    Edit_SetText(GetHandle(hDlg, IDC_EU1), sz);
    sprintf(sz, "%d",sgOBL3.wU2);     
    Edit_SetText(GetHandle(hDlg, IDC_EU2), sz);

    Edit_SetText(GetHandle(hDlg, IDC_EINFO),
                sgOBL3.szCopyrights) ;
 
    if (bHasSdx)
    {
        Edit_Enable(GetHandle(hDlg, IDC_EINFO), FALSE);
    }
    

}


/****************************************************************************
* 
*    FUNCTION: Page1(HWND, UINT, UINT, LONG)
*
*    PURPOSE:  Processes messages for "SetRange" dialog box
*
****************************************************************************/

BOOL APIENTRY Page1Proc(
	HWND hDlg,
	UINT message,
	UINT wParam,
	LONG lParam)
{

    static HWND hCtrl;
    static int iId;
    static char sz[256];
    static char sz2[256];
    static int cpt;
    static int iVal;

    static BOOL bModif = FALSE;

	static PROPSHEETPAGE * ps;
	switch (message)
	{

        case WM_COMMAND:

            switch(HIWORD(wParam))
            {

            case BN_CLICKED:
                    if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);
            break;

            case CBN_SELCHANGE:
            
                if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);
                
            break;

            case CBN_EDITCHANGE:

                iId = LOWORD(wParam);
                hCtrl = (HWND) GetHandle(hDlg,iId);

                if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);

                ComboBox_GetText(hCtrl, sz, 254);

                switch (iId)
                {
                case IDC_DC_CLASS:
                    if (GetId(sOblClass, sz)==-1)
                    {
                        ComboBox_SetText (hCtrl,
                              GetString(sOblClass, 
                                sgOBL3.bClassInfo));

                    }
                        
                break;

                case IDC_DC_SHOWAS:
                    if (GetId(sOblShowAs, sz)==-1)
                    {
                        ComboBox_SetText (hCtrl,
                              GetString(sOblShowAs,
                                sgOBL3.bDisplayInfo));

                    }
                        
                break;

                case IDC_DC_ACTAS:
                    if (GetId(sOblActAs, sz)==-1)
                    {
                            ComboBox_SetText (hCtrl,
                                GetString(sOblActAs, 
                                  sgOBL3.bActAsInfo));

                    }
                        
                break;
                }


            break;

            case EN_CHANGE:

                    
                    iId = LOWORD(wParam);
                    hCtrl = (HWND) GetHandle(hDlg,iId);
        
                    if (bModif)
                        PropSheet_Changed(
                            GetParent(hDlg), hDlg);
                    
                    Edit_GetText(hCtrl, sz, 254);
                    iVal = str2int(sz, sz2);
            
                    for (cpt=0; sSpins[cpt].iIde; cpt++)
                    {

                        if (sSpins[cpt].iIde==iId)
                        {
                            if (iVal>sSpins[cpt].wMax) 
                            {

                                
                                wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMax); 
                                Edit_SetText(hCtrl,sz);



                            }
                            else
                            {

 
                               if (iVal<sSpins[cpt].wMin) 
                               {

                                 wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMin); 
                                 Edit_SetText(hCtrl,sz);
                               
                               
                               }


                                if (strlen(sz) > 
                                    strlen(sz2) )
                                    Edit_SetText(hCtrl,sz2);
                            }
                        

                            break;
                        }

                    }
                
                
                
                
                
            break;






            }


        break;


		case WM_INITDIALOG:	
			// Save the PROPSHEETPAGE information.
			  ps = (PROPSHEETPAGE *)lParam;
              bModif = FALSE;
              InitPage1(hDlg);             
              bModif = TRUE;
			return (TRUE);

		case WM_NOTIFY:
    		switch (((NMHDR FAR *) lParam)->code) 
    		{

				case PSN_SETACTIVE:
					// Initialize the controls.
					break;

				case PSN_APPLY:
                    SavePage1(hDlg);
                    break;

				case PSN_KILLACTIVE:
					return 1;
					break;

				case PSN_RESET:
					// Reset to the original values.
					break;
    	        }
	}
	return (FALSE);   

}

/****************************************************************************
* 
*    FUNCTION: Page2(HWND, UINT, UINT, LONG)
*
*    PURPOSE:  Processes messages for "SetRange" dialog box
*
****************************************************************************/

BOOL APIENTRY Page2Proc(
	HWND hDlg,
	UINT message,
	UINT wParam,
	LONG lParam)
{
	static PROPSHEETPAGE * ps;
    static HWND hCtrl;
    static int iId;
    static char sz[256];
    static char sz2[256];
    static int cpt;
    static int iVal;

    static BOOL bModif = FALSE;


    switch (message)
	{
        case WM_COMMAND:

            switch(HIWORD(wParam))
            {

            case BN_CLICKED:
                    if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);
            break;

            case EN_CHANGE:

                    iId = LOWORD(wParam);
                    hCtrl = (HWND) GetHandle(hDlg,iId);

                    if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);


                    Edit_GetText(hCtrl, sz, 254);
                    iVal = str2int(sz, sz2);
            
                    for (cpt=0; sSpins[cpt].iIde; cpt++)
                    {

                        if (sSpins[cpt].iIde==iId)
                        {
                            if (iVal>sSpins[cpt].wMax) 
                            {

                                
                                wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMax); 
                                Edit_SetText(hCtrl,sz);



                            }
                            else
                            {
                                if (strlen(sz) > 
                                    strlen(sz2) )
                                    Edit_SetText(hCtrl,sz2);
                            }
                        

                            break;
                        }

                    }
                
                
            break;






            }


        break;

		case WM_INITDIALOG:	
			// Save the PROPSHEETPAGE information.
			  ps = (PROPSHEETPAGE *)lParam;
              bModif = FALSE;
              InitPage2(hDlg);             
              bModif = TRUE;
			return (TRUE);

		case WM_NOTIFY:
    		switch (((NMHDR FAR *) lParam)->code) 
    		{

				case PSN_SETACTIVE:
					// Initialize the controls.
					break;

				case PSN_APPLY:
                    SavePage2(hDlg);
                    break;

				case PSN_KILLACTIVE:
					return 1;
					break;

				case PSN_RESET:
					// Reset to the original values.
					break;
    	        }
	}
	return (FALSE);   

}

/****************************************************************************
* 
*    FUNCTION: Page3(HWND, UINT, UINT, LONG)
*
*    PURPOSE:  Processes messages for "SetRange" dialog box
*
****************************************************************************/

BOOL APIENTRY Page3Proc(
	HWND hDlg,
	UINT message,
	UINT wParam,
	LONG lParam)
{
	static PROPSHEETPAGE * ps;
    static HWND hCtrl;
    static int iId;
    static char sz[256];
    static char sz2[256];
    static int cpt;
    static int iVal;

    static BOOL bModif = FALSE;

	switch (message)
	{
        case WM_COMMAND:

            switch(HIWORD(wParam))
            {

            case BN_CLICKED:
                    if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);
            break;

            case EN_CHANGE:
                    iId = LOWORD(wParam);
                    hCtrl = (HWND) GetHandle(hDlg,iId);

                    if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);


                    Edit_GetText(hCtrl, sz, 254);
                    iVal = str2int(sz, sz2);
            
                    for (cpt=0; sSpins[cpt].iIde; cpt++)
                    {

                        if (sSpins[cpt].iIde==iId)
                        {
                            if (iVal<sSpins[cpt].wMin)
                            {
                               
                                wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMin); 
                                Edit_SetText(hCtrl,sz);
                                break;


                            }


                            if (iVal>sSpins[cpt].wMax) 
                            {

                                
                                wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMax); 
                                Edit_SetText(hCtrl,sz);



                            }
                            else
                            {
                                if (strlen(sz) > 
                                    strlen(sz2) )
                                    Edit_SetText(hCtrl,sz2);
                            }
                        

                            break;
                        }

                    }
                
                
            break;


            }


        break;
		case WM_INITDIALOG:	
			// Save the PROPSHEETPAGE information.
			  ps = (PROPSHEETPAGE *)lParam;
              bModif = FALSE;
              InitPage3(hDlg);             
              bModif = TRUE;
			return (TRUE);

		case WM_NOTIFY:
    		switch (((NMHDR FAR *) lParam)->code) 
    		{

				case PSN_SETACTIVE:
					// Initialize the controls.
					break;

				case PSN_APPLY:
                    SavePage3(hDlg);
                    break;

				case PSN_KILLACTIVE:
					return 1;
					break;

				case PSN_RESET:
					// Reset to the original values.
					break;
    	        }
	}
	return (FALSE);   

}

/****************************************************************************
* 
*    FUNCTION: Page4(HWND, UINT, UINT, LONG)
*
*    PURPOSE:  
*
****************************************************************************/

BOOL APIENTRY Page4Proc(
	HWND hDlg,
	UINT message,
	UINT wParam,
	LONG lParam)
{

    static BOOL bModif = FALSE;
	static PROPSHEETPAGE * ps;
    int iStatus;
    int iId;
	switch (message)
	{

        case WM_COMMAND:

            switch(HIWORD(wParam))
            {

            case EN_CHANGE:
            break;

            case BN_CLICKED:
                iId = LOWORD(wParam);
                if ((iId >= IDC_EV1) &&
                    (iId <= IDC_EV9))
               {
                igEvent = iId - IDC_EV1;
        	    iStatus = DialogBox(hAppInstance, 
		                M2INT(IDD_EVENTPROP), 
		                hDlg, 
		                EventDialogProc);

                }
            break;               
            }


		case WM_INITDIALOG:	
			// Save the PROPSHEETPAGE information.
			  ps = (PROPSHEETPAGE *)lParam;
              bModif = FALSE;
             // InitPage0(hDlg);             
              bModif = TRUE;
			return (TRUE);

		case WM_NOTIFY:
    		switch (((NMHDR FAR *) lParam)->code) 
    		{

				case PSN_SETACTIVE:
					// Initialize the controls.
					break;

				case PSN_APPLY:
                    //SavePage0(hDlg);
                    break;

				case PSN_KILLACTIVE:
					return 1;
					break;

				case PSN_RESET:
					// Reset to the original values.
					break;
    	        }
	}
	return (FALSE);   

}         

void SaveEventsPage(HWND hDlg,
                    USER_MENUHELP *psObjTab)
{

    BOOL bError;
    char sz[256];
    int iTemp;
    int iVal;
    int cpt;

    // Save ChangeTo
    ComboBox_GetText(GetHandle(hDlg,IDC_DC_CHANGETO),
                 sz,
                 128);
    sgSDI3.sEvents[igEvent].wChangeTo   
                = (WORD)GetId(psObjTab, sz);

    // Save ChangePlayerTo
    ComboBox_GetText(GetHandle(hDlg,IDC_DC_PLAYERTO),
                 sz,
                 128);
    sgSDI3.sEvents[igEvent].wPlayerChangeTo 
                = (WORD)GetId(psObjTab, sz);

    // Save TeleportTo
    ComboBox_GetText(GetHandle(hDlg,IDC_DC_TELEPORTTO),
                 sz,
                 128);
    sgSDI3.sEvents[igEvent].wTeleportTo 
                = (WORD)GetId(psObjTab, sz);

    //.........................................

    // Save LifeForce
    sgSDI3.sEvents[igEvent].wLifeForce = (WORD)
        GetDlgItemInt(hDlg, 
                      IDC_ELIFEFORCE,
                      &bError,
                      FALSE);


    // Save LifeForce
    sgSDI3.sEvents[igEvent].wPoints = (WORD)
        GetDlgItemInt(hDlg, 
                      IDC_EPOINTS,
                      &bError,
                      FALSE);


    // Save LifeForce
    sgSDI3.sEvents[igEvent].wOxygen = (WORD)
        GetDlgItemInt(hDlg, 
                      IDC_EOXYGEN,
                      &bError,
                      FALSE);

    //.............................................

    // Save CheckBoxs
    iVal = 1;
    iTemp =0;
    for (cpt=0; cpt<16; cpt++)
    {

        iTemp = iTemp +
            Button_GetCheck(GetHandle(hDlg, IDC_C1+cpt))*iVal; 

        iVal = iVal+ iVal;
    }

    sgSDI3.sEvents[igEvent].wAction = iTemp;


}



void InitEventsPage(HWND hDlg,
                    USER_STRINGID *psObjTab)
{
    static char szDialogName[512];
    static char szObjetName[256];
    char sz[164];
    int iCpt;
    HWND hChangeTo;
    HWND hPlayerTo;
    HWND hTeleportTo;
    int iTemp;
    int cpt;


    // Set DialogTitle
    if (strlen(sgOBL3.szName)==0)
    {
          strcpy(szObjetName, 
                 LastOf(sgOBL3.szFilename, '\\')+1);
                 *LastOf(szObjetName, '.')=0;
    }
     else
    {
           strcpy(szObjetName, sgOBL3.szName);
    }

     sprintf(szDialogName, 
             "�v�nenent %c%s%c de %c%s%c...",
              34,szOblEvents[igEvent],34,
                  34,szObjetName, 34);     
     SetWindowText (hDlg, szDialogName);


     // Set Spins' Range 
    for (iCpt=0; sSpins[iCpt].iIds; iCpt++)
    {
        UpDown_SetRange(
            GetHandle (hDlg, sSpins[iCpt].iIds),
                sSpins[iCpt].wMin, sSpins[iCpt].wMax);
    }

    // Get Handles to combos
    //  hDC_ACTAS  = GetHandle(hDlg, IDC_DC_ACTAS);
     hChangeTo = GetHandle(hDlg, IDC_DC_CHANGETO);
     hPlayerTo = GetHandle(hDlg, IDC_DC_PLAYERTO);
     hTeleportTo = GetHandle(hDlg, IDC_DC_TELEPORTTO);

    
    // Ajoute les strings aux combos
    for (iCpt=0; psObjTab[iCpt].cHelpText; iCpt++)
    {
         ComboBox_AddString(hChangeTo,
                psObjTab[iCpt].cHelpText) ;
         ComboBox_AddString(hPlayerTo,
                psObjTab[iCpt].cHelpText) ;
         ComboBox_AddString(hTeleportTo,
                psObjTab[iCpt].cHelpText) ;
    }

    // Fill-in the Combos' TextBox
    ComboBox_SetText (hChangeTo,
                      GetString(psObjTab, 
                      sgSDI3.sEvents[igEvent].wChangeTo));
    ComboBox_SetText (hPlayerTo,
                      GetString(psObjTab, 
                      sgSDI3.sEvents[igEvent].wPlayerChangeTo));
    ComboBox_SetText (hTeleportTo,
                      GetString(psObjTab, 
                      sgSDI3.sEvents[igEvent].wTeleportTo));

    // Fill-in TextBox for Numbers
    sprintf(sz, "%d",sgSDI3.sEvents[igEvent].wLifeForce);     
    Edit_SetText(GetHandle(hDlg, IDC_ELIFEFORCE), sz);

    sprintf(sz, "%d",sgSDI3.sEvents[igEvent].wPoints);     
    Edit_SetText(GetHandle(hDlg, IDC_EPOINTS), sz);

    sprintf(sz, "%d",sgSDI3.sEvents[igEvent].wOxygen);     
    Edit_SetText(GetHandle(hDlg, IDC_EOXYGEN), sz);


    // InitCheckBoxs
    iTemp = sgSDI3.sEvents[igEvent].wAction;
    for (cpt=0; cpt<16; cpt++)
    {
        Button_SetCheck(
            GetHandle(hDlg, IDC_C1+cpt),
            iTemp &1
            );

        iTemp = iTemp /2;
    }

}


//
//
//
BOOL CALLBACK EventDialogProc(HWND  hDlg,	
                         UINT  iMsg,	 
                         WPARAM  wParam, 
                         LPARAM  lParam )
{
    static USER_STRINGID *psObjTab;
    static USER_SDI3HEADER *psSDIHead;
    static BOOL bModif = FALSE;

    int cpt;
    int iId;
    HWND hCtrl;
    int iVal;
    char sz[200];
    char sz2[200];


     switch (iMsg)
          {
          case WM_INITDIALOG :

              bModif = FALSE;

            // Query mother window about SdiHeader
                psSDIHead = (void *)SendMessage(hAppWnd, 
                         WM_USER_GETSDIHEAD, 0,0);

            // ....................................
                MakeSDIObjTable(&psObjTab,
                     psSDIHead->pFirst,
                     psSDIHead->iNbObj);
                InitEventsPage(hDlg, psObjTab);

                bModif = TRUE;

               return TRUE ; // WM_INITDIALOG ==================

          case WM_COMMAND :

            switch(HIWORD(wParam))
            {
            case CBN_EDITCHANGE:

                iId = LOWORD(wParam);
                hCtrl = (HWND) GetHandle(hDlg,iId);

                if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);

                ComboBox_GetText(hCtrl, sz, 254);
             
                switch (iId)
                {
                    case IDC_DC_CHANGETO:
                    case IDC_DC_PLAYERTO:
                    case IDC_DC_TELEPORTTO:
                        if (GetId(sOblClass, sz)==-1)
                        {
                            ComboBox_SetText (hCtrl,
                                GetString(psObjTab, 
                                  sgSDI3.sEvents[igEvent].
                                           wTeleportTo));

                         }
                        
                       break; //
                }
            break;


            case BN_CLICKED:
                    if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);
            break;

            case EN_CHANGE:
                    iId = LOWORD(wParam);
                    hCtrl = (HWND) GetHandle(hDlg,iId);

                    if (bModif)
                     PropSheet_Changed(
                         GetParent(hDlg), hDlg);


                    Edit_GetText(hCtrl, sz, 254);
                    iVal = str2int(sz, sz2);
            
                    for (cpt=0; sSpins[cpt].iIde; cpt++)
                    {

                        if (sSpins[cpt].iIde==iId)
                        {
                            if (iVal<sSpins[cpt].wMin)
                            {
                               
                                wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMin); 
                                Edit_SetText(hCtrl,sz);
                                break;


                            }


                            if (iVal>sSpins[cpt].wMax) 
                            {

                                
                                wsprintf(sz, 
                                         "%d",
                                         sSpins[cpt].wMax); 
                                Edit_SetText(hCtrl,sz);



                            }
                            else
                            {
                                if (strlen(sz) > 
                                    strlen(sz2) )
                                    Edit_SetText(hCtrl,sz2);
                            }
                        

                            break;
                        }

                    }
                
            }     
               switch (LOWORD (wParam))
                    {
		            case IDOK :
                            SaveEventsPage(hDlg, psObjTab);
		            case IDCANCEL :
			        case IDNO :                            
                            FreeSDIObjTable(psObjTab);
                            EndDialog (hDlg, 
			   	                   LOWORD 
				                  (wParam)) ;
			         return TRUE ;
                    }
               break ;
          }
     return FALSE ;
     }
