

// FILE: PalClass.c
//       Gestion de class Palette utilis� dans GE96.c
//       pour afficher la palette de couleurs.


// *** INCLUDED FILES ***
#include "include.h"
#include "common.h"
#include "const.h"
#include "draw.h"

extern HPALETTE hpal;
extern USER_WINPAL PalColors[];
extern HWND hwnd;
extern HINSTANCE hAppInstance;
extern HWND hAppWnd	 ;
extern HWND hgrildwnd;

char PenColor =0;                       // Pencil color
HWND hchildwnd;                         // Color Palette


#include "proto.h"

uchar TheColor;
char BitPalColor[32*32];
HBITMAP MakeBitmap(int len, int hei, unsigned char *bits, HDC hdc);

BOOL CALLBACK ColorPropDialogProc(HWND  hDlg,	UINT  iMsg,	 WPARAM  wParam,
							 LPARAM  lParam );


//***********************************************************
//
//HWND RegisterAndCreateAppColorPal(HINSTANCE hInstance)
//
//***********************************************************


HWND RegisterAndCreateAppColorPal(HWND hwnd)


{
	WNDCLASS wc;
    ATOM atom;
    // *****************  Class for the ChildWindow ************************
	wc.style = CS_BYTEALIGNWINDOW |
		       CS_HREDRAW | CS_VREDRAW | CS_OWNDC | CS_DBLCLKS;
	wc.lpfnWndProc = ChildWndProc; 
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 4;
	wc.hInstance = hAppInstance;
	wc.hIcon = NULL ;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = "Palette" ; 

	atom = RegisterClass(&wc);

    return (CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_WINDOWEDGE,
		"Palette",
		ColorsPaletteName,
		//WS_POPUP |
        WS_CAPTION 
        | WS_OVERLAPPEDWINDOW 
        //| WS_CLIPCHILDREN
        | WS_VISIBLE
        | WS_CLIPSIBLINGS,
		350, 050, (16*16)+6, (15*16)+6,
		hwnd,
		(HMENU)NULL,
		hAppInstance,
		0L));
}



//**********************************************************************************
//
// ChildWndProc : This is the message handler to the Child PopUp Window
//                The Color Palette Window Proc handler
//
//*********************************************************************************
LRESULT CALLBACK ChildWndProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{        
PAINTSTRUCT ps ;
    HDC         hdc ;
	static char bitPalette[16*16*16*14];
	BOOL fAppActive;
	int static ColorPropDialogBusy = FALSE;
	int cpt;
    static HWND hMother;

    MOUSE mouse;

		switch (iMsg)
		{

        case WM_KEYDOWN:
            SendMessage(hAppWnd, WM_KEYDOWN, wParam, lParam);

        return 0;

        case WM_CLOSE :
            hMother = GetParent(hwnd);
            SendMessage(hAppWnd, WM_COMMAND,
                IDM_HASPALETTE, 0);
        return 0 ;
		
		case WM_LBUTTONDBLCLK:
        return TRUE;

		case WM_LBUTTONDOWN:
			
               if (wParam & MK_LBUTTON)
               {
					mouse.last_x= mouse.x;
					mouse.last_y= mouse.y;
		            mouse.button = wParam;
                    mouse.x = LOWORD (lParam) ;
                    mouse.y = HIWORD (lParam) ;

			
					if ((mouse.y/16 <14) && (mouse.x/16<16))
					{
						PenColor = (char) (
                                     (mouse.y & 0xF0) 
							       + (mouse.x/16) +16);

						for (cpt=0; cpt<32*32; cpt++)
							BitPalColor[cpt] = PenColor;
						//InvalidateRect (hgrildwnd, NULL, FALSE) ;


					}
			   }
					    
               return 0 ;

		    		//ReleaseDC (hwnd, hdc) ;
	
		case WM_RBUTTONDOWN:
	
               if (wParam & MK_RBUTTON)
                    {
                    //hdc = GetDC (hwnd) ;

					mouse.last_x= mouse.x;
					mouse.last_y= mouse.y;
		            mouse.button = wParam;
                    mouse.x = LOWORD (lParam) ;
                    mouse.y = HIWORD (lParam) ;


						if (!ColorPropDialogBusy)
						{	ColorPropDialogBusy= TRUE;
			  				TheColor = (char) (
                                (mouse.y & 0xF0) 
							+ (mouse.x/16) +16);
							DialogBox(hAppInstance, 
							M2INT(IDD_COLORPROP), 
				     		hAppWnd, 
						  	  ColorPropDialogProc);
	
							ColorPropDialogBusy= FALSE;
						}

                    }
               return 0 ;

		case WM_ACTIVATEAPP:

            fAppActive = (BOOL)wParam;

        //*** Remap the system colors and deal with the palette
               
           //AppActivate(fAppActive);
           AppActivate(fAppActive);
           if (hpal)
           {
            hdc = GetDC(hwnd);

            UnrealizeObject(hpal);
            SelectPalette(hdc, hpal, FALSE);
            RealizePalette(hdc);
            ReleaseDC(hwnd, hdc);
           }
        
           break;
	
		        case WM_CREATE :

				if (hpal)
				{
         		
					hdc = GetDC(hwnd);

					UnrealizeObject(hpal);
					SelectPalette(hdc, hpal, FALSE);
					RealizePalette(hdc);				
					
					ReleaseDC(hwnd, hdc);
 			        FillbitPalette(bitPalette);

				}

				return 0 ;



				case WM_PAINT :
			  		hdc = BeginPaint(hwnd,&ps);
                    PaintPaletteWithBitmap(hdc, bitPalette);
       				EndPaint(hwnd,&ps);
				return 0L;

 
	
		}
         return DefWindowProc (hwnd, iMsg, wParam, lParam) ;

	}        


void PaintPaletteChildWindowWithRect(HDC hdc)
{
	USER_RECT user_rect;
	int x,y;
	for (y=0; y<14; y++)
	{			
		for (x=0; x<16; x++)
		{

			user_rect.x1 = x *16  ;
			user_rect.x2 = x*16 +15	;
			user_rect.y1 = y*16 ;
			user_rect.y2 = y*16+15;
			user_rect.color = PalColors[x+y*16+16];			
			DrawUserRect(hdc, user_rect);

		}	

	}

}


void PaintPaletteWithBitmap(HDC hdc, char bitPalette[])
{
	HBITMAP hbitmap;

    hbitmap = MakeBitmap(16*16, 16*14, bitPalette, hdc);

			if (hbitmap)
				{ 
				PutBitmap( hdc, 
			               hbitmap,
			               0,
			               0)  ;
				}
				   
			   DeleteObject(hbitmap);
}

void FillbitPalette(char bitPalette [])
{
	int x,y,x2,y2;
	for (y=0; y<14; y++)
	{			
			for (x=0; x<16; x++)
			{						
				for (y2=0; y2<15; y2++)
				{
					for (x2 =0; x2<15; x2++)
					{
						bitPalette[y*256*16+
  									x*16+									   
									y2*256+
									x2] = x+y*16+16;
					}
				}


			}
	}

}


//*********************************************************
//
// ColorPropSheet DialogProc
//
//*********************************************************

BOOL CALLBACK ColorPropDialogProc(HWND  hDlg,	UINT  iMsg,	 WPARAM  wParam,
							 LPARAM  lParam )
{

		BOOL test;
	    int cpt;
		HWND hCtrl;
		int iCtrlID;
		int iIndex;
		char *PtrPenColor;
		PAINTSTRUCT ps ;

		HDC hdc;

		static int iColor[3];

		PALETTEENTRY PalEntry;

		static char ColorRect[32*256];
		HBITMAP hbitmap;


		switch (iMsg)
          {



			case WM_ACTIVATEAPP:

         //   fAppActive = (BOOL)wParam;

        //*** Remap the system colors and deal with the palette
               
           //AppActivate(fAppActive);
           AppActivate(FALSE);
           if (hpal)
           {
            hdc = GetDC(hwnd);

            UnrealizeObject(hpal);
            SelectPalette(hdc, hpal, FALSE);
            RealizePalette(hdc);
            ReleaseDC(hwnd, hdc);
           }
        
           break;
	


			case WM_INITDIALOG :
			   PtrPenColor = (char *)&PalColors +(TheColor-16)*3;


			   for (cpt=0; cpt<3; cpt++)
			   {
				   hCtrl = GetDlgItem (hDlg, cpt+IDC_SCROLLRED);
				   SetScrollRange(hCtrl, SB_CTL, 0, 255, FALSE);
				   SetScrollPos(hCtrl, SB_CTL, 
					            *(PtrPenColor+cpt), FALSE);
		           iColor[cpt] = *(PtrPenColor+cpt);
			   }
    
				PalEntry.peRed = 255;//PalColors[TheColor-16].red;
				PalEntry.peGreen = 255;//PalColors[TheColor-16].green;
				PalEntry.peBlue = 255;//PalColors[TheColor-16].blue;
				PalEntry.peFlags = PC_RESERVED;

				AppActivate(FALSE);
				if (hpal)
				{
					hdc = GetDC(hAppWnd);
					test=	AnimatePalette(hpal, TheColor-16,1, &PalEntry);
					UnrealizeObject(hpal);
					SelectPalette(hdc, hpal, FALSE);
					RealizePalette(hdc);
					ReleaseDC(hAppWnd, hdc);
				}


				for (cpt=0; cpt<32*256; cpt++)			     
					ColorRect[cpt]=TheColor;

			   UpdateWindow(hDlg);

			  return TRUE ;


		  case WM_HSCROLL:
				hCtrl = (HWND) lParam;
				iCtrlID = GetWindowLong(hCtrl, GWL_ID);
				iIndex = iCtrlID - 1000;

				switch(LOWORD (wParam))
				{
				
                    case SB_PAGEDOWN :
                         iColor[iIndex] += 15 ;        // fall through
                    case SB_LINEDOWN :
                         iColor[iIndex] = min (255, iColor[iIndex] + 1) ;
                         break ;
                    case SB_PAGEUP :
                         iColor[iIndex] -= 15 ;        // fall through
                    case SB_LINEUP :
                         iColor[iIndex] = max (0, iColor[iIndex] - 1) ;
                         break ;
                    case SB_TOP :
                         iColor[iIndex] = 0 ;
                         break ;
                    case SB_BOTTOM :
                         iColor[iIndex] = 255 ;
                         break ;
                    case SB_THUMBPOSITION :
                    case SB_THUMBTRACK :
                         iColor[iIndex] = HIWORD (wParam) ;
                         break ;
                    default :
                         return FALSE ;
				
				}

               SetScrollPos  (hCtrl, SB_CTL,      iColor[iIndex], TRUE) ;
               SetDlgItemInt (hDlg,  iCtrlID + 3, iColor[iIndex], FALSE) ;
			   InvalidateRect(hDlg, NULL,FALSE);	
			   return TRUE;



          case WM_PAINT:

	  		hdc = BeginPaint(hDlg,&ps);
			UnrealizeObject(hpal);
			SelectPalette(hdc, hpal, FALSE);
			RealizePalette(hdc);
			hbitmap = MakeBitmap(256,32, ColorRect, hdc);
            //hbitmap = CreateBitmap(256, 32, 1, 8, ColorRect);
			if (hbitmap)
			{	PutBitmap( hdc, 
					        hbitmap,
						    16,
							8)  ;
		  
				DeleteObject(hbitmap);
       			EndPaint(hwnd,&ps);
			}
				
			  return TRUE ;



          case WM_COMMAND :
               switch (LOWORD (wParam))
                    {
		            case IDOK :
		            case IDCANCEL :
			    case IDNO :
					ShowWindow(hchildwnd, SW_RESTORE);
					SetFocus(hchildwnd);
					EndDialog (hDlg, 
			   	           LOWORD 
				          (wParam)) ;
			         return TRUE ;
                    }
               break ;
          }
     return FALSE ;
}
