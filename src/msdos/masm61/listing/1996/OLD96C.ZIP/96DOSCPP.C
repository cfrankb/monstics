#include <user\friendly.h>
#include <stdlib.h>

#define SAVE asm{push di; push es}
#define RESTORE asm{pop es; pop di}
#define uchar unsigned char
#define uint unsigned int
#define ulong unsigned long

typedef struct
{
	unsigned char VESASignature[4];
	unsigned int VESAVersion;
	unsigned char far*OEMStringPtr;
	unsigned int Capabilities[4];
	unsigned int far* VideoModePtr;
} VGAINFOBLOCK;

typedef struct
{
 //;mandatory information
unsigned int ModeAttributes;		// dw ?		;mode attributes
unsigned  char WinAAttributes;		//db ?		;Window A attributes
unsigned  char WinBAttributes;		//db ?		;Window B attributes
unsigned  int WinGranularity;		//dw ?		;window granularity
unsigned  int WinSize;	   		//	dw ?		;window size
unsigned  int WinASegment;		//dw ?		;Window A start segment
unsigned  int WinBSegment;	        //	dw ?		;Window B start segment
unsigned long WinFuncPtr;		//dd ?		;pointer to window function
unsigned  int BytesPerScanLine;		//dw ?		;bytes per scan line

 //;extended information
 //;optional information
unsigned  int XResolution;	   //	dw ?		;horizontal resolution
unsigned  int YResolution;	   //	dw ?		;vertical resolution
unsigned  char XCharSize;	   //	db ?		;character cell width
unsigned  char YCharSize;	   //db ?		;character cell height
unsigned  char NumberOfPlanes;     //		db ?		;number of memory planes
unsigned  char BitsPerPixel;	   //	db ?		;bits per pixel
unsigned  char NumberOfBanks ;     //		db ?		;number of banks
unsigned  char MemoryModel;	   //	db ?		;memory model type
unsigned  char BankSize;	 	   //	db ?		;bank size in K
} MODEINFOBLOCK;

typedef struct
{
  unsigned int boutons;
  unsigned int x;
  unsigned int y;
  unsigned int oldx;
  unsigned int oldy;

  unsigned char mouse[16][16];
  unsigned char temp[16][16];
} MOUSE;

typedef struct
{
	char rouge;
	char vert;
	char bleu;
} COULEUR;

// structures windows
typedef struct
{
  long biSize;		// Taille du Record
  long biWidth;		// Largeur du bitmap
  long biHeight;        // Hauteur du bitmap
  int biPlanes;	// Nombre de plan (toujours 1)
  int biBitCount;	// Nombre de bits par couleur 	8 dn notre cas)
  long biCompression;	// toujours BI_RGB
  long biSizeImage;	// on s'en fout	(n/a)
  long biXPelsPerMeter;	// on s'en fout (n/a)
  long biYPelsPerMeter; // on s'en fout	(n/a)
  long biClrUsed;	// nombre de couleurs utilis�es	(256 dn notre cas)
  long biClrImportant;	// nbr de couleurs significative(0 = toutes)
} BITMAPINFOHEADER;

typedef struct
{
	char rgbBlue;
	char rgbGreen;
	char rgbRed;
	char rgbReserved; // doit �tre toujours z�ro
}  RGBQUAD;

typedef struct
{
	BITMAPINFOHEADER bmiHeader;
	RGBQUAD          bmiColors[256];
} BITMAPINFO;

int  ss_returnsvgainfo(VGAINFOBLOCK *buffer);
int  ss_returnsvgamodeinfo(MODEINFOBLOCK *buffer, unsigned int mode);
int  ss_setsvgamode(unsigned int mode);
int  ss_getsvgamode(unsigned int *mode);
int  ss_setsvgawindow(char win, unsigned int pos);
int  ss_getsvgawindow(char win, unsigned int *pos);
void ss_setfastwindow(char win, unsigned int pos, unsigned long ptrwin);
void ss_getfastwindow(char win, unsigned int *pos, unsigned long ptrwin);
void ss_drawmouse(MOUSE *mouse, MODEINFOBLOCK infoblock);
void ss_undrawmouse(MOUSE *mouse, MODEINFOBLOCK infoblock);
void ss_readmouse(MOUSE *mouse);
int  ss_initmouse(MOUSE *mouse);
void ss_setrangey(unsigned min, unsigned max);
void ss_setrangex(unsigned min, unsigned max);
void ss_drawpix(unsigned x, unsigned y, unsigned char color, MODEINFOBLOCK);
void ss_draw2pix(unsigned x, unsigned y, unsigned int color, MODEINFOBLOCK);
void ss_draw4pix(unsigned x,unsigned y,unsigned long color,MODEINFOBLOCK);
void ss_drawundermouse(unsigned int x, unsigned int y, char color, MOUSE *mouse);
void ss_tellwinposfor(unsigned int x,unsigned int y,MODEINFOBLOCK infoblock,unsigned int *pos,unsigned int *where);
int ss_loadbmp(const char *name, BITMAPINFO *PTRbitmapinfo, char far **dib);
void ss_getvideorgb(COULEUR *rgb);
void ss_setvideorgb(COULEUR *rgb);
void ss_setcolor( unsigned int color, uchar red, uchar green, uchar blue);
void ss_usebmpcolors(BITMAPINFO);

	/*
GetRegisters PROC
			pushall
		mov ah,10h
			mov al,17h
			mov bx,0
			mov cx,256
			set es,DATA
			mov dx,offset C_Registers
		int 10h
			popall
			ret
GetRegisters ENDP

;-------------------------------------------------------------------------

	  */

void ss_getvideorgb(COULEUR *rgb)
{
	SAVE;
	asm {  mov ah, 0x10
		   mov al, 0x17
		   mov bx,0
		   mov cx, 256
		   les dx,rgb
		   int 0x10
		}
	RESTORE
}

/*FillRegisters PROC

			pushall
				call DisableRefresh
		mov ah,10h
			mov al,12h
			mov bx,0
			mov cx,256
			set es,DATA
			mov dx,offset C_Registers
		int 10h
			popall
				call EnableRefresh
			ret
FillRegisters ENDP*/


void ss_setvideorgb(COULEUR *rgb)
{
	asm {
		mov ah,0x10
		mov al, 0x12
		mov bx,0
		mov cx,256
		les dx, rgb
		int 0x10
		}

}

void ss_usebmpcolors(BITMAPINFO bitmapinfo__)
{
	COULEUR couleurs[256];
	uint x;

	for (x=0; x<256; x++)
	{
		couleurs[x].rouge = bitmapinfo__.bmiColors[x].rgbRed;
		couleurs[x].bleu = bitmapinfo__.bmiColors[x].rgbBlue;
		couleurs[x].vert = bitmapinfo__.bmiColors[x].rgbGreen;
	}

	ss_setvideorgb(couleurs);
}



/*_SetColor	PROC NEAR PASCAL, ColorReg:WORD, Red:BYTE, Green:BYTE, Blue:BYTE
		pushall
				mov ah,10h
				mov al,10h
				mov bx,ColorReg
				mov ch,Green
				mov cl,Blue
				mov dh,Red
				int 10h
				popall
				ret
_SetColor       ENDP*/

void ss_setcolor( unsigned int color, uchar red, uchar green, uchar blue)
{
	SAVE;
	asm { mov ah,0x10
		  mov al,0x10
		  mov bx, color
		  mov ch, green
		  mov cl,blue
		  mov dh, red
		  int 0x10
		  }
	RESTORE;

}

void ss_setrangey(unsigned min, unsigned max)
{
	asm {mov ax, 8
		 mov cx, min
		 mov dx, max
		int 0x33
		}
}

void ss_setrangex(unsigned min, unsigned max)
{
	asm {mov ax, 7
		 mov cx, min
		 mov dx, max
		int 0x33
		}
}

void ss_drawundermouse(unsigned int x, unsigned int y, char color, MOUSE *mouse)
{
	mouse->temp[x][y]=color;
}


void ss_readmouse(MOUSE *mouse)
{
	int __x;
	int __y;
	int __boutons;

	asm { mov ax, 3
		  int 0x33
			mov &__x, cx
			mov &__y, dx
			mov &__boutons, bx
		}
	mouse->x = __x;
	mouse->y = __y;
	mouse->boutons = __boutons;
}

int ss_initmouse(MOUSE *mouse)
{
	int retour;
	asm {
	mov ax,0
	int 0x33
	mov &retour,ax
		}

	mouse->x =-1;
	mouse->y =-1;
	mouse->oldx =-1;
	mouse->oldy =-1;

	return(retour);
}

int ss_returnsvgainfo(VGAINFOBLOCK  *buffer)
{
	int retour;
	SAVE;
	asm { les di, buffer
		  mov al,0
		  mov ah,0x4f
		  int 0x10
		  mov &retour, ax
		}
	RESTORE;
	return(retour);
}

int ss_returnsvgamodeinfo(MODEINFOBLOCK *buffer, unsigned int mode)
{
	int retour;
	SAVE;
	asm { mov al,01
		  mov cx,mode
		  mov ah,0x4f
		   les di, buffer
		   int 0x10
		   mov &retour,ax
		  }
	RESTORE;
	return(retour);
}

int ss_setsvgamode(unsigned int mode)
{
	int retour;
	asm { mov ah,0x4f
		  mov al,2
		  mov bx,mode
		  int 0x10

		  mov &retour, ax
		}
		return(retour);
}

int ss_getsvgamode(unsigned int *mode)
{
	int retour;
	int MODE;

	asm { mov ah,0x4f
		  mov al,3
		  int 0x10

		  mov &retour, ax
		  mov &MODE,bx
		}

		*mode= MODE;
		return(retour);
}

int ss_setsvgawindow(char win, unsigned int pos)
{
	int retour;
	asm {
			mov ah, 0x4f
			mov al,5
			mov bh,0
			mov bl, win
			mov dx, pos;
			int 0x10
			mov &retour, ax
		}
	return(retour);
}


int ss_getsvgawindow(char win, unsigned int *pos)
{
	int POS;
	int retour;
	asm {
			mov ah, 0x4f
			mov al,5
			mov bh,1
			mov bl, win
			int 0x10
			mov &retour, ax
			mov &POS, dx
		}
			*pos = POS;

	return(retour);
}

// FONCTION GENERIQUE
int seg(const char far *DataPtr)
{

	int segtmp;
	asm {	push ds
			pusha
			lds si, DataPtr
			mov &segtmp, ds
			popa
			pop ds
		}

	return(segtmp);
}

int offset(const char far *DataPtr)
{

	int segtmp;
	asm {	push ds
			pusha
			lds si, DataPtr
			mov &segtmp, si
			popa
			pop ds
		}

	return(segtmp);
}


void setmodev(char Mode)
{

	asm {   push ds /* Indispensable  PUSH DS, PUSHA*/
			pusha
			mov ah,0
			mov al,Mode
			int 0x10

			mov ah,0xf
			int 0x10

			popa
			pop ds /* Indispensable POPA, POP DS */
		}
}



void setxy(char x,char y)
{
 asm{			mov bh,0
				mov dl,x
				mov dh,y
				mov ah,2
				int 0x10
	}
}



void ecrirecar(char Car, char Color)
{
asm{            mov al,Car
				mov bl,Color
				mov ah,0x0e
				int 0x10
	}
}



char maj(char key)
{
	if ((key >='a') && (key <='z'))
		key= key - 'a' + 'A';
	return(key);
}

int getax()
{
	int key=0;
	asm{
			push bx
			push dx
			push ds
			mov ax,0
			mov dx,0x40
			mov ds,dx
			mov dx,word ptr ds:[0x1c]
			mov bx,word ptr ds:[0x1a]
			cmp dx,bx
			jz GETOUT
			mov ax,[bx]
			mov ds:[0x1a],dx
			mov &key,ax
		}
GETOUT:
	asm{
			pop ds
			pop dx
			pop bx
		}
	return(key);
}


ulong dec2long(const char *ch)
{
	ulong temp=0;
	int neg =0;

	if (*ch=='-') {neg=1;ch++;}
	while ((*ch >= '0') && (*ch <='9'))
	{
		temp = temp * 10;
		temp = temp + *ch -'0';
		ch++;
	}

  if (neg)  return(-temp);
  else return(temp);

}


void blowvideo(int color)
{
	SAVE;
	asm { push 0xa000
		  pop es
		  xor di,di
		  mov bx , color
		  mov cx, 65536 /2
		  mov bx, color
		}
__loop:
	asm{
		  //mov bl,ch
		  //mov bh,ch
		  mov word ptr es:[di], bx
		  add di,2
		  loop __loop
		}
	RESTORE;
}



