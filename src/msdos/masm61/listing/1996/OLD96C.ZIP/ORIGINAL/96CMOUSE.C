
typedef struct
{
	unsigned char VESASignature[4];
	unsigned int VESAVersion;
	unsigned char far*OEMStringPtr;
	unsigned int Capabilities[4];
	unsigned int far* VideoModePtr;
} VGAINFOBLOCK;

typedef struct
{
 //;mandatory information
unsigned int ModeAttributes;		// dw ?		;mode attributes
unsigned  char WinAAttributes;		//db ?		;Window A attributes
unsigned  char WinBAttributes;		//db ?		;Window B attributes
unsigned  int WinGranularity;		//dw ?		;window granularity
unsigned  int WinSize;	   		//	dw ?		;window size
unsigned  int WinASegment;		//dw ?		;Window A start segment
unsigned  int WinBSegment;	        //	dw ?		;Window B start segment
unsigned long WinFuncPtr;		//dd ?		;pointer to window function
unsigned  int BytesPerScanLine;		//dw ?		;bytes per scan line

 //;extended information
 //;optional information
unsigned  int XResolution;	   //	dw ?		;horizontal resolution
unsigned  int YResolution;	   //	dw ?		;vertical resolution
unsigned  char XCharSize;	   //	db ?		;character cell width
unsigned  char YCharSize;	   //db ?		;character cell height
unsigned  char NumberOfPlanes;     //		db ?		;number of memory planes
unsigned  char BitsPerPixel;	   //	db ?		;bits per pixel
unsigned  char NumberOfBanks ;     //		db ?		;number of banks
unsigned  char MemoryModel;	   //	db ?		;memory model type
unsigned  char BankSize;	 	   //	db ?		;bank size in K
} MODEINFOBLOCK;

typedef struct
{
  unsigned int boutons;
  unsigned int x;
  unsigned int y;
  unsigned int oldx;
  unsigned int oldy;

  unsigned char mouse[16][16];
  unsigned char temp[16][16];
} MOUSE;

int  ss_returnsvgainfo(VGAINFOBLOCK *buffer);
int  ss_returnsvgamodeinfo(MODEINFOBLOCK *buffer, unsigned int mode);
int  ss_setsvgamode(unsigned int mode);
int  ss_getsvgamode(unsigned int *mode);
int  ss_setsvgawindow(char win, unsigned int pos);
int  ss_getsvgawindow(char win, unsigned int *pos);
void far ss_setfastwindow(char win, unsigned int pos, unsigned long ptrwin);
void ss_drawmouse(MOUSE *mouse, MODEINFOBLOCK infoblock);
void ss_undrawmouse(MOUSE *mouse, MODEINFOBLOCK infoblock);

void ss_readmouse(MOUSE *mouse)
{
	int __x;
	int __y;
	int __boutons;

	asm { mov ax, 3
		  int 0x33
			mov &__x, cx
			mov &__y, dx
			mov &__boutons, bx
		}
	mouse->x = __x;
	mouse->y = __y;
	mouse->boutons = __boutons;
}

int ss_initmouse(MOUSE *mouse)
{
	int retour;
	asm {
	mov ax,0
	int 0x33
	mov &retour,ax
		}

	mouse->x =-1;
	mouse->y =-1;
	mouse->oldx =-1;
	mouse->oldy =-1;

	return(retour);
}

