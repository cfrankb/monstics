
//
// common.c
//

#include "Common.h"

//
// This was str.c
//

char *MakeString(const char *sz)
{
    char *p = malloc(strlen(sz)+1);
    strcpy(p,sz);
    return p;
}

void ddmemcpy(char *pd, char *ps, int iLen)
{

    __asm 
    {
            mov ecx, iLen
            shr ecx,2
            mov esi, ps
            mov edi, pd
ddLoop:
            mov eax, [esi]
            cmp eax,0xdddddddd
            je outloop

            mov [edi],eax
            inc esi
            inc esi
            inc esi
            inc esi
            inc edi
            inc edi
            inc edi
            inc edi
            dec ecx
            or ecx,ecx
            jne ddLoop

outloop:       
    }

}


void fillmem(void *vmem, char ch, int size)
{
    char *mem = (char *)vmem;

    for (;size;size--, ((char *)mem)++)
        (char)*mem = ch;
}

char * Int2Str(int Num)
{
	char Str[128];
	char *ptr;
	int cpt;

	Str[127] =0;
	ptr = malloc (5);
	for (cpt=0; cpt<4; cpt++)
		*(ptr+cpt)=32; 

	*(ptr+cpt) =0;

	
	for(cpt=0;Num!=0;cpt++)
	{
	   Str[126-cpt]= Num%10 + 0x30;
	   Num=Num/10;
	}

	strcpy(ptr +4-cpt, &Str[126-cpt+1] );
	return(ptr);

	
}

void Int2Hex(unsigned short value, char *hex)
{

    char temp[5]="0000";
    int cpt;
    

    for (cpt=3;value && cpt>=0;value = value/16, cpt--)
    {
		if ((value%16) >=10 )  
		   temp[cpt] = (char) (value%16 -10)+'A';
		else
		   temp[cpt] = (char) (value%16)+'0';

    }
    
    strcpy(hex,temp);

}


char *LastOf(char *text, char car)
{
    char *last;
    last = NULL;
    
    for (; *text; text++)
        if (*text==car) last =text;

    return last;
}


BOOL SamePath(char *t1, char *t2)
{

    for( ; *t1 && *t2 && (*t1== *t2); t1++, t2++);
    return (!LastOf(t1, '\\') && !LastOf(t2, '\\') );
     
}


int XOR(int src1, int src2)
{
    int retour;
    __asm { 
            push eax
            mov eax, src1
            xor eax,src2
            mov dword ptr retour, eax
            pop eax
          }
    return retour;
}


// ***********************************************************
//
// void error(const char *title, const char *text)
//
// ***********************************************************


void error(const char *title, const char *text)
{
		     MessageBox(hwnd, text, 
				              title,
							  MB_OK | MB_ICONSTOP);
			 exit(0);
}



// *************************************************************
//
// int SaveNow()
//
// *************************************************************


int SaveNow()
{
        return WarningDialog(hwnd,
        "Les modifications n'ayant pas �t� sauvegarder, elles seront perdues.",   
        "Souhaitez-vous sauvegarder avant de continuer ?");
    
}



// *************************************************************
//
// BOOL ValidateFilename(char *filename, char *Id)
//
// *************************************************************


 BOOL ValidateFilename(char *filename, char *Id)
 {

	static char Temp[5];
	FILE *sfile;
	sfile = fopen(filename, "rb");
	if (!sfile) return err_fileopen;

	fread(Temp, 4,1, sfile);
	if (strcmp(Temp, Id)==0) 
	{
	 fclose(sfile);
	 return TRUE;
	}
	else
	{
	 fclose (sfile);
	 return err_format;
	}

 }
 



// *************************************************************
//
// DoCaption
// 
// *************************************************************

void DoCaption(HWND hwnd, char *Title, char *Filename, int HasChanged)
{
	static char Titlename[1024];

    static char tFilename[1024];

    strcpy(tFilename, Filename);

    if (LastOf(tFilename, '\\'))
    {
        strcpy(tFilename, LastOf(tFilename, '\\')+1);
    }


	strcpy(Titlename, Title);
	strcat(Titlename, " - [ ");
	if (strlen(tFilename)==0)
	   strcat(Titlename, SansTitre);
	else
	   strcat(Titlename, tFilename);
    
    if (HasChanged) strcat(Titlename, " * ]");
    else strcat(Titlename, " ]");

    SetWindowText (hwnd, Titlename) ;
}


