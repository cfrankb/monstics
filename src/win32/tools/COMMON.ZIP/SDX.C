
//
// Sdx.c
//

#include "sdx.h"

// Static Database Info..........................................

int LoadSDI(USER_SDI3HEADER *psSDIHead,
            char *szFilename)
{


    char SDIxx[] = "xxxx"; 
    FILE *sfile;
    USER_SDI3 *psSDI = NULL;
    USER_SDI3 *psPSDI = NULL;
    int x;
    USER_SDI3HEADER lsSDIHead;

    sfile = fopen(szFilename, "rb");
    if (sfile==NULL) return err_fileopen;

    fread(&lsSDIHead, sizeof(USER_SDI3HEADER), 1, sfile);

    memcpy(SDIxx, lsSDIHead.Id, 4);
    if (strcmp(SDIxx, "SDI3")!=0)
    {
        fclose(sfile);
        return err_format;
    }

    for (x=lsSDIHead.iNbObj; x; x--)
    {    
        if (psSDI==NULL)
        {
            psSDI = malloc(sizeof(USER_SDI3));
            fillmem(psSDI, 0,sizeof(USER_SDI3)); 
            lsSDIHead.pFirst = psSDI;
        }
        else
        {
            psSDI = malloc(sizeof(USER_SDI3));
            fillmem(psSDI, 0,sizeof(USER_SDI3)); 
        }
        fread(psSDI, sizeof(USER_SDI3), 1, sfile);

        if (psPSDI!=NULL)
            psPSDI->pNext = psSDI;
        psPSDI = psSDI;
    }

    fclose(sfile);

    *psSDIHead = lsSDIHead;

    return TRUE;
}


void FreeSDI(USER_SDI3HEADER *psSDIHead)
{
    USER_SDI3 *pSDI;
    USER_SDI3 *pSDIx;

    pSDI = psSDIHead->pFirst;
    for (;pSDI;)
    {

        pSDIx= pSDI;
        pSDI = pSDI->pNext;
        if (pSDIx) free(pSDIx);
    }

    psSDIHead->pFirst = NULL;

}


int SaveSDI(USER_SDI3HEADER *psSDIHead,
            char *szFilename)
{


    FILE *tfile;
    USER_SDI3 *psSDI;
    int x;

    tfile = fopen(szFilename, "wb");
    if (tfile==NULL) return err_fileopen;

    fwrite(psSDIHead, sizeof(USER_SDI3HEADER), 1, tfile);

    psSDI = psSDIHead->pFirst;
    
    for (x=psSDIHead->iNbObj; x; x--)
    {    
        fwrite(psSDI, sizeof(USER_SDI3), 1, tfile);
        psSDI = psSDI->pNext;
    }

    fclose(tfile);

    return TRUE;
}


void NewSDI(USER_SDI3HEADER *psSDIHead)
{

    fillmem( (void*)psSDIHead, 0, sizeof(USER_SDI3HEADER));
    memcpy(psSDIHead->Id, "SDI3",4);

}


USER_SDI3 *Make1xSDI(USER_OBL3HEADER *psOblHead)
{

    USER_SDI3 *pSDI;
    pSDI= malloc(sizeof(USER_SDI3));
    if (pSDI==NULL) return NULL;

    fillmem( (void*)pSDI, 0, sizeof(USER_SDI3));

    if (psOblHead!=NULL) 
    {
        memcpy(&pSDI->sOblHead, psOblHead, 
              sizeof(USER_OBL3HEADERLITE));
        
    }

    return pSDI;
}


void Add1xSDI(USER_SDI3HEADER *sSDIHead,
              USER_SDI3 *pSDI)
{

    USER_SDI3 *pPSDI;

    if (sSDIHead->pFirst ==NULL)
    {
        sSDIHead->pFirst = pSDI;    
        (sSDIHead->iNbObj)++;

    }
    else
    {

        pPSDI = sSDIHead->pFirst;
        for (; pPSDI->pNext; pPSDI =pPSDI->pNext);

        pPSDI->pNext = pSDI;

        (sSDIHead->iNbObj)++;

    }

}




// Static Database Object........................................


int LoadSDOasSDI(USER_SDI3HEADER *psSDIHead,
                 char *szFilename)
{
    char SDOxx[] = "xxxx"; 
    FILE *sfile;
    USER_SDI3 *psSDI = NULL;
    USER_SDI3 *psPSDI = NULL;
    int x;
    USER_SDI3HEADER lsSDIHead;
    USER_SDO3HEADER lsSDOHead;

    sfile = fopen(szFilename, "rb");
    if (sfile==NULL) return err_fileopen;

    fread(&lsSDOHead, sizeof(USER_SDO3HEADER), 1, sfile);

    memcpy(SDOxx, lsSDOHead.Id, 4);
    if (strcmp(SDOxx, "SDO3")!=0)
    {
        fclose(sfile);
        return err_format;
    }

    lsSDIHead.iNbObj = lsSDOHead.iNbObj;
    
    for (x=lsSDIHead.iNbObj; x; x--)
    {    
        if (psSDI==NULL)
        {
            psSDI = malloc(sizeof(USER_SDI3));
            fillmem(psSDI, 0,sizeof(USER_SDI3)); 
            lsSDIHead.pFirst = psSDI;
        }
        else
        {
            psSDI = malloc(sizeof(USER_SDI3));
            fillmem(psSDI, 0,sizeof(USER_SDI3)); 
        }
        fread(psSDI, sizeof(USER_SDI3), 1, sfile);

        if (psPSDI!=NULL)
            psPSDI->pNext = psSDI;
        psPSDI = psSDI;
    }

    fclose(sfile);

    *psSDIHead = lsSDIHead;

    return TRUE;


}




USER_SDO3 *Make1xSDO(char *pData,
                    int iPixLen,
                    int iPixHei,
                    int iFNTLen,
                    int iFNTHei)
{

    USER_SDO3 *pSDO;
    char *pEntry;

    if (pData==NULL)
    {
        iPixLen =0;
        iPixHei =0;
        iFNTLen =0;
        iFNTHei =0;
    }

    pSDO = malloc(iPixLen * iPixHei + sizeof(USER_SDO3));
    pSDO ->iPixLen = iPixLen;
    pSDO ->iPixHei = iPixHei;
    pSDO ->iFNTLen = iFNTLen;
    pSDO ->iFNTHei = iFNTHei;
    pSDO ->iEntrySize = iPixLen * iPixHei + sizeof(USER_SDO3);
    pSDO ->pNext = NULL;

    if (pData!=NULL)
    {
        pEntry = ((char *)pSDO) + sizeof(USER_SDO3);
        memcpy(pEntry, pData,iPixLen * iPixHei); 
    }

    return pSDO;
}

int SaveSDO (USER_SDO3HEADER *psSDOHead,
             char *szFilename)
{

    FILE *tfile;
    int x;

    USER_SDI3 *pSDI;
    USER_SDO3 *pSDOIma;
    USER_SDO3 *pSDOMap;

    tfile = fopen(szFilename, "wb");
    if (tfile==NULL) return err_fileopen;

    memcpy(psSDOHead->Id, "SDO3", 4);
    fwrite(psSDOHead, sizeof(USER_SDO3HEADER), 1, tfile);

    pSDI = psSDOHead->pFirstSdi;
    for (x=0; x<psSDOHead->iNbObj; x++)
    {
        fwrite(pSDI, sizeof(USER_SDI3), 1, tfile);
        pSDI = pSDI->pNext;
    }

    pSDOIma = psSDOHead->pFirstIma;
    for (x=0; x<psSDOHead->iNbImages; x++)
    {
        fwrite(pSDOIma, pSDOIma->iEntrySize, 1, tfile);
        pSDOIma = pSDOIma->pNext;

    }

    pSDOMap = psSDOHead->pFirstMap;
    for (x=0; x<psSDOHead->iNbImages; x++)
    {
        fwrite(pSDOMap, pSDOMap->iEntrySize, 1, tfile);
        pSDOMap = pSDOMap->pNext;
    }


    fclose(tfile);

    return TRUE;
}

void _FreeSDO(USER_SDO3HEADER *psSDOHead)
{
    USER_SDO3 *pSDO;
    USER_SDO3 *pSDOx;

    pSDO = psSDOHead->pFirstIma;
    for (;pSDO; )
    {
        pSDOx = pSDO->pNext;
        free(pSDO);
        pSDO = pSDOx;
    }

    pSDO = psSDOHead->pFirstMap;
    for (;pSDO; )
    {
        pSDOx = pSDO->pNext;
        free(pSDO);
        pSDO = pSDOx;
    }

    psSDOHead->pFirstIma = NULL;
    psSDOHead->pFirstMap = NULL;

}



int CreateSDO(USER_SDI3HEADER *psSDIHead,
                char *szFilename)
{

    USER_OBL3HEADER sOBLHead;
    USER_SDO3HEADER sSDOHead;
    USER_SDI3 *psSDI;
    int x;
    int xx;
    int iStatus;
    char szMapName[256];
    char szSdoName[256];
    char *pLastDot;
    char szTemp [256];
    char szHex[8];

    USER_OBL3 *pOBL;
    USER_SDO3 *pSDOIma;
    USER_SDO3 *pSDOMap;

    FILE *tfile;

    if ( (szFilename==NULL) || (strlen(szFilename)==0) )
    {
        szFilename = "(SansTitre).XXX";
    }

    strcpy(szMapName, szFilename);
    strcpy(szSdoName, szFilename);
    pLastDot = LastOf(szMapName, '.');
    strcpy(pLastDot, ".map");
    pLastDot = LastOf(szSdoName, '.');
    strcpy(pLastDot, ".sdo");   

    tfile = fopen(szMapName, "wt");
    fillmem(&sSDOHead, 0, sizeof(USER_SDO3HEADER));

    psSDI = psSDIHead->pFirst;

    for (x=0; x<psSDIHead->iNbObj; x++)
    {                   
        
        // Read Object (.IMA, .MCX or .OBL)
        if (psSDI->bDeleted==FALSE)
            iStatus = Import_ANY2OBL(&sOBLHead, 
                       (psSDI->sOblHead).szFilename);
        else
            iStatus = err_notwanted;

        strcpy(szTemp, (psSDI->sOblHead).szFilename);        
        if ((iStatus==TRUE) &&
            ((_stricmp( LastOf( (psSDI->sOblHead).szFilename, '.'), 
                ".obl") ==0)))
            memcpy(&psSDI->sOblHead, &sOBLHead, 
                       sizeof(USER_OBL3HEADERLITE));

        if (iStatus == TRUE)
        {
            (psSDI->sOblHead).iLen=sOBLHead.iLen;            
            (psSDI->sOblHead).iHei=sOBLHead.iHei;            
            (psSDI->sOblHead).iNbrImages=sOBLHead.iNbrImages; 
            (psSDI->sOblHead).PtrFirst =
                sOBLHead.PtrFirst;

             strcpy((psSDI->sOblHead).szFilename,szTemp);

        }
        else
        {
            (psSDI->sOblHead).iLen=0;
            (psSDI->sOblHead).iHei=0;
            (psSDI->sOblHead).iNbrImages =0; 
            (psSDI->sOblHead).PtrFirst =NULL;

             strcpy((psSDI->sOblHead).szFilename,szTemp);       
        }


        pOBL = (psSDI->sOblHead).PtrFirst;
        // Add Images and Maps to USER_SDO3HEADER
        for (xx=0; (DWORD)xx<(psSDI->sOblHead).iNbrImages; xx++)
        {

            if (sSDOHead.pFirstIma==NULL)
            {
                sSDOHead.pFirstIma = 
                    Make1xSDO(
                        pOBL->PtrBits,
                        (psSDI->sOblHead).iLen * OBL3FNT,
                        (psSDI->sOblHead).iHei * OBL3FNT,
                        (psSDI->sOblHead).iLen,
                        (psSDI->sOblHead).iHei );

                 pSDOIma = sSDOHead.pFirstIma;


                sSDOHead.pFirstMap = 
                    Make1xSDO(
                        pOBL->PtrMap,
                        (psSDI->sOblHead).iLen * 2,
                        (psSDI->sOblHead).iHei * 2,
                        (psSDI->sOblHead).iLen,
                        (psSDI->sOblHead).iHei );

                pSDOMap =sSDOHead.pFirstMap;


            }
                    
            else
            {
                pSDOIma->pNext =
                    Make1xSDO(
                        pOBL->PtrBits,
                        (psSDI->sOblHead).iLen * OBL3FNT,
                        (psSDI->sOblHead).iHei * OBL3FNT,
                        (psSDI->sOblHead).iLen,
                        (psSDI->sOblHead).iHei );

                 pSDOIma = pSDOIma->pNext;


                pSDOMap->pNext = 
                    Make1xSDO(
                        pOBL->PtrMap,
                        (psSDI->sOblHead).iLen * 2,
                        (psSDI->sOblHead).iHei * 2,
                        (psSDI->sOblHead).iLen,
                        (psSDI->sOblHead).iHei );

                pSDOMap = pSDOMap->pNext;  
                
            }


            pOBL = pOBL->PtrNext;
            sSDOHead.iSizeImage = 
                 sSDOHead.iSizeImage + pSDOIma->iEntrySize; 
                   
            sSDOHead.iSizeMap = 
                 sSDOHead.iSizeMap + pSDOMap->iEntrySize; 
        }


        // Fill-In Headers...
        psSDI->iFirstImaNo = sSDOHead.iNbImages;

        sSDOHead.iNbImages = sSDOHead.iNbImages 
            + (psSDI->sOblHead).iNbrImages;

        if (sSDOHead.pFirstSdi==NULL)
        {
            sSDOHead.pFirstSdi = psSDI;
        }

        psSDI = psSDI->pNext;

        if (iStatus==TRUE)
           FreeOBL3(&sOBLHead);  // Lib�re la m�moire allou�e

        Int2Hex((WORD)x, szHex);
        strcpy(szTemp, LastOf(szTemp, '\\')+1);
        fprintf(tfile, "%s %-60s",szHex, szTemp);
        strcpy(szTemp,"");
        if (tfile)
        {
            switch (iStatus)
            {
            case TRUE:
                strcat (szTemp, " - Ok\n");
                break;
            case err_fileopen:
                strcat (szTemp, " - Erreur de lecture\n");
                break;
            case err_memory:
                strcat (szTemp, " - M�moire insuffisante\n");
                break;
            case err_format:
                strcat (szTemp, " - Format incorrect\n");
                break;
            case err_filename:
                strcat (szTemp, " - Nom incorrectt\n");
                break;
            case err_notwanted:
                strcat (szTemp, " - Non-d�sir�\n");
                break;

            default:
                strcat (szTemp, " - Erreur inconnue\n");
                break;
            
            }

            fprintf(tfile, "%s", szTemp);
        
        }

    }

    sSDOHead.iNbObj = psSDIHead->iNbObj;
    fclose(tfile);
    iStatus = SaveSDO(&sSDOHead, szSdoName);
    _FreeSDO(&sSDOHead);
    return iStatus;

}


//
//
//
void FreeSDIObjTable(USER_STRINGID *psObjTab)
{
    USER_STRINGID *psItem;
    if (psObjTab!=NULL)
    {
        psItem = psObjTab;
        for (;;)
        {
            if (psItem->cHelpText==NULL) break;
            free(psItem->cHelpText);
            psItem++;
        }
    
        free(psObjTab);
    }
}

void MakeSDIObjTable(USER_STRINGID **ppsObjTab,
                     USER_SDI3 *pFirst,
                     int iNbObj)
{
    int iCpt;
    char szTemp[256];
    char szTemp2[324];

     *ppsObjTab = malloc ((iNbObj+3)*sizeof(USER_STRINGID));

     (*ppsObjTab)->iItemId =0;
     (*ppsObjTab)->cHelpText = MakeString("(Inutilis�)");

     for (iCpt=1; iCpt<=iNbObj; iCpt++)
     {

        if (pFirst==NULL) break;

        if(strlen(pFirst->sOblHead.szName)==0)
        {
            strcpy(szTemp,
                LastOf(pFirst->sOblHead.szFilename, '\\')+1); 

            *LastOf(szTemp, '.')=0;
        }
        else
        {
            strcpy(szTemp,pFirst->sOblHead.szName); 
        }

        wsprintf(szTemp2, "%s, (0x%x)", szTemp, iCpt-1); 
        strcpy(szTemp, szTemp2);               

        (*ppsObjTab+iCpt)->iItemId =iCpt;
        (*ppsObjTab+iCpt)->cHelpText = MakeString(szTemp);

        pFirst = pFirst->pNext;

     };

     (*ppsObjTab+iCpt)->iItemId =0;
     (*ppsObjTab+iCpt)->cHelpText = NULL;


}



