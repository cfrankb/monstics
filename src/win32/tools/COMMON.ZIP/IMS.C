
//
// Ims.C
//


#include "include.h"
#include "ims.h"
#include "user_err.h"
#include "common.h"

BOOL ValidateFilename(char *filename, char *Id);

void FreeIms(USER_IMSHEADER *header)
{
	if (header->PtrObjs)
	  free(header->PtrObjs);
	if (header->PtrTiles)
	  free (header->PtrTiles);

	header->NbObjs =0;
	header->NbTiles =0;

}
/*
int LoadIms(char *filename, USER_IMSHEADER *header)
{

	USER_IMS *PtrObjs;
	int y; int yy;
	int x; int xx;
	FILE *sfile;

	int status;
    status = ValidateFilename(filename, "MCX3");
	if (status!=TRUE) return status;		

    if (strlen(filename)==0) return(err_fileopen);

	sfile= fopen(filename, "rb");
	if (sfile==0) return (err_fileopen);

	fread(header, sizeof(USER_IMSHEADER)-8, 1,sfile);
	header->PtrObjs = malloc(header->NbObjs * sizeof(USER_IMS));
	header->PtrTiles= malloc(header->NbTiles*32*32);

	for (xx=0,yy=0, y = header->NbObjs; y;y--)
	{	
		PtrObjs = (USER_IMS*)(header->PtrObjs);
		fread((char*)(header->PtrObjs)+yy*sizeof(USER_IMS),
			  sizeof(USER_IMS), 1, sfile);

		fread((char*)(header->PtrTiles)+xx*32*32, 32*32, 
			     1,sfile);
		xx++;	

		x= ((PtrObjs)->NbrImages); x--;
		if (x) fseek(sfile, 32*32*x, SEEK_CUR); 
	}
	fclose(sfile);
	return(TRUE);
  
}*/

/*
int LoadLevel(char *filename, USER_IMSHEADER *imsheader,
			  USER_LEVEL *level)
{
	FILE *sfile;
	int status;
    if (strlen(filename)==0) return(err_fileopen);

    status = ValidateFilename(filename, "LEVB");
	if (status!=TRUE) return status;		


	sfile = fopen(filename, "rb");
	if (sfile==0) return (err_fileopen);
	fread(level, sizeof(USER_LEVEL), 1, sfile);
	fclose(sfile);

    return LoadIms(level->ImsName, imsheader);
}
*/


int SaveLevel(char *filename, USER_LEVEL *level)
{
	FILE *sfile;

    if (*filename==0) return err_fileopen;

    if (SamePath(filename, level->ImsName) && LastOf(level->ImsName, '\\'))
        strcpy(level->ImsName, LastOf(level->ImsName, '\\')+1);

    memcpy(level->Id, "LEVB",4);
	sfile = fopen(filename, "wb");
	if (sfile==0) return (err_fileopen);
	fwrite(level, sizeof(USER_LEVEL), 1, sfile);
	fclose(sfile);
	return TRUE;

}

int LoadLevel(char *filename, USER_IMSHEADER *imsheader,
			  USER_LEVEL *level)
{
	FILE *sfile;
	int status;
    if (strlen(filename)==0) return(err_fileopen);

    status = ValidateFilename(filename, "LEVB");
	if (status!=TRUE) return status;		


	sfile = fopen(filename, "rb");
	if (sfile==0) return (err_fileopen);
	fread(level, sizeof(USER_LEVEL), 1, sfile);
	fclose(sfile);

    return LoadIms(level->ImsName, imsheader);
}


int LoadIms(char *filename, USER_IMSHEADER *header)
{

	USER_IMS *PtrObjs;
	int y; int yy;
	int x; int xx;
	FILE *sfile;
	sfile= fopen(filename, "rb");
	if (sfile==0) return (err_fileopen);

	fread(header, sizeof(header)-8, 1,sfile);
	header->PtrObjs = malloc(header->NbObjs * sizeof(USER_IMS));
	header->PtrTiles= malloc(header->NbTiles*32*32);

	for (xx=0,yy=0, y = header->NbObjs; y; y--)
	{	
		PtrObjs = ((USER_IMS*)(header->PtrObjs) )+yy;
		fread((char*)(header->PtrObjs)+yy*sizeof(USER_IMS),
			  sizeof(USER_IMS), 1, sfile);

        PtrObjs->PtrFirstImage = (char*)(header->PtrTiles)+xx*32*32;
		for (x= ((PtrObjs)->NbrImages);x; x--, xx++)
		{
		  fread((char*)(header->PtrTiles)+xx*32*32, 32*32, 
			     1,sfile);
		
		}
	}
  
}

