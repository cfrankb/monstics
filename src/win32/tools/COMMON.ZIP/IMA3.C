
//
// ima3.c
//

#include "ima3.h"

// *****************************************************************
//
// StretchBitmap:
// Produce an output image increased in size by the desired factor.
//
// *****************************************************************
char *StretchBitmap(USER_STDIMA sStdIma, char *ImaData, uint Factor)
{

    uint len;
    uint hei;
    uint x;
    uint y;
    uint x2;
    uint y2;
    char *dest;
    char car;

    len = sStdIma.len;
    hei = sStdIma.hei;

    dest = malloc(len*hei*64*Factor*Factor);
    if (dest==NULL) return NULL;

    for (y=0; y<hei*8; y++)
    {
        for (x=0; x<len*8; x++)
        {
            car = *(ImaData + x + y*len*8);
            for (y2=0; y2<Factor; y2++)
            {
                for (x2=0; x2<Factor; x2++)
                {
                      *(dest+(y*Factor+y2)*len*8*Factor+
                            (x*Factor+x2)) =car;
                    

                }

            }



        }
    }

    return dest;

}



// *****************************************************************
//
// Ima2Bitmap:
// Convert a FNT based image into a linear image that
// can be displayed.
//
// *****************************************************************
char *Ima2Bitmap(USER_STDIMA sStdIma, char *ImaData)
{
    
    uint x;
    uint y;
    uint x2;
    uint y2;

    uint len;
    uint hei;

    char *dest;
   
    len = sStdIma.len;
    hei = sStdIma.hei;

    if (ImaData ==NULL) return NULL;

    dest = malloc (len*hei*64);
    if (dest==NULL) return NULL; 

    for (y=0; y<hei; y++)    
    {
        for (x=0; x<len; x++)
        {
            for (y2=0; y2<8; y2++)
            
            {
                for (x2=0; x2<8; x2++)
                {
                    *(dest + x*8+x2+(y*8+y2)*len*8) = 16+
                        *(ImaData+(x+y*len)*64+x2+y2*8);
                    
                }
            }

        }
    }
    


    return dest;

}

// *************************************************************
//
// LoadIma
// Put in memory a IMA (FNT) or IMC1 (compressed FNT) based image
// and return a status code.
//
// *************************************************************
int LoadIma(const char *filename, USER_STDIMA *sStdIma, char **ppImaData)
{

    FILE *sfile;

    uchar *IMC1Data;
    char IMC1id[] = "IMC1";   
    char IMC1xx[] = "xxxx";
    uchar *tampon;
    uchar *ptr;
    uchar *ptrIMC1;
    uchar *ImaData;
    unsigned int cpt;
    unsigned int loop;
    unsigned char car;
    unsigned int SizeData;
    unsigned int wsize;

    unsigned int pos;
    USER_IMAHEADER *ptr_ima;
    USER_IMC1HEADER *ptr_imc1;

    sfile = fopen (filename , "rb");
    if (sfile==NULL)
        return err_fileopen;

    tampon = malloc(6);
    ptr_ima = (USER_IMAHEADER *)tampon;
    ptr_imc1 = (USER_IMC1HEADER *)tampon;

    fread(tampon, 6,1, sfile);

    memcpy(IMC1xx, &ptr_imc1->Id,4);
    if (strcmp(IMC1id, IMC1xx)==0)
    {

        sStdIma->len = ptr_imc1->len;
        sStdIma->hei = ptr_imc1->hei;

        fseek(sfile, 6, SEEK_SET);
        fread(&SizeData, 4,1, sfile);

        IMC1Data = malloc(SizeData);
        ImaData = malloc(ptr_imc1->len * ptr_imc1->hei*64 +1);
        fread(IMC1Data, SizeData,1, sfile);
        fclose(sfile);

        ptr = ImaData;
        ptrIMC1 = IMC1Data;

        for (cpt=0; (cpt<= SizeData-1) ;)
        {

            if (*ptrIMC1==0xff)
            {
                
                car = *(ptrIMC1+1);
                for (loop = (*(ptrIMC1+2) + *(ptrIMC1+3) *256);
                            (loop !=0 )                                 
                                ; loop--, ptr++)
                    *ptr = car;

                ptrIMC1 = ptrIMC1+4;
                cpt = cpt+4;

            }
            else
            {
                *ptr = *ptrIMC1;                                
                ptr ++;
                ptrIMC1 ++;
                cpt++;
            }
        }

        *ppImaData = ImaData;
        free(IMC1Data);
        free(tampon);
        fclose(sfile);

        return TRUE;

    }
    else
    {
        if ((ptr_ima->len <=0x40) && 
              (ptr_ima->hei <=0x30) &&
              (ptr_ima->len) &&
              (ptr_ima->hei))
        {

            fseek(sfile, 0, SEEK_END);
            pos = ftell(sfile);
            wsize =  ptr_ima->len * ptr_ima->hei * 64 +2;

            if (wsize !=pos)
            {
                fclose(sfile);
                free(tampon);
                return err_format;
            }
            
            sStdIma->len = ptr_ima->len;
            sStdIma->hei = ptr_ima->hei;

            fseek(sfile, 2, SEEK_SET);
            ImaData = malloc( ptr_ima->len * ptr_ima->hei * 64);
            fread(ImaData, ptr_ima->len * ptr_ima->hei * 64, 1, sfile);            
            free(tampon);
            fclose(sfile);
            *ppImaData = ImaData;
            return TRUE;        
        }
        else
        {
            fclose(sfile);
            free(tampon);
            return err_format;
        }

    }
  
}
