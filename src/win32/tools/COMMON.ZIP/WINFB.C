
//
// WinFb.c
//

#include "winfb.h"

//
// HWND RegisterAndCreateWindow(HINSTANCE hInstance, 
//                             USER_WINDOW sUserWindow)
//

HWND RegisterAndCreateWindow(HINSTANCE hInstance, 
                             USER_WINDOW sUserWindow)
{

    WNDCLASS wndclass;
    ATOM atom;
    uint cx,cy;
    HWND hwnd;

    cx  = GetSystemMetrics (SM_CXSCREEN)  ;
    cy  = GetSystemMetrics (SM_CYSCREEN)  ;

     // Class for Mother MiniApp's Window
         
     wndclass.style         = sUserWindow.iClassStyle;
     wndclass.lpfnWndProc   = sUserWindow.iClassProc ;
     wndclass.cbClsExtra    = 0 ;
     wndclass.cbWndExtra    = 0 ;
     wndclass.hInstance     = hInstance ;
     wndclass.hIcon         = sUserWindow.hIcon ;//LoadIcon (hInstance, "ABC") ;
     wndclass.hCursor       = sUserWindow.hCursor; //LoadCursor (NULL, IDC_ARROW) ;
     wndclass.hbrBackground = sUserWindow.hBrush; //(HBRUSH) GetStockObject (GRAY_BRUSH) ;
     wndclass.lpszMenuName  = sUserWindow.cMenuName;//M2INT(AppMenu);
     wndclass.lpszClassName = sUserWindow.cClassName;//AppName;

     atom = RegisterClass (&wndclass);

	 hwnd =  CreateWindowEx( 
				WS_EX_ACCEPTFILES,                      /* no extended styles        */ 
			    M2INT(atom),            /* window class              */ 
				sUserWindow.cWndTitle,  /* text for window title bar */ 
			    sUserWindow.iWndStyle,  /* window styles             */ 
				 
				sUserWindow.iWndX,	    /* default horizontal position */ 
			    sUserWindow.iWndY,		/* default vertical position   */ 
				sUserWindow.iWndLen,	/* default width               */ 
			    sUserWindow.iWndHei,	/* default height              */ 
				(HWND) NULL,			/* no parent for overlapped windows  */ 
			    (HMENU) NULL,			/* window class menu                 */ 
				hInstance,				/* instance owning this window       */ 
                (LPVOID) NULL           /* pointer not needed                */ 
                  );

    hAppInstance= hInstance;

    UpdateWindow(hwnd);
    return(hwnd); 
}


int GetWindowLenght(HWND hwnd)
{
    RECT sRect;
    int iSize =0;

    if (GetWindowRect(hwnd, &sRect))
        iSize = sRect.right - sRect.left +1;

    return iSize;
  
}

int GetWindowHeight(HWND hwnd)
{
    RECT sRect;
    int iSize =0;

    if (GetWindowRect(hwnd, &sRect))
        iSize = sRect.bottom - sRect.top +1;

    return iSize;
  
}
