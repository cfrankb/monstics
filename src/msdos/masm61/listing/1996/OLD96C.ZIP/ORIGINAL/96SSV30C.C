
/* Statics System V3 runtime librairy 96SSV30C
   Autor  : FRANCOIS BLANCHETTE
   Purpose: Install a new SVGA support for game platforms.
*/

// STATICS SYSTEM V3.0 FOR DOS

typedef struct
{
	unsigned char VESASignature[4];
	unsigned int VESAVersion;
	unsigned char far*OEMStringPtr;
	unsigned int Capabilities[4];
	unsigned int far* VideoModePtr;
} VGAINFOBLOCK;

typedef struct
{
 //;mandatory information
unsigned int ModeAttributes;		// dw ?		;mode attributes
unsigned  char WinAAttributes;		//db ?		;Window A attributes
unsigned  char WinBAttributes;		//db ?		;Window B attributes
unsigned  int WinGranularity;		//dw ?		;window granularity
unsigned  int WinSize;	   		//	dw ?		;window size
unsigned  int WinASegment;		//dw ?		;Window A start segment
unsigned  int WinBSegment;	        //	dw ?		;Window B start segment
unsigned  char far *WinFuncPtr;		//dd ?		;pointer to window function
unsigned  int BytesPerScanLine;		//dw ?		;bytes per scan line

 //;extended information
 //;optional information
unsigned  int XResolution;	   //	dw ?		;horizontal resolution
unsigned  int YResolution;	   //	dw ?		;vertical resolution
unsigned  char XCharSize;	   //	db ?		;character cell width
unsigned  char YCharSize;	   //db ?		;character cell height
unsigned  char NumberOfPlanes;     //		db ?		;number of memory planes
unsigned  char BitsPerPixel;	   //	db ?		;bits per pixel
unsigned  char NumberOfBanks ;     //		db ?		;number of banks
unsigned  char MemoryModel;	   //	db ?		;memory model type
unsigned  char BankSize;	 	   //	db ?		;bank size in K
} MODEINFOBLOCK;


int  ss_returnsvgainfo(VGAINFOBLOCK *buffer);
int  ss_returnsvgamodeinfo(MODEINFOBLOCK *buffer, unsigned int mode);
int  ss_setsvgamode(unsigned int mode);
int  ss_getsvgamode(unsigned int *mode);
int  ss_setsvgawindow(char win, unsigned int pos);
int  ss_getsvgawindow(char win, unsigned int *pos);
void ss_setfastwindow(char win, unsigned int pos, MODEINFOBLOCK *info);

#define SAVE asm{push di; push es}
#define RESTORE asm{pop es; pop di}

int ss_returnsvgainfo(VGAINFOBLOCK  *buffer)
{
	int retour;
	SAVE;
	asm { les di, buffer
		  mov al,0
		  mov ah,0x4f
		  int 0x10
		  mov &retour, ax
		}
	RESTORE;
	return(retour);
}

int ss_returnsvgamodeinfo(MODEINFOBLOCK *buffer, unsigned int mode)
{
	int retour;
	SAVE;
	asm { mov al,01
		  mov cx,mode
		  mov ah,0x4f
		   les di, buffer
		   int 0x10
		   mov &retour,ax
		  }
	RESTORE;
	return(retour);
}

int ss_setsvgamode(unsigned int mode)
{
	int retour;
	asm { mov ah,0x4f
		  mov al,2
		  mov bx,mode
		  int 0x10

		  mov &retour, ax
		}
		return(retour);
}

int ss_getsvgamode(unsigned int *mode)
{
	int retour;
	int MODE;

	asm { mov ah,0x4f
		  mov al,3
		  int 0x10

		  mov &retour, ax
		  mov &MODE,bx
		}

		*mode= MODE;
		return(retour);
}

int ss_setsvgawindow(char win, unsigned int pos)
{
	int retour;
	asm {
			mov ah, 0x4f
			mov al,5
			mov bh,0
			mov bl, win
			mov dx, pos;
			int 0x10
			mov &retour, ax
		}
	return(retour);
}


int ss_getsvgawindow(char win, unsigned int *pos)
{
	int POS;
	int retour;
	asm {
			mov ah, 0x4f
			mov al,5
			mov bh,1
			mov bl, win
			int 0x10
			mov &retour, ax
			mov &POS, dx
		}
			*pos = POS;

	return(retour);
}
