#include <user\friendly.h>
#include <stdlib.h>
//#include "vesa.h"

#define SAVE asm{push di; push es}
#define RESTORE asm{pop es; pop di}
#define uchar unsigned char
#define uint unsigned int
typedef struct
{
	unsigned char VESASignature[4];
	unsigned int VESAVersion;
	unsigned char far*OEMStringPtr;
	unsigned int Capabilities[4];
	unsigned int far* VideoModePtr;
} VGAINFOBLOCK;

typedef struct
{
 //;mandatory information
unsigned int ModeAttributes;		// dw ?		;mode attributes
unsigned  char WinAAttributes;		//db ?		;Window A attributes
unsigned  char WinBAttributes;		//db ?		;Window B attributes
unsigned  int WinGranularity;		//dw ?		;window granularity
unsigned  int WinSize;	   		//	dw ?		;window size
unsigned  int WinASegment;		//dw ?		;Window A start segment
unsigned  int WinBSegment;	        //	dw ?		;Window B start segment
unsigned long WinFuncPtr;		//dd ?		;pointer to window function
unsigned  int BytesPerScanLine;		//dw ?		;bytes per scan line

 //;extended information
 //;optional information
unsigned  int XResolution;	   //	dw ?		;horizontal resolution
unsigned  int YResolution;	   //	dw ?		;vertical resolution
unsigned  char XCharSize;	   //	db ?		;character cell width
unsigned  char YCharSize;	   //db ?		;character cell height
unsigned  char NumberOfPlanes;     //		db ?		;number of memory planes
unsigned  char BitsPerPixel;	   //	db ?		;bits per pixel
unsigned  char NumberOfBanks ;     //		db ?		;number of banks
unsigned  char MemoryModel;	   //	db ?		;memory model type
unsigned  char BankSize;	 	   //	db ?		;bank size in K
} MODEINFOBLOCK;

typedef struct
{
  unsigned int boutons;
  unsigned int x;
  unsigned int y;
  unsigned int oldx;
  unsigned int oldy;

  unsigned char mouse[16][16];
  unsigned char temp[16][16];
} MOUSE;

typedef struct
{
	char rouge;
	char vert;
	char bleu;
} COULEUR;

// structures windows
typedef struct
{
  long biSize;		// Taille du Record
  long biWidth;		// Largeur du bitmap
  long biHeight;        // Hauteur du bitmap
  int biPlanes;	// Nombre de plan (toujours 1)
  int biBitCount;	// Nombre de bits par couleur 	8 dn notre cas)
  long biCompression;	// toujours BI_RGB
  long biSizeImage;	// on s'en fout	(n/a)
  long biXPelsPerMeter;	// on s'en fout (n/a)
  long biYPelsPerMeter; // on s'en fout	(n/a)
  long biClrUsed;	// nombre de couleurs utilis�es	(256 dn notre cas)
  long biClrImportant;	// nbr de couleurs significative(0 = toutes)
} BITMAPINFOHEADER;

typedef struct
{
	char rgbBlue;
	char rgbGreen;
	char rgbRed;
	char rgbReserved; // doit �tre toujours z�ro
}  RGBQUAD;

typedef struct
{
	BITMAPINFOHEADER bmiHeader;
	RGBQUAD          bmiColors[256];
} BITMAPINFO;

int  ss_returnsvgainfo(VGAINFOBLOCK *buffer);
int  ss_returnsvgamodeinfo(MODEINFOBLOCK *buffer, unsigned int mode);
int  ss_setsvgamode(unsigned int mode);
int  ss_getsvgamode(unsigned int *mode);
int  ss_setsvgawindow(char win, unsigned int pos);
int  ss_getsvgawindow(char win, unsigned int *pos);
void ss_setfastwindow(char win, unsigned int pos, unsigned long ptrwin);
void ss_getfastwindow(char win, unsigned int *pos, unsigned long ptrwin);
void ss_drawmouse(MOUSE *mouse, MODEINFOBLOCK infoblock);
void ss_undrawmouse(MOUSE *mouse, MODEINFOBLOCK infoblock);
void ss_readmouse(MOUSE *mouse);
int  ss_initmouse(MOUSE *mouse);
void ss_setrangey(unsigned min, unsigned max);
void ss_setrangex(unsigned min, unsigned max);
void ss_drawpix(unsigned x, unsigned y, unsigned char color, MODEINFOBLOCK);
void ss_draw2pix(unsigned x, unsigned y, unsigned int color, MODEINFOBLOCK);
void ss_draw4pix(unsigned x,unsigned y,unsigned long color,MODEINFOBLOCK);
void ss_drawundermouse(unsigned int x, unsigned int y, char color, MOUSE *mouse);
void ss_tellwinposfor(unsigned int x,unsigned int y,MODEINFOBLOCK infoblock,unsigned int *pos,unsigned int *where);
void ss_drawrectangle(unsigned int x,
					  unsigned int y,
					  unsigned int lenght,
					  unsigned int height,
					  unsigned char color,
					  MODEINFOBLOCK infoblock);
int ss_loadbmp(const char *name, BITMAPINFO *PTRbitmapinfo, char far **dib);
void ss_getvideorgb(COULEUR *rgb);
void ss_setvideorgb(COULEUR *rgb);
void ss_setcolor( unsigned int color, uchar red, uchar green, uchar blue);
void ss_usebmpcolors(BITMAPINFO);

	/*
GetRegisters PROC
			pushall
		mov ah,10h
			mov al,17h
			mov bx,0
			mov cx,256
			set es,DATA
			mov dx,offset C_Registers
		int 10h
			popall
			ret
GetRegisters ENDP

;-------------------------------------------------------------------------

	  */

void ss_getvideorgb(COULEUR *rgb)
{
	SAVE;
	asm {  mov ah, 0x10
		   mov al, 0x17
		   mov bx,0
		   mov cx, 256
		   les dx,rgb
		   int 0x10
		}
	RESTORE
}

/*FillRegisters PROC

			pushall
				call DisableRefresh
		mov ah,10h
			mov al,12h
			mov bx,0
			mov cx,256
			set es,DATA
			mov dx,offset C_Registers
		int 10h
			popall
				call EnableRefresh
			ret
FillRegisters ENDP*/


void ss_setvideorgb(COULEUR *rgb)
{
	asm {
		mov ah,0x10
		mov al, 0x12
		mov bx,0
		mov cx,256
		les dx, rgb
		int 0x10
		}

}

void ss_usebmpcolors(BITMAPINFO bitmapinfo__)
{
	COULEUR couleurs[256];
	uint x;

	for (x=0; x<256; x++)
	{
		couleurs[x].rouge = bitmapinfo__.bmiColors[x].rgbRed;
		couleurs[x].bleu = bitmapinfo__.bmiColors[x].rgbBlue;
		couleurs[x].vert = bitmapinfo__.bmiColors[x].rgbGreen;
	}

	ss_setvideorgb(couleurs);
}



/*_SetColor	PROC NEAR PASCAL, ColorReg:WORD, Red:BYTE, Green:BYTE, Blue:BYTE
		pushall
				mov ah,10h
				mov al,10h
				mov bx,ColorReg
				mov ch,Green
				mov cl,Blue
				mov dh,Red
				int 10h
				popall
				ret
_SetColor       ENDP*/

void ss_setcolor( unsigned int color, uchar red, uchar green, uchar blue)
{
	SAVE;
	asm { mov ah,0x10
		  mov al,0x10
		  mov bx, color
		  mov ch, green
		  mov cl,blue
		  mov dh, red
		  int 0x10
		  }
	RESTORE;

}

void ss_setrangey(unsigned min, unsigned max)
{
	asm {mov ax, 8
		 mov cx, min
		 mov dx, max
		int 0x33
		}
}

void ss_setrangex(unsigned min, unsigned max)
{
	asm {mov ax, 7
		 mov cx, min
		 mov dx, max
		int 0x33
		}
}

void ss_drawundermouse(unsigned int x, unsigned int y, char color, MOUSE *mouse)
{
	mouse->temp[x][y]=color;
}

