

//
// Toolbox.c
//

#include "include.h"

LRESULT CALLBACK ToolboxWndProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{        
PAINTSTRUCT ps ;
    HDC         hdc ;
	BOOL fAppActive;

	
		switch (iMsg)
		{

        case WM_CLOSE :
        return 0 ;
		
		case WM_LBUTTONDBLCLK:
        return TRUE;

		case WM_LBUTTONDOWN:
        return 0 ;

		case WM_RBUTTONDOWN:
        return 0 ;

		case WM_ACTIVATEAPP:

            fAppActive = (BOOL)wParam;
            AppActivate(FALSE);
            if (hpal)
            {
                hdc = GetDC(hwnd);

                UnrealizeObject(hpal);
                SelectPalette(hdc, hpal, FALSE);
                RealizePalette(hdc);
                ReleaseDC(hwnd, hdc);
            }
        
         break;
	
         case WM_CREATE :

				if (hpal)
				{
					hdc = GetDC(hwnd);

					UnrealizeObject(hpal);
					SelectPalette(hdc, hpal, FALSE);
					RealizePalette(hdc);				
					
					ReleaseDC(hwnd, hdc);
				}

		   return 0 ;



		    case WM_PAINT :
			  		hdc = BeginPaint(hwnd,&ps);					
                    //PaintPaletteWithBitmap(hdc, bitPalette);
       				EndPaint(hwnd,&ps);
		    return 0L;

 
	
		}
         return DefWindowProc (hwnd, iMsg, wParam, lParam) ;

	}  


//
//
//

ATOM RegisterToolboxClass()
{
	WNDCLASS wc;
    ATOM atom;
    // *****************  Class for the ChildWindow ************************
	wc.style = CS_BYTEALIGNWINDOW |
		       CS_HREDRAW | CS_VREDRAW | CS_OWNDC | CS_DBLCLKS;
	wc.lpfnWndProc = ToolboxWndProc; 
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 4;
	wc.hInstance = hAppInstance;
	wc.hIcon = NULL ;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = "Toolbox" ; 

	atom = RegisterClass(&wc);
    return atom;
}
