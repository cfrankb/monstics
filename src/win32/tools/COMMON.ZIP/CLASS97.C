
//
// Class97.c
//

#include "Class97.h"

char *szOblEvents[] =
{
    "When touched",
    "When extra #0",
    "When action key pressed",
    "When dead",
    "When hurt",
    "When trigger called",
    "When reborn",
    "When extra #1",
    "When extra #2",
    "When extra #3",
    NULL
};

USER_STRINGID sOblClass[] =
{

    
    0x0,  "(Background)",
    0x1,  "Antigravity",
    0x2,  "Water",
    0x4,  "Lava",
    0x5,  "Slime",
    0x6,  "Jump Throufht",
    0x10, "Full Brick",
    0x11, "Move Up Only",
    0x12, "Move Dn Only",
    0x13, "Move lf Only",
    0x14, "Move rg Only",
    0x15, "Pull Up",
    0x16, "Pull Down",
    0x17, "Pull Lf",
    0x18, "Pull Rg",
    0x79, "Stop",

    0x81, "Player",
    0x82, "G�n�ric objs",
    0x83, "Visible to",
    0x84, "Doors(Open to)",
    0x85, "Goal",
    0x90, "Dummy",
    0x91, "COS 1.0 Idiots",
    0x9a, "Computer v1",
    0x9b, "Computer v2",
    0xa0, "Drone Up & Down",
    0xa1, "Drone Lf & Right",
    0xa2, "Platform UP/DOWN",
    0xa3, "Platform LF/RIGHT",
    0xb0, "Player Bullets",
    0xb1, "Others Bullets",

    0xc0, "zCustom 0xc0",
    0xc1, "zCustom 0xc1",
    0xc2, "zCustom 0xc2",
    0xc3, "zCustom 0xc3",
    0xc4, "zCustom 0xc4",
    0xc5, "zCustom 0xc5",
    0xc6, "zCustom 0xc6",
    0xc7, "zCustom 0xc7",
    0xc8, "zCustom 0xc8",
    0xc9, "zCustom 0xc9",
    0xca, "zCustom 0xca",
    0xcb, "zCustom 0xcb",
    0xcc, "zCustom 0xcc",
    0xcd, "zCustom 0xcd",
    0xce, "zCustom 0xce",
    0xcf, "zCustom 0xcf",
    0,NULL
};

USER_STRINGID sOblShowAs[]=
{
    0, "(One frame)",
    1, "Multiple frames",
    2, "Grouped frames by 4",
    3, "Grouped frames by 2",
    4, "Defined only left/right",
    0, NULL
};
                
USER_STRINGID sOblActAs[]=
{
    0x0, "(None)",
    0, NULL
};


