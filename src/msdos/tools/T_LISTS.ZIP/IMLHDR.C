/*
	FICHIER: IMLHDR.C
	AUTEUR : FRANCOIS BLANCHETTE
	BUT    : GENERER DES .IML A PARTIR DE .OBL
*/

#include <user\friendly.h>
#include <stdlib.h>
char ver[]="IMLHDR V1.0 (12/28/95)";
struct ffblk ffblk;

typedef  struct
{
	char id[4];
	unsigned int nbfnt;
	unsigned int sizedefstats;
	unsigned int sizemap;
	unsigned int sizecomment;
	unsigned int nbobl;
}  IMLHEADER;

typedef struct
{
	char id[4];
	unsigned char masterkey;
	unsigned char objclass;
	unsigned char s1;
	unsigned char s2;
	unsigned char lenght;
	unsigned char height;
	unsigned char hasmap;
}  OBLHEADER;

typedef struct
{
	int ptrnext;
	char masterkey;
	char objclass;
	char s1;
	char s2;
	char lenght;
	char height;
	int ptrmap;
	//int fragments; //flexible structure
} IMLENTRY;


// GLOBAL VARIABLES
FILE *sfile;
FILE *tfile;
FILE *mfile;
FILE *oblfile;

int quiet =0;

// System related var
IMLHEADER 			imlheader;
IMLENTRY  			imlentry;
OBLHEADER 			oblheader;

//IMLENTRY  			*imlptr;
unsigned int        *imlptr;
unsigned int huge 	*fontptr;
unsigned char      	*mapptr;
unsigned char      	*comptr;
unsigned int huge  *fntptr;

unsigned int 		imlbase;
unsigned int 		combase;
unsigned int	    mapbase;

// A fnt from a .OBL
int aFNT[64/2];


void AfficherSyntaxe()
{
	puts("");
	puts(ver);
	puts("(C) 1995 FRANCOIS BLANCHETTE");
	puts("\nSyntaxe:");
	puts("  IMLHDR [/S] fichiers ...");
	puts("");
	puts("  /? /HELP /AIDE         Aide");
	puts("  /S                     Supprimer le (c) message\n");
	exit(3);
}

void stripof(char *chaine, char car)
{
	int cpt;
	for (cpt=0; cpt<strlen(chaine); cpt++)
	{
		if (*(chaine+cpt) == car)
			strcpy(chaine+cpt, chaine+cpt+1);
	}
}

char maj(char car)
{
	if ( (car>='a') && (car <='z') )
	   car = car -'a' + 'A';

	return(car);
}


int haswild(const char *NomIma)
{
	return(((strchr(NomIma, '*')) || (strchr(NomIma,'?'))));
}

int hasbackslash(const char *NomIma)
{	return(int)(strchr(NomIma,'\\'));
}

int lastofchar(const char *NomIma, char car)
{   const char *temp;
	int addon_;
	temp = NomIma;
	addon_ = strlen(NomIma);

	while (((*(temp+addon_) != car) &&
			(addon_)))
		addon_--;

	if (*(temp+addon_)!=car)
		return(-1);
	else
		return(addon_);
}

void error(const char *err__)
{
	puts(err__);
	exit(2);
}



int IsIn(const char *Limite, char car)
{
	//printf("%c%s%c", 34,Limite,34);
	for (;*Limite; Limite++)
		if (*Limite == car)
		{
		//	printf("*");
			return(1);
		}
	return(0);

}

void chgchar(char *chaine, char ocar, char ncar)
{
	for (;*chaine; chaine++)
	{	if ( (*chaine)==ocar)
			 (*chaine)=ncar;
	}
}


/*
  */


void describe(char *imlname)
{

	unsigned int temp;
	unsigned int x,y;
	unsigned imlbase;
	unsigned long pos;

	combase=0;
	sfile=fopen(imlname,"rb");
	if (sfile==NULL)
	{
		printf("WARNING: Unable to open %c%s%c.",34,imlname,34);
		return;

	}

	printf("\nIMLFILE : %s \n",imlname);
	fread(&imlheader, sizeof(IMLHEADER), 1, sfile);

	printf("\n ID                     :%4s\n", imlheader.id);
	printf(" Nombre de FNT          : 0x%x\n", imlheader.nbfnt);
	printf(" Taille des def. stats  : 0x%x\n", imlheader.sizedefstats);
	printf(" Taille des maps utili. : 0x%x\n", imlheader.sizemap);
	printf(" Taille des commentaires: 0x%x\n", imlheader.sizecomment);
	printf(" Nombre de .OBL inclus  : 0x%x\n", imlheader.nbobl);
	puts("");

	pos=ftell(sfile);
	fseek(sfile, imlheader.sizedefstats, 1);
	fseek(sfile, imlheader.sizemap,1);
	fseek(sfile, imlheader.nbfnt*64,1);
	fread(comptr, imlheader.sizecomment, 1, sfile);
	fseek(sfile, pos, 0);

	for (y=0; y!=imlheader.nbobl; y++)
	{
		fread(&imlentry, sizeof(imlentry),1, sfile);

		puts("");

		printf(" Entry #                : 0x%x\n", y);
		printf(" Description            : %s\n", comptr+combase);
		printf(" Ptr next def           : 0x%x\n", imlentry.ptrnext);
		printf(" MasterKey / Obj Class  : 0x%x 0x%x\n", imlentry.masterkey, imlentry.objclass);
		printf(" S1        / S2         : 0x%x 0x%x\n", imlentry.s1, imlentry.s2);
		printf(" lenght   / height      : 0x%x 0x%x\n", imlentry.lenght, imlentry.height);
		if (imlentry.ptrmap==-1)
			printf(" PtrMap                 : 0x%x [NoMap]\n", imlentry.ptrmap);
		else
			printf(" PtrMap                 : 0x%x \n", imlentry.ptrmap);


		combase = combase + 1 +strlen(comptr+combase);
		for (x=0; x!=(imlentry.lenght * imlentry.height);x++)
		{
			fread(&temp, 2,1,sfile);
		printf("                          0x%x \n", temp);

		}

		//fseek(sfile,imlentry.lenght * imlentry.height *2,1);
	}

	fclose(sfile);


}

void withfile(char *thefile)
{
	char static imlname[128];
	char *tempPtr;

	int lastslash= lastofchar(thefile, '\\');
	int lastdot;

	if (lastslash!=-1)
		tempPtr= tempPtr + lastslash;

	lastdot = lastofchar(tempPtr+ lastslash, '.');

	if (lastdot==-1)
	{	strcpy(imlname, thefile);
		strcat(imlname, ".IML");
	}
	else
		strcpy(imlname, thefile);

	//strcat(imlname, ".IML");
	describe(imlname);


}

void givehelp(int NbArgs, char *TabPtr[])
{
	char static temp[256];
	int cpt;
	for (cpt=1; cpt < NbArgs; cpt++)
	{
		*(TabPtr[cpt]+1)= maj(*(TabPtr[cpt]+1));
		strcpy(temp,TabPtr[cpt]);
		temp[2]=0;

		if (strcmp(temp, "/C") !=0)
			strupr(TabPtr[cpt]);
		if (strcmp(temp, "/S") ==0)
			quiet=1;
		if (strcmp(temp, "/Q") ==0)
			quiet=1;

		if (strcmp(TabPtr[cpt], "/?") ==NULL)
			AfficherSyntaxe();
		if (strcmp(TabPtr[cpt], "/HELP") ==NULL)
			AfficherSyntaxe();
		if (strcmp(TabPtr[cpt], "/AIDE") ==NULL)
			AfficherSyntaxe();

	}
}


char hex2dec(unsigned char hex)
{
	//printf("[%c]", hex);
	if (((hex >='0') && (hex<='9')) )
		return(hex-'0');
	if (((hex >='A') && (hex<='F')))
		return(hex-'A'+10);
	return(18);
}


void withcommand(char *command)
{
	switch(*(command+1))
	{
		case 'S':
		case 'Q':
			break;

		default:
			printf("Parametre %c%s%c invalide.\n", 34,command,34);
			break;
	}
}

void AllocMem()
{

	  comptr  = (unsigned char *) farmalloc(16384);
	  if (comptr==NULL) error("FATALE: Memoire insuffisante.");

}


void main(int NbArgs, char *TabPtr[])
{
	int cpt;
	// User want help ?
	givehelp(NbArgs, TabPtr);
	if (NbArgs <2)
		AfficherSyntaxe();

	if (!quiet)
	{
		puts("");
		puts(ver);
		puts("(C) 1995 FRANCOIS BLANCHETTE\n");
	}

	AllocMem();
	for (cpt=1; cpt < NbArgs; cpt++)
	{
		if (*(TabPtr[cpt])!='/')
			withfile(TabPtr[cpt]);
		else
			withcommand(TabPtr[cpt]);
	}

}