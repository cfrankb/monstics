//
// wasted.c
//

#include "include.h"
#include "struc.h"
#include "winEasy.h"

/*

BOOL APIENTRY Page1(
	HWND hDlg,
	UINT message,
	UINT wParam,
	LONG lParam)
{
	static PROPSHEETPAGE * ps;
	BOOL bErr;
	static UINT uMin, uMax, uMinSave, uMaxSave;

    static HWND hDC_CLASS;
    static HWND hDC_SHOWAS;
    static HWND hDC_ACTAS; 
    
    int cpt;
    bErr=0;

	switch (message)
	{
		case WM_INITDIALOG:	
			// Save the PROPSHEETPAGE information.
			ps = (PROPSHEETPAGE *)lParam;

              hDC_CLASS = GetHandle(hDlg, IDC_DC_CLASS);
              hDC_SHOWAS = GetHandle(hDlg, IDC_DC_SHOWAS);
              hDC_ACTAS = GetHandle(hDlg, IDC_DC_ACTAS);

              for (cpt=0; sOblClass[cpt].cHelpText; cpt++)
              {
                    ComboBox_AddString(hDC_CLASS,
                                sOblClass[cpt].cHelpText) ;
              }

              for (cpt=0; sOblShowAs[cpt].cHelpText; cpt++)
              {
                    ComboBox_AddString(hDC_SHOWAS,
                                sOblShowAs[cpt].cHelpText) ;
              }

              for (cpt=0; sOblActAs[cpt].cHelpText; cpt++)
              {
                    ComboBox_AddString(hDC_ACTAS,
                                sOblActAs[cpt].cHelpText) ;
              }

			return (TRUE);

		case WM_NOTIFY:
    		switch (((NMHDR FAR *) lParam)->code) 
    		{

				case PSN_SETACTIVE:
					// Initialize the controls.
				//	uMinSave = SendMessage( hWndSlider, TBM_GETRANGEMIN, 0L, 0L);
				//	uMaxSave = SendMessage( hWndSlider, TBM_GETRANGEMAX, 0L, 0L);
				//	SetDlgItemInt(hDlg, IDE_MIN, uMinSave, TRUE);
				//	SetDlgItemInt(hDlg, IDE_MAX, uMaxSave, TRUE);
					break;

				case PSN_APPLY:
				//	uMin = GetDlgItemInt(hDlg, IDE_MIN, &bErr, TRUE);
				//	uMax = GetDlgItemInt(hDlg, IDE_MAX, &bErr, TRUE);
				//	SendMessage( hWndSlider, TBM_SETRANGE, TRUE, 
				//		MAKELONG(uMin, uMax));
 	           	//	SetWindowLong(hDlg,	DWL_MSGRESULT, TRUE);
					break;

				case PSN_KILLACTIVE:
	           	//	SetWindowLong(hDlg,	DWL_MSGRESULT, FALSE);
					return 1;
					break;

				case PSN_RESET:
					// Reset to the original values.
				//	SendMessage( hWndSlider, TBM_SETRANGE, TRUE, 
				//		MAKELONG(uMinSave, uMaxSave));
	           	//	SetWindowLong(hDlg,	DWL_MSGRESULT, FALSE);
					break;
    	}
	}
	return (FALSE);   

}

*/



int CALLBACK PropSheetProc (HWND hwndDlg, 
                            UINT uMsg, 
                            LPARAM lParam)
     {

 
     switch (uMsg)
          {
          case PSCB_INITIALIZED :
                   // Process PSCB_INITIALIZED
               break ;

          case PSCB_PRECREATE :
               // Process PSCB_PRECREATE
               break ;

          default :
               // Unknown message
               break ;
          }

     return 0 ;
     }

UINT CALLBACK 
StylePage1Proc (HWND  hwnd, UINT uMsg, LPPROPSHEETPAGE ppsp)
     {


     switch (uMsg)
          {
          case PSPCB_CREATE :
               // Store pointer to style data
               //pTheStyles = (LPDWORD) ppsp->lParam ;
               return TRUE ;

          case PSPCB_RELEASE :
               return 0;
          }
     return 0 ;
     }

UINT CALLBACK 
StylePage2Proc (HWND  hwnd, UINT uMsg, LPPROPSHEETPAGE ppsp)
     {
     switch (uMsg)
          {
          case PSPCB_CREATE :
               // Store pointer to style data
               //pTheStyles = (LPDWORD) ppsp->lParam ;
               return TRUE ;

          case PSPCB_RELEASE :
               return 0;
          }

     return 0 ;
     }

UINT CALLBACK 
StylePage3Proc (HWND  hwnd, UINT uMsg, LPPROPSHEETPAGE ppsp)
     {
     switch (uMsg)
          {
          case PSPCB_CREATE :
               // Store pointer to style data
               //pTheStyles = (LPDWORD) ppsp->lParam ;
               return TRUE ;

          case PSPCB_RELEASE :
               return 0;
          }

     return 0 ;
     }


/****************************************************************************
*
*    FUNCTION: Spin(HWND, UINT, UINT, LONG)
*
*    PURPOSE:  Processes messages for "Spin" dialog box
*
****************************************************************************/

BOOL APIENTRY Spin(
	HWND hDlg,
	UINT message,
	UINT wParam,
	LONG lParam)
{
	static HWND hWndUpDown;
	//BOOL bErr;

    USER_UPDOWNCTRL sUpDown;

	switch (message)
	{
		case WM_INITDIALOG:
            sUpDown.hWndParent = hDlg;
            sUpDown.hWndBuddy = GetHandle(hDlg, 401);
            sUpDown.iIdBuddy = 401;
            sUpDown.iId= 1000;
            sUpDown.iMin = 1;
            sUpDown.iMax = 25;
            sUpDown.iDefVal =1;            
          //  hWndUpDown=  CreateUpDown(sUpDown);
			return TRUE;

		case WM_COMMAND:              
			switch (LOWORD(wParam))
			{
				case IDOK:
			//		iNumLines = (int)GetDlgItemInt(hDlg, IDE_BUDDY, 
			//			&bErr, FALSE );
			//		InvalidateRect(hWndMain, NULL, TRUE); 

				case IDCANCEL:
					EndDialog(hDlg, TRUE);
					break;
				
			}
			break;
	
	}
	return (FALSE);   

}

