
//
// Import.c
//

#include "import.h"


int Import_IMA2OBL (char *szFilename,
                    USER_OBL3HEADER *psHeader)
{

    USER_OBL3HEADER lsHeader;
    USER_OBL3     * pPrevObl = NULL;
    USER_OBL3     * pObl;

    USER_STDIMA  sStdIma;
    USER_STDIMA  sStdImaD;
    char *pImaData;
    char *pBits;
    char *pNew;
    int iStatus;
    BOOL bResize = FALSE;

    static int cpt;

    iStatus = LoadIma(szFilename, 
                      &sStdIma,
                      &pImaData);

    if (iStatus!=TRUE) return iStatus;

    memcpy(&sStdImaD, &sStdIma, sizeof(USER_STDIMA));
    
    if (sStdIma.len & 1) 
    {
        sStdImaD.len++;
    }
    if (sStdIma.hei & 1) 
    {
        sStdImaD.hei++;
    }

    pBits = Ima2Bitmap(sStdIma, pImaData);
    if (pBits==NULL) return err_memory;


    pNew =  ResizeImage(pBits,
                    sStdIma.len *8, sStdIma.hei*8,
                    sStdImaD.len *8, sStdImaD.hei*8);

    fillmem((void*)&lsHeader, 0, sizeof(USER_OBL3HEADER));

    memcpy(lsHeader.Id, "OBL3", 4);
    lsHeader.iNbrImages = 1;
    lsHeader.iLen = sStdImaD.len/2;
    lsHeader.iHei = sStdImaD.hei/2;

    pObl = MakeOBL3(sStdImaD.len/2,
                    sStdImaD.hei/2, NULL, NULL);

    lsHeader.PtrFirst = pObl;

    pObl->PtrBits = pNew;

    // Added transparency to old .IMA
    for (cpt=0; (unsigned) cpt< (sStdImaD.len *8 * sStdImaD.hei*8);
         cpt++)
    {
            if (*(pNew+cpt)==16)
                *(pNew+cpt)=0;
    }

    memcpy(psHeader, &lsHeader, sizeof(USER_OBL3HEADER));
    free(pBits);
    free(pImaData);

    return TRUE;
}




int Import_MCX2OBL (char *szFilename, 
                       USER_OBL3HEADER *psHeader)
{

    USER_OBL3HEADER lsHeader;
    USER_MCXHEADER  sMcxHeader;
    USER_MCX      * pMcx;

    USER_OBL3     * pPrevObl = NULL;
    USER_OBL3     * pObl;
   
    char szSig[]  = "xxxx";

    FILE *sfile;

    sfile = fopen(szFilename, "rb");
    if (sfile==NULL) return err_fileopen;
    
    fread(&sMcxHeader, sizeof(USER_MCXHEADER), 1, sfile);
    memcpy(szSig, sMcxHeader.Id, 4);
    if (strcmp(szSig, "GE96")!=0)
    {
        fclose(sfile);
        return err_format;
    }
    
    pMcx = malloc(sizeof(USER_MCX));    
    fread(pMcx, sizeof(USER_MCX),1 ,sfile);
    
    fillmem((void*)&lsHeader, 0, sizeof(USER_OBL3HEADER));

    memcpy(lsHeader.Id, "OBL3", 4);
    lsHeader.iNbrImages = sMcxHeader.NbrImages;
    lsHeader.iLen = 2;
    lsHeader.iHei = 2;

    for (;sMcxHeader.NbrImages;sMcxHeader.NbrImages--)
    {
        // MakeOBL3 takes 16x16 FNT as args
        pObl = MakeOBL3(32/OBL3FNT,32/OBL3FNT, pPrevObl, NULL);
        ddmemcpy((void *)pObl->PtrBits, (void*)pMcx->ImageData, 32*32);

        if (pPrevObl==NULL)
        {
            lsHeader.PtrFirst = pObl;
        }
        else
        {
            pPrevObl->PtrNext = pObl;
        }

        pPrevObl = pObl;
        fread(pMcx, sizeof(USER_MCX),1 ,sfile);

    }

    memcpy(psHeader, &lsHeader, sizeof(USER_OBL3HEADER));
    free(pMcx);
    fclose(sfile);

    return TRUE;

}

int Import_GetFileInfo(USER_OBL3HEADER *pHeader, 
            char *szFilename)
{
    char *pDot;
    FILE *tfile;

    USER_OBL3HEADER lsOblHead;
    USER_MCXHEADER lsMcxHead;
    USER_IMC1HEADER lsIMC1Head;
    USER_IMAHEADER lsIMAHead;
    char Idxxxx[] = "xxxx";
    int iPos;
    int iSize;

    pDot = LastOf(szFilename, '.');

    if ((pDot) == NULL) 
        return err_filename;

     // Deal with an OBL.....................................
     if (_stricmp(pDot, ".obl")==0)
     {

        tfile = fopen(szFilename, "rb");
        if (tfile==NULL) return err_fileopen;
        fread(&lsOblHead, sizeof(USER_OBL3HEADER), 1, tfile);

        memcpy(Idxxxx, lsOblHead.Id, 4);
        if (strcmp(Idxxxx, "OBL3")==0)
        {
            memcpy(pHeader, &lsOblHead, sizeof(USER_OBL3HEADER));
            fclose (tfile);
            return TRUE;
        }
        else
        {
            fclose (tfile);
            return err_format;
        }


     }

     // Deal with an MCX........................................
     if (_stricmp(pDot, ".mcx")==0)
     {

        tfile = fopen(szFilename, "rb");
        if (tfile==NULL) return err_fileopen;
        fread(&lsMcxHead, sizeof(USER_MCXHEADER), 1, tfile);

        memcpy(Idxxxx, lsMcxHead.Id, 4);
        if (strcmp(Idxxxx, "GE96")==0)
        {
            pHeader->iLen = 2;
            pHeader->iHei = 2;
            pHeader->iNbrImages  = lsMcxHead.NbrImages;
            memcpy(pHeader->Id, "OBL3",4);
            fclose (tfile);
            return TRUE;
        }
        else
        {
            fclose (tfile);
            return err_format;
        }


     }

     // Deal with an IMA........................................
     if (_stricmp(pDot, ".ima")==0)
     {
        tfile = fopen(szFilename, "rb");
        if (tfile==NULL) return err_fileopen;
        fread(&lsIMC1Head, sizeof(USER_IMC1HEADER), 1, tfile);

        memcpy(Idxxxx, lsIMC1Head.Id, 4);
        // Is it an IMC1?
        if (strcmp(Idxxxx, "IMC1")==0)
        {
            pHeader->iLen = lsIMC1Head.len;
            pHeader->iHei = lsIMC1Head.hei;
            memcpy(pHeader->Id, "OBL3",4);

            if ((pHeader->iLen) & 1) (pHeader->iLen)++;
            if ((pHeader->iHei) & 1) (pHeader->iHei)++;
            pHeader->iNbrImages  = 1;
            fclose (tfile);
            return TRUE;
        }
        else
        {
            // Ima?? 
            memcpy(&lsIMAHead, &lsIMC1Head,2);
            fseek(tfile, 0, SEEK_END);
            iPos = ftell(tfile);
            iSize =  lsIMAHead.len * lsIMAHead.hei * 64 +2;

            if (iSize !=iPos)
            {
                fclose(tfile);
                return err_format;
            }

            pHeader->iLen = lsIMAHead.len;
            pHeader->iHei = lsIMAHead.hei;
            memcpy(pHeader->Id, "OBL3",4);

            if ((pHeader->iLen) & 1) (pHeader->iLen)++;
            if ((pHeader->iHei) & 1) (pHeader->iHei)++;
            pHeader->iNbrImages  = 1;
            pHeader->iLen =pHeader->iLen /2;
            pHeader->iHei =pHeader->iHei /2;
            fclose (tfile);
            return TRUE;
        }


 
     }

    return err_filename;
}


int Import_ANY2OBL(USER_OBL3HEADER *pHeader, 
            char *szFilename)
{
    char *pDot;

     pDot = LastOf(szFilename, '.');


     if ((pDot) == NULL) 
        return err_filename;

     
     if (_stricmp(pDot, ".obl")==0)
     {
         return LoadOBL3(pHeader, szFilename);
     }


     if (_stricmp(pDot, ".mcx")==0)
     {
       return Import_MCX2OBL 
              (szFilename, 
               pHeader); 
     }


     if (_stricmp(pDot, ".ima")==0)
     {
       return Import_IMA2OBL (
                    szFilename,
                    pHeader);
     }

    return err_filename;
}

