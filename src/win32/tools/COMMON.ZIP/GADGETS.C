
//
// Gadgets.c
// 

//
// Code from PropSheet.c
//

#include "gadgets.h"

extern HINSTANCE hAppInstance  ;
extern HPALETTE hpal;
void AppActivate(HPALETTE);

// *************************************************************************
//
// int CreatePropertySheet(HWND hwndOwner)
//
// *************************************************************************

int CreatePropertySheet(HWND hwndOwner, 
                        USER_PROPWIN psp_data[], 
                        const char *PropTitle)
{
    static PROPSHEETPAGE psp[20];
    PROPSHEETHEADER psh;
    int NbPages;

    int x;

    for (x=0; (psp_data[x].PropSheet); x++)
    {
        psp[x].dwSize = sizeof(PROPSHEETPAGE);
        psp[x].dwFlags = PSP_USETITLE ;
        psp[x].hInstance = hAppInstance;
        psp[x].pszTemplate = psp_data[x].PropSheet; 
        psp[x].pszIcon = NULL;
        psp[x].pfnDlgProc = psp_data[x].DlgProc;
        psp[x].pszTitle = psp_data[x].Title;
        psp[x].lParam = 0;
        psp[x].pfnCallback = 0;

    }
   
    NbPages = x;
    psh.dwSize = sizeof(PROPSHEETHEADER);
    psh.dwFlags = PSH_PROPSHEETPAGE ;
    psh.hwndParent = hwndOwner;
    psh.hInstance = hAppInstance;
    psh.pszIcon = NULL;
    psh.pszCaption = (LPSTR) PropTitle;
    psh.nPages = NbPages       ;
    psh.ppsp = (LPCPROPSHEETPAGE) &psp;
    psh.pfnCallback = 0 ;

    return (PropertySheet(&psh));
}



// 
// This code was stat_bar.c
//

HWND CreateStatusBar(HWND hwnd, USER_STATBAR sStatbar[])
{


        int cpt;
        int *iWidths;        
        int NbParts ;

        HWND hWndStatus;

            hWndStatus = CreateWindowEx ( 
            0L,                             // extended style
            STATUSCLASSNAME,                // create status bar
            "",                             // window title
            WS_CHILD | WS_BORDER |
            WS_VISIBLE | SBS_SIZEGRIP,      // window styles
            0, 0, 0, 0,                     // x, y, width, height
            hwnd,                           // parent window
            (HMENU)ID_STATUSBAR,            // ID
            hAppInstance,                   // instance
            NULL);                          // window data

         if (hWndStatus == NULL)
         {   MessageBox (NULL, "Status Bar not created!", NULL, MB_OK );
             return NULL;
         }

         for (cpt=0; sStatbar[cpt].iStyle ||
                     sStatbar[cpt].cText; cpt++);

         iWidths = (int *)malloc(4 * cpt);

         NbParts = cpt;

         for (cpt=0; cpt<NbParts; cpt++)
            *(iWidths+cpt) = sStatbar[cpt].iSize;

         // Break the status bar into four parts.
         // (or in as many parts as you want).
         SendMessage (hWndStatus, SB_SETPARTS, NbParts, 
                      (LPARAM)iWidths);

         for (cpt=0; sStatbar[cpt].iStyle ||
                     sStatbar[cpt].cText; cpt++)
         {
            SendMessage (hWndStatus, 
                         SB_SETTEXT, 
                         sStatbar[cpt].iStyle | cpt,
                         (LPARAM)sStatbar[cpt].cText);                     
         }                  
           
         return hWndStatus;
      
}




    
// ************************************************************
// ************************************************************
//
//              New gadgets below this point.
//
// ************************************************************
// ************************************************************

//
// HWND CreateUpDown(USER_UPDOWNCTRL sUpDown);
//

HWND CreateUpDown(USER_UPDOWNCTRL sUpDown)
{
        HWND hWndUpDown;

    // Create up-down control.
		hWndUpDown = CreateWindowEx( 
			0L,
			UPDOWN_CLASS,
			"",
			WS_CHILD | WS_BORDER | WS_VISIBLE | 
                UDS_WRAP | UDS_ARROWKEYS |
			    UDS_ALIGNRIGHT | UDS_SETBUDDYINT,
			0, 0, 8, 8,
			sUpDown.hWndParent,
			(HMENU)sUpDown.iId,
			hAppInstance,
			NULL );

		// Set the buddy window.
		SendMessage( hWndUpDown, UDM_SETBUDDY, 
                     (LONG)sUpDown.hWndBuddy, 0L );

		// Set the range.
		SendMessage( hWndUpDown, UDM_SETRANGE, 0L, 
            MAKELONG (sUpDown.iMax, sUpDown.iMin));

		// Set the default value in the edit control.
		SetDlgItemInt( sUpDown.hWndParent, sUpDown.iIdBuddy, 
                             sUpDown.iDefVal,FALSE);

        return hWndUpDown;

}

//
//
//

void ResizeResident(int iMLen,
                    int iMHei,
                    HWND hWndToolbar,
                    HWND hWndStatusBar,
                    HWND hListView

                    )
{

    
    static RECT RectToolbar;
    static RECT RectStatusbar;
    static RECT RectNULL;

    static int iLW_Len;
    static int iLW_Hei;
    static int iLW_X;
    static int iLW_Y;

    if (hWndToolbar!=0)
    {
        if (GetWindowRect(hWndToolbar, &RectToolbar)==FALSE)
            memcpy(&RectToolbar, &RectNULL, sizeof(RECT));
    }
    else
    {
        memcpy(&RectToolbar, &RectNULL, sizeof(RECT));
    }

          
    if (hWndStatusBar!=0)   
    {
        if (GetWindowRect(hWndStatusBar, &RectStatusbar)==FALSE)
        memcpy(&RectStatusbar, &RectNULL, sizeof(RECT));
    }
    else
    {
        memcpy(&RectStatusbar, &RectNULL, sizeof(RECT));
    }



    iLW_Y = RectToolbar.bottom - RectToolbar.top;
    iLW_X = 0;
    iLW_Len = iMLen;
    iLW_Hei = iMHei
              - (iLW_Y )
              - (RectStatusbar.bottom- RectStatusbar.top);
   
     MoveWindow(hListView,
                iLW_X,       // x
                iLW_Y,       // y
                iLW_Len,     // len
                iLW_Hei,     // hei
                TRUE);         // Redraw

     UpdateWindow(hListView)  ;

}

//
//
//

int AppMenuHelp(WPARAM wParam, 
                 LPARAM lParam, 
                 USER_MENUHELP sMenuHelp[],
                 HWND hStatusbar)
{

    uint uItem;
    uint fuFlags;
    HMENU hmenu;

    BOOL bFound;
    int cpt;
    
    uItem = (UINT) LOWORD(wParam);    
    fuFlags = (UINT) HIWORD(wParam);    
    hmenu = (HMENU) lParam;

    // User closed menu (yes sir!)
    if ((fuFlags == 0xffff) || (hmenu ==NULL))    
    {
         SendMessage (hStatusbar, SB_SETTEXT, 0, 
                      (LPARAM)(LPSTR)"Ready.");
        return FALSE;
    }

    if (uItem == 0) return FALSE;

    bFound =FALSE;
    for (cpt=0; sMenuHelp[cpt].iItemId; cpt++)
    {
        if ((UINT)sMenuHelp[cpt].iItemId ==uItem)
        {   
            bFound = TRUE;
            break;
        }

    }

    if (bFound)  
    {

         SendMessage (hStatusbar, SB_SETTEXT, 0, 
                      (LPARAM)(LPSTR)sMenuHelp[cpt].cHelpText);
    }
    else
    {

         SendMessage (hStatusbar, SB_SETTEXT, 0, 
                      (LPARAM)(LPSTR)" ");
    }
        
    return TRUE;
}


//
//
//
HWND CreateListBox(int iId, 
                   HWND hMainWnd, 
                   int x,
                   int y,
                   int len, 
                   int hei)
{
    HWND hListBox;
    hListBox = CreateWindow ("ListBox",
                        NULL,
                        WS_CHILD | WS_VSCROLL | LBS_NOINTEGRALHEIGHT
                        | LBS_SORT | WS_VISIBLE,
                        x,
                        y,
                        len,
                        hei,
                        hMainWnd,
                        (HMENU)iId,
                        hAppInstance,
                        NULL);

    return hListBox;
}

// CreateEdit (int, HWND, const char *)
// ==================================================
// iId                      Id notification
// hParent                  Handle to parent window
// szClass:                 "EDIT" or "RICHEDIT"            
// 

HWND CreateEdit(int iId, HWND hParent, const char *szClass)
{
    
    HWND static hWndRichEdit;
     // Create the rich edit control.            
     hWndRichEdit = CreateWindowEx(
                  WS_EX_CLIENTEDGE,    // make rich edit control appear "sunken"
                  szClass,             // class name of rich edit control
                  "",                  // text of rich edit control
                  WS_CHILD | WS_VISIBLE |
                  ES_MULTILINE | ES_SAVESEL |
                    WS_HSCROLL | WS_VSCROLL,    
                                       // window style
                  0, 0,                // initially create 0 size,
                  0, 0,                // main window's WM_SIZE handler will resize
                  hParent,             // use main parent
                  (HMENU)iId,          // ID 
                  hAppInstance,        // this app instance owns this window
                  NULL  );
     
     return hWndRichEdit;
}

//
// HIMAGELIST CreateImageList(LPTSTR [], int, int, int);
//

HIMAGELIST CreateImageList(LPTSTR iIconsId[], 
                           int iLen, 
                           int iHei,
                           int iType)
{

    static HICON hIcon;
    static HBITMAP hBitmap;

    HIMAGELIST hImageList;
    int iNbImages;
    int cpt;

    for (cpt=0; iIconsId[cpt]; cpt++);
    iNbImages = cpt;

	hImageList = ImageList_Create(iLen, 
                                  iHei, 
                                  ILC_COLORDDB, 
                                  iNbImages, 
                                  0);
        
        
 	// Load the icons and add them to the image lists.
	for (cpt=0; cpt<iNbImages ; cpt++)
	{
        if (iType==TYPE_ICON)
        {
		    hIcon = LoadIcon (hAppInstance, iIconsId[cpt]);
            if (ImageList_AddIcon(hImageList, hIcon) ==-1)
                return NULL;

        }
        else
        {
            hBitmap = LoadBitmap (hAppInstance, iIconsId[cpt]);
            if (ImageList_AddIcon(hImageList, hBitmap) ==-1)
                return NULL;
        }

	}


	if (ImageList_GetImageCount(hImageList) < iNbImages)
		return FALSE;

    return hImageList;

}



//
//  HWND CreateListView(HWND, LPTSTR[], LPTSTR[], int);
//

HWND CreateListView(HWND hWndParent, 
                    LPTSTR sSmImageList[],
                    LPTSTR sLgImageList[],
                    LPTSTR cColumnHeader[],
                    int iListViewId,
                    int iType)
{

   	RECT rcl;           		// rectangle for setting size of window
	HWND hWndList;      		// handle to list view window
        
    HIMAGELIST hSmImageList,    // images lists
               hLgImageList;

	LV_COLUMN lvC;				// list view column structure
	static char szText[1024];   // place to store some text

    int cpt, index;
    int iNbCol;

	// Get the size and position of the parent window.
    GetClientRect(hWndParent, &rcl);

	// Create the list view window that starts out in details view
    // and supports label editing.
	hWndList = CreateWindowEx( 0L,
		WC_LISTVIEW,                // list view class
		"",                         // no default text
		WS_VISIBLE | WS_CHILD | WS_BORDER | LVS_REPORT |
		     WS_EX_CLIENTEDGE | LVS_AUTOARRANGE 
             | LVS_SHOWSELALWAYS,	// styles
		0, 0,
		rcl.right - rcl.left, rcl.bottom - rcl.top,
		hWndParent,
		(HMENU) iListViewId,
		hAppInstance,
		NULL );

	if (hWndList == NULL )
		return NULL;


    hSmImageList = CreateImageList(sSmImageList, 
                           16, 
                           16,
                           iType);

    hLgImageList = CreateImageList(sLgImageList, 
                           32, 
                           32,
                           iType);
    
	ListView_SetImageList(hWndList, 
                          hSmImageList, 
                          LVSIL_SMALL);

    ListView_SetImageList(hWndList, 
                          hLgImageList, 
                          LVSIL_NORMAL);


	// Now initialize the columns you will need.
	// Initialize the LV_COLUMN structure.
	// The mask specifies that the fmt, width, pszText, and subitem members 
	// of the structure are valid,
	lvC.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	lvC.fmt = LVCFMT_LEFT;  // left-align column
	lvC.cx = 75;            // width of column in pixels
	lvC.pszText = szText;

    for (cpt=0; strlen(cColumnHeader[cpt]); cpt++);
    iNbCol = cpt;

	// Add the columns.
	for (index = 0; index < iNbCol; index++)
	{
		lvC.iSubItem = index;
        strcpy(szText,cColumnHeader[index]);
    //	LoadString( hInst, 
    //				IDS_ADDRESS + index,
    //				szText,
    //				sizeof(szText));
		if (ListView_InsertColumn(hWndList, index, &lvC) == -1)
			return NULL;
	}

    return hWndList;
}


//
// HWND CreateButton(HWND hMother, USER_BUTTON sUserButton);
//

HWND CreateButton(HWND hMother, USER_BUTTON sUserButton)
{

    HWND hButton ;
    hButton = CreateWindow ("button", 
                               sUserButton.lpszText,
                               WS_CHILD | WS_VISIBLE | 
                                   sUserButton.iStyle,
                               sUserButton.x, 
                               sUserButton.y,
                               sUserButton.iLen, 
                               sUserButton.iHei,
                               hMother, 
                               (HMENU) sUserButton.iId,
                              hAppInstance, NULL) ;

    if (sUserButton.hImage)
    {
        switch(sUserButton.iStyle & (BS_ICON | BS_BITMAP))
        {
        case BS_ICON:
            Button_SetImageIcon(hButton, sUserButton.hImage);
            break;
        case BS_BITMAP:
            Button_SetImageBitmap(hButton, sUserButton.hImage);
            break;

        }
    }
    
    return hButton;

}

//
// int AddTooltip (HWND hToolOwner,  HWND hTooltip, 
//                 RECT sRect,  char *cToolText, HWND hTool )
//

int AddTooltip (HWND hToolOwner,
                 HWND hTooltip, 
                 RECT sRect,
                 char *cToolText,
                 HWND hTool
                 )

{

    TOOLINFO ti;
    ti.cbSize     = sizeof(TOOLINFO); 
    ti.uFlags     = TTF_IDISHWND | //TTF_CENTERTIP |
                    TTF_SUBCLASS; 
    ti.hwnd       = hToolOwner;     
    ti.hinst      = hAppInstance; 
    ti.uId        = (UINT) hTool; 
    ti.lpszText   = cToolText; 
    ti.rect.left  = sRect.left; 
    ti.rect.top   = sRect.top; 
    ti.rect.right = sRect.right; 
    ti.rect.bottom= sRect.bottom; 
 
    if (!SendMessage(hTooltip, TTM_ADDTOOL, 0, 
                    (LPARAM) (LPTOOLINFO) &ti)) 
        return FALSE; 
    else
        return TRUE;
}



//
//
//
LPTSTR GetString(USER_MENUHELP sTable[], int iIndex)
{               
    int cpt;
    for (cpt=0; sTable[cpt].cHelpText; cpt++)
    {
            if (sTable[cpt].iItemId==iIndex)
                return sTable[cpt].cHelpText;           
    }
    return NULL;
}

//
//
//
int GetId(USER_MENUHELP sTable[], char *szChaine)
{
    int cpt;
    for (cpt=0; sTable[cpt].cHelpText; cpt++) 
    {
        if (strcmp(sTable[cpt].cHelpText, szChaine)== 0)
            return sTable[cpt].iItemId;

    }
    
    return -1;
}





//
//
//
HWND CreateTooltip(HWND hParent)
{
     HWND hwndTT;
     hwndTT =   CreateWindow(
                   TOOLTIPS_CLASS, 
                   (LPSTR) NULL, TTS_ALWAYSTIP, 
                   CW_USEDEFAULT, CW_USEDEFAULT, 
                   CW_USEDEFAULT, CW_USEDEFAULT, 
                   hParent, (HMENU) NULL, hAppInstance, 
                   NULL); 
     return hwndTT;
}



int ListView_AddItem (HWND hWndList,
                      USER_LVITEM sLVItem[])
{

    LV_ITEM lvI;				// list view item structure
    int index;
    int iCurrent;
    int iSubItem;
    
	// Finally, add the actual items to the control.
	// Fill out the LV_ITEM structure for each of the items to add to the list.
	// The mask specifies the the pszText, iImage, lParam and state
	// members of the LV_ITEM structure are valid.
	lvI.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM | LVIF_STATE;
	lvI.state = 0;      
	lvI.stateMask = 0;  

	for (index = 0; 
         sLVItem[index].cText!=NULL; 
         index++)
	{
		lvI.iItem = sLVItem[index].iIndex;
        iCurrent = sLVItem[index].iIndex;
		
        lvI.iSubItem = 0;
		// The parent window is responsible for storing the text. 
		// The list view control will send an LVN_GETDISPINFO 
		// when it needs the text to display.
		lvI.pszText = sLVItem[index].cText; 
                     //LPSTR_TEXTCALLBACK; 
		lvI.cchTextMax = MAX_ITEMLEN;
		lvI.iImage = sLVItem[index].iImage;
		lvI.lParam = sLVItem[index].iId;//
                     //NULL; //(LPARAM)&rgHouseInfo[index];

        if (ListView_InsertItem(hWndList, &lvI) == -1)
			return FALSE;
	    index ++;

		for (iSubItem = 1; 
             (sLVItem[index].iIndex==iCurrent)
              && (sLVItem[index].cText!=NULL); 
             iSubItem++, index++)
		{
			ListView_SetItemText( hWndList,
				iCurrent,
				iSubItem,
                sLVItem[index].cText);
		}
             index--;
	}
	return (TRUE);

}




//
//
//
int ListView_AddItemEx 
                      (HWND hWndList,
                      int iIndex,
                      int iId,
                      int iImage,
                      char *szLVItem[])
{

    LV_ITEM lvI;				// list view item structure
    int iSubItem;
    
	// Finally, add the actual items to the control.
	// Fill out the LV_ITEM structure for each of the items to add to the list.
	// The mask specifies the the pszText, iImage, lParam and state
	// members of the LV_ITEM structure are valid.
	lvI.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM | LVIF_STATE;
	lvI.state = 0;      
	lvI.stateMask = 0;  

		lvI.iItem = iIndex;
		
        lvI.iSubItem = 0;
		// The parent window is responsible for storing the text. 
		// The list view control will send an LVN_GETDISPINFO 
		// when it needs the text to display.
		lvI.pszText = szLVItem[0]; 
		lvI.cchTextMax = MAX_ITEMLEN;
		lvI.iImage = iImage;
		lvI.lParam = iId;//

        if (ListView_InsertItem(hWndList, &lvI) == -1)
			return FALSE;

		for (iSubItem = 1; (szLVItem[iSubItem]!=NULL); 
             iSubItem++)
		{
			ListView_SetItemText( hWndList,
				iIndex,
				iSubItem,
                szLVItem[iSubItem]);
		}
	
	return (TRUE);

}

int ListView_SetItemEx 
                      (HWND hWndList,
                      int iIndex,
                      int iId,
                      int iImage,
                      char *szLVItem[])
{

    LV_ITEM lvI;				// list view item structure
    int iSubItem;
    
	// Finally, add the actual items to the control.
	// Fill out the LV_ITEM structure for each of the items to add to the list.
	// The mask specifies the the pszText, iImage, lParam and state
	// members of the LV_ITEM structure are valid.
	lvI.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM | LVIF_STATE;
	lvI.state = 0;      
	lvI.stateMask = 0;  

		lvI.iItem = iIndex;
		
        lvI.iSubItem = 0;
		// The parent window is responsible for storing the text. 
		// The list view control will send an LVN_GETDISPINFO 
		// when it needs the text to display.
		lvI.pszText = szLVItem[0]; 
		lvI.cchTextMax = MAX_ITEMLEN;
		lvI.iImage = iImage;
		lvI.lParam = iId;//

        if (ListView_SetItem(hWndList, &lvI) == -1)
			return FALSE;

		for (iSubItem = 1; (szLVItem[iSubItem]!=NULL); 
             iSubItem++)
		{
			ListView_SetItemText( hWndList,
				iIndex,
				iSubItem,
                szLVItem[iSubItem]);
		}
	
	return (TRUE);

}



