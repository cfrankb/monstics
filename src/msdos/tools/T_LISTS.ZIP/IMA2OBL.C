/*
	FICHIER: IMA2OBL.C
	AUTEUR : FRANCOIS BLANCHETTE
	BUT    : GENERER DES .OBL A PARTIR DE .IMA
*/

#include <user\friendly.h>
#include <stdlib.h>
char ver[]="IMA2OBL V1.0 (12/27/95)";
struct ffblk ffblk;

FILE *sfile;
FILE *tfile;

	//OblHeader
	char header[4]="OBL\0";
	char MasterKey=0;
	char ObjClass=0;
	char S1=0;
	char S2=0;
	char len=0;
	char hei=0;
	char MapUsed=0;

	// courant
	static char curpath[128];
	int curdrive =0;

	// source / destination
	static char path[128];
	int drive=0;

	// Commentaires
	int name2comment =1;
	char comment[256];

	int quiet =0;
	int ficOui=0;

void AfficherSyntaxe()
{
	puts("");
	puts(ver);
	puts("(C) 1995 FRANCOIS BLANCHETTE");
	puts("\nSyntaxe:");
	puts("  IMA2OBL [/Xww[xxyyzz]] [/Cxxxx] fichiers ...");
	puts("");
	puts("  /? /HELP /AIDE         Aide\n");
	puts("  /Xww[xxyyzz]           Fixe les valeurs");
	puts("                         ww = clef maitre");
	puts("                         xx = obj class  ");
	puts("                         yy = special1   ");
	puts("                         zz = special2   \n");
	puts("  /Cxxxx                 Commentaire personnalise\n");
	exit(3);
}

char maj(char car)
{
	if ( (car>='a') && (car <='z') )
	   car = car -'a' + 'A';

	return(car);
}


int haswild(const char *NomIma)
{
	return(((strchr(NomIma, '*')) || (strchr(NomIma,'?'))));
}

int hasbackslash(const char *NomIma)
{	return(int)(strchr(NomIma,'\\'));
}

int lastofchar(const char *NomIma, char car)
{   const char *temp;
	int addon_;
	temp = NomIma;
	addon_ = strlen(NomIma);

	while (((*(temp+addon_) != car) &&
			(addon_)))
		addon_--;

	if (*(temp+addon_)!=car)
		return(-1);
	else
		return(addon_);
}

void error(const char *err__)
{
	puts(err__);
	exit(2);
}

void lookat(char NomIma[], const char *Ext, char *path )
{
	int lastbck; int lastdot;
	lastbck = lastofchar(NomIma, '\\');
	if (lastbck==-1)
	{
		lastdot = lastofchar(NomIma, '.');
		if (lastdot!=-1)
		{
			strcpy(  (NomIma+lastdot), Ext);
			//printf("NomIma : %s\n", NomIma);
		}
		else
		{
			strcpy(NomIma+strlen(NomIma), Ext);
			//printf("NomIma : %s\n", NomIma);

		}
	}

// Has some path
	else
	{
			strcpy(path, NomIma);
			*(path+lastbck+1) =0;
			strcpy(NomIma, NomIma+ lastbck+1);

		lastdot = lastofchar(NomIma, '.');
		if (lastdot==-1)
		{
			strcpy(NomIma+strlen(NomIma), Ext);
			//printf("NomIma : %s\n", NomIma);

		}

		else
		{
				//printf("NomImaA : %s\n", NomIma);
				strcpy(  (NomIma+lastdot), Ext);
				//printf("NomIma : %s\n", NomIma);
		}
	}
}


void makeobl(char *sname)
{
	char tname[128];
	unsigned char mem[64];
	unsigned blocks;
	char nom[128];

	strcpy(tname, sname);
	strcpy(&tname[lastofchar(tname, '.')], ".OBL");
	sfile = fopen(sname, "rb");
	if (sfile==NULL)
	{
		printf("[error--IMA]");
		return;
	}

	fread(&len, 2,1, sfile);
	blocks = hei*len;

	tfile = fopen(tname, "wb");
	if (tfile==NULL)
	{
		fclose(sfile);
		printf("[error--OBL]");
		return;
	}

	fprintf(tfile,"OBL%c",0);
	fwrite(&MasterKey, 7,1,tfile);
	for (;blocks!=0; blocks--)
	{
		fread(mem, 64,1,sfile);
		fwrite(mem, 64,1,tfile);
	}

	strcpy(nom, tname);
	*(tname+lastofchar(tname, '.')) =0;
	if (name2comment)
		fprintf(tfile, "%s%c", nom,0);
	else
		fprintf(tfile, "%s%c", comment,0);

	fclose(sfile);
	fclose(tfile);
	printf("[ok]");

}


void withfile(char *thefile)
{
	// Nom Global
	static char NomIma[128];
	static char NomObl[128];
	static char NomSource[128];
	int done;

	// Init global variables
	path[0]=0;
	drive=0;


	printf("Converting... [%s]\n",thefile);

	//strcpy(NomIma, TabPtr[1]);
	strcpy(NomIma, thefile);
	lookat(NomIma, ".IMA", path);

	if (path[1]==':')
	{
		drive=maj(path[0]) - 'A' +1;
		strcpy(path, &path[2]);
		//printf("Drive: %c:\n", drive + 'A' -1);
	}

	if (NomIma[1]==':')
	{
		drive=maj(NomIma[0]) - 'A' +1;
		strcpy(NomIma, &NomIma[2]);
		//printf("Drive: %c:\n", drive + 'A' -1);
	}


	if (	(path[strlen(path)-1] == '\\') &&
			(strlen(path) > 1) )
		path[strlen(path)-1]=0;

	//printf("Path:%c%s%c\n", 34,path,34);

	strcpy(NomObl, NomIma);
	strcpy(&NomObl[lastofchar(NomObl, '.')], ".OBL");
	//printf("NomOBl: %s\n", NomObl);
	//printf("Current path: %s\n", curpath);

	if (drive)
		setdisk(drive-1);

	if (path)
		chdir(path);

		done = findfirst(NomIma,&ffblk,0);
		if (!done) {}
		else
			printf("%-60s    [introuv.]\n", NomIma);

		while (!done)
		{
		   //printf("  %s\n", ffblk.ff_name);

		   strcpy(NomSource, ffblk.ff_name);
		   strcpy(NomObl, NomSource);
		   strcpy(&NomObl[lastofchar(NomObl, '.')], ".OBL");
		   printf("%-30s -> %-30s" , NomSource, NomObl);
		   makeobl(NomSource);
			puts("");
		   done = findnext(&ffblk);
		}

		chdir(curpath);
		setdisk(curdrive-1);
}

void givehelp(int NbArgs, char *TabPtr[])
{
	char static temp[256];
	int cpt;
	for (cpt=1; cpt < NbArgs; cpt++)
	{
		*(TabPtr[cpt]+1)= maj(*(TabPtr[cpt]+1));
		strcpy(temp,TabPtr[cpt]);
		temp[2]=0;

		if (strcmp(temp, "/C") !=0)
			strupr(TabPtr[cpt]);
		if (strcmp(temp, "/S") ==0)
			quiet=1;
		if (strcmp(temp, "/Q") ==0)
			quiet=1;


		if (strcmp(TabPtr[cpt], "/?") ==NULL)
			AfficherSyntaxe();
		if (strcmp(TabPtr[cpt], "/HELP") ==NULL)
			AfficherSyntaxe();
		if (strcmp(TabPtr[cpt], "/AIDE") ==NULL)
			AfficherSyntaxe();

	}
}

void stripof(char *chaine, char car)
{
	int cpt;
	for (cpt=0; cpt<strlen(chaine); cpt++)
	{
		if (*(chaine+cpt) == car)
			strcpy(chaine+cpt, chaine+cpt+1);
	}
}
/*	char MasterKey=0;
	char ObjClass=0;
	char S1=0;
	char S2=0;
*/

char hex2dec(unsigned char hex)
{
	//printf("[%c]", hex);
	if (((hex >='0') && (hex<='9')) )
		return(hex-'0');
	if (((hex >='A') && (hex<='F')))
		return(hex-'A'+10);
	return(18);
}

void drophex(char *code, unsigned char *dest, int *fini,char *ori)
{
	if (*fini)
	{
		*dest=0;
		return;
	}
	else
	{
		//printf("%2x",	hex2dec(*code) *16 + hex2dec(*(code+1)));
		if ( (hex2dec(*code)   == 18)   ||
			 (hex2dec(*(code+1)) == 18)    )
		{
			*fini=1;
			*dest=0;
			if(*code!=0)
			{
				printf("invalid hexa %c%s%c\n", 34,ori, 34);
				exit(2);
			}

		}
		else
		 {
			*dest= hex2dec(*code) *16 + hex2dec(*(code+1));
		 //	(*code)= ((*code)+2);
		 }
	}
}

void grabhexcode(char *code)
{

	char *ori;
	int fini=0;

	//puts(code);
	ori=  code;
	drophex(code, &MasterKey, &fini,ori); code= code+2;
	drophex(code, &ObjClass, &fini,ori);  code= code+2;
	drophex(code, &S1, &fini,ori);        code= code+2;
	drophex(code, &S2, &fini,ori);        code= code+2;
}

void withcommand(char *command)
{
	switch(*(command+1))
	{
		case 'C':
			name2comment=0;
			strcpy(comment, command+2);
			stripof(comment,34);
			break;

		case 'X':
			grabhexcode(command+2);
			break;

		case 'S':
		case 'Q':
			break;

		default:
			printf("Parametre %c%s%c invalide.\n", 34,command,34);
			break;

	}
}

void main(int NbArgs, char *TabPtr[])
{
	int cpt;

	// General purpose
	curdrive =getdisk() +1;
	curpath[0]='\\';
	getcurdir(0, &curpath[1]);

	// User want help ?
	givehelp(NbArgs, TabPtr);
	if (NbArgs <2)
		AfficherSyntaxe();

	if (!quiet)
	{
		puts("");
		puts(ver);
		puts("(C) 1995 FRANCOIS BLANCHETTE\n");
	}

	for (cpt=1; cpt < NbArgs; cpt++)
	{
		if (*(TabPtr[cpt])!='/')
		{
			withfile(TabPtr[cpt]);
			ficOui=1;
		}
		else
			withcommand(TabPtr[cpt]);
	}


	if (!ficOui)
	{
		puts("ERR: Aucune fichier specifie.");
		puts("\nSyntaxe:");
		puts("  IMA2OBL [/Xww[xxyyzz]] [/Cxxxx] fichiers ...");
		puts("");
		puts("  /? /HELP /AIDE         Aide\n");
		puts("  /Xww[xxyyzz]           Fixe les valeurs");
		puts("                         ww = clef maitre");
		puts("                         xx = obj class  ");
		puts("                         yy = special1   ");
		puts("                         zz = special2   \n");
		puts("  /Cxxxx                 Commentaire personnalise\n");
		exit(3);
	}
}