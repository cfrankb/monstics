
//
// Obl3.c
//

#include "obl3.h"

int OBL3FNT = 16;

void fillmem(char *mem, char ch, int size);

void Free1xObl3(USER_OBL3 *pOBLx)
{

       if (pOBLx==NULL) return;
       if (pOBLx->PtrBits) free(pOBLx->PtrBits);
       if (pOBLx->PtrMap)  free(pOBLx->PtrMap);
       if (pOBLx->PtrUndo) FlushOBL3Undo(pOBLx->PtrUndo); 
       free(pOBLx);

}

USER_OBL3 *MakeOBL3(int iLen, 
                    int iHei,
                    USER_OBL3 *pPrev,
                    USER_OBL3 *pNext)
{
    USER_OBL3 *pObl;
    pObl = malloc(sizeof(USER_OBL3));
    pObl->PtrBits = malloc(iLen*iHei * OBL3FNT* OBL3FNT);
    fillmem(pObl->PtrBits, 0, iLen*iHei * OBL3FNT* OBL3FNT);
    pObl->PtrPrev = pPrev;
    pObl->PtrNext = pNext;
    
    // Fill unused vars with zeros
    pObl->PtrMap = NULL;
    pObl->PtrUndo = NULL;
    memcpy(pObl->ExtraInfo, "\0\0\0", 4);
    return pObl;
}

void FlushOBL3Undo(USER_OBL3UNDO *psUndo)
{
    int x;
    if (psUndo==NULL)
        return;

    for (x=0; x<MaxUndo; x++)
    {
        if (psUndo->PtrUndo[x])
            free(psUndo->PtrUndo[x]);

        if (psUndo->PtrRedo[x])
            free(psUndo->PtrRedo[x]);
    }

    free (psUndo);

}


void FreeOBL3(USER_OBL3HEADER *psHeader)
{
    USER_OBL3 *pOBL;
    USER_OBL3 *pOBLx;
    pOBL = psHeader->PtrFirst;
    for (; pOBL; )
    {  pOBLx = pOBL;
       if (pOBLx->PtrBits) free(pOBLx->PtrBits);
       if (pOBLx->PtrMap)  free(pOBLx->PtrMap);
       if (pOBLx->PtrUndo) FlushOBL3Undo(pOBLx->PtrUndo);   
       
       pOBL = pOBLx->PtrNext;
       free(pOBLx);
    }
    psHeader->PtrFirst =NULL;
}


int SaveOBL3(USER_OBL3HEADER *psHeader, 
             const char *lpszFilename)
{
    USER_OBL3 *pObl;
    FILE *tfile;

    tfile = fopen(lpszFilename ,"wb");
    if (tfile==NULL)
        return err_fileopen;

    fwrite(psHeader, sizeof(USER_OBL3HEADER), 1, tfile);
    pObl = psHeader->PtrFirst;

    for (;pObl;pObl=pObl->PtrNext)
    {
        fwrite(pObl, sizeof(USER_OBL3), 1, tfile);
        if (pObl->PtrBits)
            fwrite(pObl->PtrBits, 
                   psHeader->iLen *OBL3FNT *
                   psHeader->iHei *OBL3FNT,
                   1,
                   tfile);
    }

    fclose(tfile);
    return TRUE;

}

 

int LoadOBL3(USER_OBL3HEADER *psHeader,
             const char *lpszFilename)
{

    static int x;
    
    USER_OBL3 *pObl ;
    USER_OBL3 *pPrev;
    static USER_OBL3HEADER lsHeader;
    FILE *sfile;

    char OBL3xx[] ="XXXX";

    fillmem((char *)&lsHeader, 0, sizeof(USER_OBL3HEADER));

    pObl = NULL;
    pPrev = NULL;

    sfile = fopen(lpszFilename ,"rb");
    if (sfile==NULL) 
        return err_fileopen;

    fread(&lsHeader, sizeof(USER_OBL3HEADER),1,sfile);

    memcpy(OBL3xx, &lsHeader, 4);
    if (strcmp(OBL3xx, "OBL3")!=0)
    {
        fclose(sfile);
        return err_format;
    }
    else;

    lsHeader.PtrFirst = NULL;
    x= (lsHeader.iNbrImages);
    for (; x; x--)
    {

        pObl = malloc(sizeof(USER_OBL3));
        fread(pObl, sizeof(USER_OBL3), 1, sfile);

        if (pPrev!=NULL)
            pPrev->PtrNext = pObl;

        if (lsHeader.PtrFirst ==NULL) 
            lsHeader.PtrFirst = pObl;

        pObl->PtrUndo = NULL;
        pObl->PtrMap = NULL;   // To-be Fix-up later

        if (pObl->PtrBits)
        {
            pObl->PtrBits = malloc(lsHeader.iLen*
                                 lsHeader.iHei*
                                 OBL3FNT * OBL3FNT);
            fread(pObl->PtrBits, lsHeader.iLen*
                                 lsHeader.iHei*
                                 OBL3FNT * OBL3FNT,
                                  1, sfile);
        }
                
        pObl->PtrPrev = pPrev;      
        pPrev = pObl;               // Prev = Current
    }

    if (pObl!=NULL)
       pObl->PtrNext = NULL;
    lsHeader.LastViewed=0;
    memcpy(psHeader, &lsHeader, sizeof(USER_OBL3HEADER));

    fclose(sfile);
    return TRUE;

}


// Give input size in pixel (not FNT)
char *ResizeImage(char *pSImage, 
            int iSLen, int iSHei, 
            int iDLen, int iDHei)
{
    char *pDImage;
    int iTLen;
    int iTHei;
    int y;
    int cpt;

    iTLen = min(iSLen, iDLen);
    iTHei = min(iSHei, iDHei);

    if (pSImage == NULL) return NULL;

    pDImage = malloc(iDLen*iDHei);
    if (pDImage==NULL) return NULL;

    for (cpt=iDLen*iDHei; cpt; cpt--)
        *(pDImage +cpt-1)=0;

    for (y=0; y<iTHei; y++)
    {
        memcpy(pDImage+y*iDLen, 
               pSImage+y*iSLen,
               iTLen);
    };

    return pDImage;
}


int NewOBL3(USER_OBL3HEADER *sHeader, 
            int iLen, int iHei)
{

    USER_OBL3 *PtrOBL;

    PtrOBL = malloc(sizeof(USER_OBL3));
    PtrOBL -> PtrPrev = NULL;
    PtrOBL -> PtrNext = NULL;
    PtrOBL -> PtrBits = malloc(iLen*iHei*OBL3FNT*OBL3FNT);
    PtrOBL -> PtrMap = NULL;
    PtrOBL -> PtrUndo = NULL;
    memcpy(PtrOBL -> ExtraInfo, "\0\0\0\0",4);

    fillmem(PtrOBL ->PtrBits, 0, iLen*iHei*OBL3FNT*OBL3FNT);

    memcpy(sHeader->Id, "OBL3", 4);
    sHeader->LastViewed =0;
    sHeader->iNbrImages =1;
    sHeader->iDefaultImage =0;
    sHeader->bClassInfo = 0;
    sHeader->bDisplayInfo =0;
    sHeader->bActAsInfo =0;
    sHeader->bItemProps =0;
    sHeader->wU1 =0;
    sHeader->wU2 =0;
    sHeader->wRebirthTime =0;
    sHeader->wMaxJump =0;
    sHeader->wFireRate =0;
    sHeader->wLifeForce =0;
    sHeader->wLives =0;
    sHeader->wOxygen =0;
    sHeader->wSpeed=0;
    sHeader->wFallSpeed=0;
    sHeader->wAniSpeed=0;
    sHeader->wTimeOut=0;
    sHeader->wDomages =0;
    sHeader->wFiller =0;
    
    sHeader->iLen =iLen;
    sHeader->iHei =iHei;

    sHeader->bU1 =0;
    sHeader->bU2= 0;
    sHeader->bU3 =0;
    sHeader->bCompilerOptions =0;

    sHeader->PtrFirst = PtrOBL;
    strcpy(sHeader->szName, "");
    strcpy(sHeader->szFilename, "");
    strcpy(sHeader->szCopyrights, "");

    return TRUE;

}
