
//
// Dialog.c
//

// *************************************************************
//
// DialogProc:
// Is a example of a dialog procedure.
//
// *************************************************************

#include "dialog.h"
#include "common.h"
#include "WinEasy.h"
#include "resource.h"

static char text1[256];
static char text2[256];

HINSTANCE extern hAppInstance;			// Application instance

BOOL CALLBACK DialogProc(HWND  hDlg,	
                         UINT  iMsg,	 
                         WPARAM  wParam, 
                         LPARAM  lParam )
{

     switch (iMsg)
          {
          case WM_INITDIALOG :

                Static_SetText(
                    GetHandle(hDlg, IDC_STATIC1),
                    text1);

                Static_SetText(
                    GetHandle(hDlg, IDC_STATIC2),
                    text2);

               return TRUE ;

          case WM_COMMAND :
               switch (LOWORD (wParam))
                    {
		            case IDOK :
		            case IDCANCEL :
			        case IDNO :
                           EndDialog (hDlg, 
			   	                   LOWORD 
				                  (wParam)) ;
			         return TRUE ;
                    }
               break ;
          }
     return FALSE ;
     }


// *************************************************************
// 
// The About dialog box handler. You know the little
// stupid box shown from the help menu
//
// Example of a dialog box
//
// *************************************************************

void AboutDialogBox()
{
	DialogBox(hAppInstance, 
		  M2INT(IDD_APROPOSDE), 
		  hAppWnd, 
		  DialogProc);
}



// *************************************************************
//
// int WarningDialog(HWND H_hwnd, const char *PTR_text1, const char *PTR_text2)
//
// *************************************************************

int WarningDialog(HWND H_hwnd, 
                  const char *PTR_text1, 
                  const char *PTR_text2)
{
	strcpy(text1, PTR_text1);
    strcpy(text2, PTR_text2);
    
    return DialogBox(hAppInstance, 
		  M2INT(IDD_ALERTE), 
		  H_hwnd, 
		  DialogProc);
    
}


//
//
//
int InfoDialog(HWND H_hwnd, const char *PTR_text1)
{
	strcpy(text1, PTR_text1);
    strcpy(text2, "");
    
    return DialogBox(hAppInstance, 
		  M2INT(IDD_INFO), 
		  H_hwnd, 
		  DialogProc);
    
}



// *************************************************************
// 
// The "Are you sure dialog?" when you quit without saving your
// program.
//
// Example of a dialog box
//
// *************************************************************

	
int QuitDialogBox()
{	
	return WarningDialog(hAppWnd,
        "Les modifications n'ayant pas �t� sauvegarder, elles seront perdues.",   
        "Souhaitez-vous sauvegarder avant de quitter ?");
}



